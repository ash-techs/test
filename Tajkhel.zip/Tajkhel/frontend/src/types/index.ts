// src/types.ts
export interface Employee {
  id: number;
  name: string;
  employeeId: string;
  department: string;
  position: string;
  salary: number;
  hireDate: string;
  email: string;
  website: string;
  status: 'Active' | 'Inactive';
  createdAt: string;
  updatedAt: string;
}

export interface Order {
  id: number;
  number: string;
  quantity: number;
  price: number;
  discount: string;
  total: number;
  status: string;
  phone: string;
  state: string;
  city: string;
  note: string;
  createdAt: string;
  updatedAt: string;
  customerId: number;
  productId: number;
  companyId: number;
  company_name: string;
  customer_name: string;
  product_name: string;
}

export interface Quote {
  id: number;
  number: string;
  customerId: number;
  companyId: number;
  date: string;
  expireDate: string;
  year: number;
  currency: string;
  status: string;
  paid: boolean;
  note: string;
  tax: number;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
  company_name: string;
  customer_name: string;
  item_count: number;
  total_quote_value: number;
}

export interface Invoice {
  id: number;
  number: string;
  customerId: number;
  date: string;
  expireDate: string;
  year: number;
  currency: string;
  status: string;
  paid: boolean;
  note: string;
  tax: number;
  createdBy: number;
  createdAt: string;
  updatedAt: string;
  companyId: number;
  company_name: string;
  customer_name: string;
  item_count: number;
  total_item_value: number;
}

export interface Product {
  id: number;
  sku: string;
  image: string;
  name: string;
  price: number;
  quantity: number;
  description: string;
  company_name: string;
  order_count: number;
  sale_count: number;
  total_sale_value: number;
  total_discount: number;
}

export interface Sale {
  id: string;
  quantity: number;
  unitPrice: number;
  discount: string;
  amount: number;
  createdAt: string;
  updatedAt: string;
  productId: number;
  companyId: number;
  weight:string;
  lot:string;
  fileno:string;
  company_name: string;
  total_sale_amount: number;
}

export interface Customer {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
  createdAt: string;
  updatedAt: string;
  companyId: number;
  company_name: string;
  order_count: number;
  invoice_count: number;
  quote_count: number;
  total_order_value: number;
}

export interface SalesData {
  month: string;
  sales: number;
  target: number;
}

export interface Stats {
  revenue: number;
  revenueChange: number;
  customers: number;
  customersChange: number;
  invoices: number;
  invoicesChange: number;
  orders: number;
  ordersChange: number;
  quoteCount: number;
  profit: number;
  profitChange: number;
  monthlyExpenses: number;
}

export interface ReportsAnalyticsResponse {
  orders: Order[];
  quotes: Quote[];
  invoices: Invoice[];
  products: Product[];
  sales: Sale[];
  customers: Customer[];
  stats: Stats;
  salesData: SalesData[];
}