import ERPHomepage from '../pages/ERPHomepage';

const Index = () => {
  return <ERPHomepage />;
};

export default Index;
