import React, { useState, useEffect } from 'react';
import { Save, Plus, Trash2, Search, Download, RefreshCw, Eye, X, Inbox, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { saleApi, Sale, CreateSaleData } from '../services/sales';
import { productAPI } from '../services/products';
import { customerAPI } from '../services/customers';

interface Product {
  id: number;
  fileno: string;
  weight: number;
  lot: string;
  kind:string;
  balance_unit: number;
  balance_weight: number;
  issue:number;
}

interface Customer {
  id: number;
  name: string;
  amount: number;
}

interface SaleFormData {
  saleId: string;
  customerId: number;
  customerName: string;
  productId: number;
  productLot: string;
  productFileno: string;
  weight: string;
  balanceUnits: string;
  unitPrice: string;
  discount: string;
  paymentMethod: string;
  status: string;
  date: string;
  notes: string;
  companyId: string | null;
  createdBy: string;
}

interface ValidationErrors {
  saleId?: string;
  customerId?: string;
  customerName?: string;
  productId?: string;
  balanceUnits?: string;
  weight?: string;
  unitPrice?: string;
  date?: string;
  paymentMethod?: string;
  status?: string;
}

interface SaleFormProps {
  allowedActions: string[];
}

const paymentMethods = ['CASH', 'CREDIT_CARD', 'BANK_TRANSFER', 'DIGITAL_WALLET'];
const statuses = ['PENDING', 'COMPLETED', 'CANCELLED', 'REFUNDED'];
const discounts = ['NO_DISCOUNT', 'FIVE_PERCENT', 'TEN_PERCENT', 'FIFTEEN_PERCENT'];

const SaleForm: React.FC<SaleFormProps> = ({ allowedActions }) => {
  const { toast } = useToast();
  const [sales, setSales] = useState<Sale[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingSaleId, setEditingSaleId] = useState<string | null>(null);
  const [deletingSaleId, setDeletingSaleId] = useState<string | null>(null);
  const [viewingSale, setViewingSale] = useState<Sale | null>(null);
  const [formData, setFormData] = useState<SaleFormData>({
    saleId: '',
    customerId: 0,
    customerName: '',
    productId: 0,
    productLot: '',
    productFileno: '',
    weight: '',
    balanceUnits: '',
    unitPrice: '',
    discount: 'NO_DISCOUNT',
    paymentMethod: 'CASH',
    status: 'PENDING',
    date: new Date().toISOString().split('T')[0],
    notes: '',
    companyId: null,
    createdBy: 'Admin',
  });
  const [errors, setErrors] = useState<ValidationErrors>({});

  // Calculate amount with discount
  const calculatedAmount = () => {
    const weight = parseFloat(formData.weight);
    const balanceUnits = parseFloat(formData.balanceUnits);
    const unitPrice = parseFloat(formData.unitPrice);
    if (isNaN(weight) || isNaN(balanceUnits) || isNaN(unitPrice)) return 0;
    let discountPercentage = 0;
    switch (formData.discount) {
      case 'FIVE_PERCENT': discountPercentage = 0.05; break;
      case 'TEN_PERCENT': discountPercentage = 0.10; break;
      case 'FIFTEEN_PERCENT': discountPercentage = 0.15; break;
      default: discountPercentage = 0;
    }
    const baseAmount = (weight * balanceUnits / 45) * unitPrice;
    return baseAmount * (1 - discountPercentage);
  };

  useEffect(() => {
    loadCustomers();
    loadProducts();
    loadSales();
  }, []);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const response = await customerAPI.getCustomers();
      setCustomers(Array.isArray(response.data) ? response.data : []);
    } catch (err: any) {
      setError('Failed to load customers. Please check the server connection.');
      toast({ title: 'Error', description: 'Failed to load customers.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const loadProducts = async () => {
    setLoading(true);
    try {
      const response = await productAPI.getProducts();
      setProducts(Array.isArray(response.data) ? response.data : []);
    } catch (err: any) {
      setError('Failed to load products. Please check the server connection.');
      toast({ title: 'Error', description: 'Failed to load products.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const loadSales = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await saleApi.getSales();
      setSales(Array.isArray(response.data.data) ? response.data.data : []);
    } catch (err: any) {
      setError('Failed to load sales. Please check the server connection.');
      toast({ title: 'Error', description: 'Failed to load sales. Please check the server connection.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    const newErrors: ValidationErrors = {};
    if (!formData.saleId.trim()) newErrors.saleId = 'Sale ID is required';
    if (!formData.customerId || !customers.find(c => c.id === formData.customerId)) {
      newErrors.customerId = 'Please select a valid customer';
    }
    if (!formData.customerName || !customers.find(c => c.name === formData.customerName)) {
      newErrors.customerName = 'Customer name does not match selected customer';
    }
    if (!formData.productId || !products.find(p => p.id === formData.productId)) {
      newErrors.productId = 'Please select a valid product';
    }
    const balanceUnits = parseFloat(formData.balanceUnits);
    if (isNaN(balanceUnits) || balanceUnits <= 0) {
      newErrors.balanceUnits = 'Balance units must be greater than 0';
    } else {
      const product = products.find(p => p.id === formData.productId);
      if (product && balanceUnits > product.balance_unit) {
        newErrors.balanceUnits = `Balance units cannot exceed available units (${product.balance_unit})`;
      }
    }
    const weight = parseFloat(formData.weight);
    if (isNaN(weight) || weight <= 0) {
      newErrors.weight = 'Weight must be greater than 0';
    }
    const unitPrice = parseFloat(formData.unitPrice);
    if (isNaN(unitPrice) || unitPrice <= 0) {
      newErrors.unitPrice = 'Price (per 45 kg) must be greater than 0';
    }
    if (!formData.date || !/^\d{4}-\d{2}-\d{2}$/.test(formData.date)) {
      newErrors.date = 'Date is required (YYYY-MM-DD)';
    }
    if (!formData.paymentMethod || !paymentMethods.includes(formData.paymentMethod)) {
      newErrors.paymentMethod = 'Payment method is required';
    }
    if (!formData.status || !statuses.includes(formData.status)) {
      newErrors.status = 'Status is required';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (value.trim()) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSelectChange = (name: string, value: string | number) => {
    if (name === 'productId') {
      const product = products.find(p => p.id === Number(value));
      setFormData(prev => ({
        ...prev,
        productId: Number(value),
        productLot: product?.lot || '',
        productFileno: product?.fileno || '',
        weight: product?.weight.toString() || '',
      }));
      setErrors(prev => ({
        ...prev,
        productId: product ? undefined : 'Please select a valid product',
        balanceUnits: undefined,
        weight: undefined,
      }));
    } else if (name === 'customerId') {
      const customer = customers.find(c => c.id === Number(value));
      setFormData(prev => ({
        ...prev,
        customerId: Number(value),
        customerName: customer?.name || '',
      }));
      setErrors(prev => ({
        ...prev,
        customerId: customer ? undefined : 'Please select a valid customer',
        customerName: customer ? undefined : 'Customer name does not match selected customer',
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSave = async () => {
    if (!validateForm()) {
      toast({ title: 'Validation Error', description: 'Please correct the form errors.', variant: 'destructive' });
      return;
    }
    setLoading(true);
    try {
      const saleData: CreateSaleData = {
        saleId: formData.saleId,
        customerId: formData.customerId,
        customerName: formData.customerName,
        productId: formData.productId,
        balanceUnits: parseFloat(formData.balanceUnits),
        weight: parseFloat(formData.weight),
        unitPrice: parseFloat(formData.unitPrice),
        discount: formData.discount,
        paymentMethod: formData.paymentMethod,
        status: formData.status,
        date: formData.date,
        notes: formData.notes || undefined,
        createdBy: formData.createdBy,
        companyId: formData.companyId,
      };
      if (editingSaleId) {
        await saleApi.updateSale(editingSaleId, saleData);
        toast({ title: 'Success', description: 'Sale updated successfully.' });
      } else {
        await saleApi.createSale(saleData);
        toast({ title: 'Success', description: 'Sale created successfully.' });
      }
      await loadSales();
      setIsCreateDialogOpen(false);
      setEditingSaleId(null);
      resetForm();
    } catch (err: any) {
      setError(err.message || 'Failed to save sale. Please check the server connection.');
      toast({ title: 'Error', description: err.message || 'Failed to save sale.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: string) => {
  setLoading(true);
  try {
    const response = await saleApi.getSaleById(id); // AxiosResponse<Sale>
    const sale = response.data; // Access the Sale object
    setFormData({
      saleId: sale.saleId,
      customerId: sale.customerId,
      customerName: sale.customerName,
      productId: sale.productId,
      productLot: sale.productLot || '',
      productFileno: sale.productFileno || '',
      weight: sale.weight.toString(),
      balanceUnits: sale.balanceUnits.toString(),
      unitPrice: sale.unitPrice.toString(),
      discount: sale.discount,
      paymentMethod: sale.paymentMethod,
      status: sale.status,
      date: sale.createdAt.split('T')[0],
      notes: sale.notes || '',
      companyId: sale.companyId,
      createdBy: sale.createdBy,
    });
    setEditingSaleId(id);
    setIsCreateDialogOpen(true);
  } catch (err: any) {
    setError('Failed to load sale. Please check the server connection.');
    toast({ title: 'Error', description: err.message || 'Failed to load sale.', variant: 'destructive' });
  } finally {
    setLoading(false);
  }
};
  const handleDelete = async (id: string) => {
    setLoading(true);
    try {
      await saleApi.deleteSale(id);
      await loadSales();
      toast({ title: 'Success', description: 'Sale deleted successfully.' });
      setIsDeleteDialogOpen(false);
      setDeletingSaleId(null);
    } catch (err: any) {
      setError('Failed to delete sale. Please check the server connection.');
      toast({ title: 'Error', description: err.message || 'Failed to delete sale.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleView = (sale: Sale) => {
    setViewingSale(sale);
    setIsViewDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      saleId: '',
      customerId: 0,
      customerName: '',
      productId: 0,
      productLot: '',
      productFileno: '',
      weight: '',
      balanceUnits: '',
      unitPrice: '',
      discount: 'NO_DISCOUNT',
      paymentMethod: 'CASH',
      status: 'PENDING',
      date: new Date().toISOString().split('T')[0],
      notes: '',
      companyId: null,
      createdBy: 'Admin',
    });
    setErrors({});
  };
  const handleDownloadPDF = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await saleApi.downloadSalesPDF();
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'sales-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download PDF error:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredSales = sales.filter(sale =>
    sale.saleId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.productLot.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalAmount = filteredSales.reduce((sum, sale) => sum + sale.amount, 0);

  return (
    <div className="p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <h1 className="text-2xl font-bold mb-2 sm:mb-0">Sales</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search sales..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Button variant="outline" onClick={loadSales} disabled={loading}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
          <Button onClick={handleDownloadPDF} disabled={loading}>
            <Download className="mr-2 h-4 w-4" /> Download PDF
          </Button>
          {allowedActions.includes('create') && (
            <Dialog open={isCreateDialogOpen} onOpenChange={(open) => {
              setIsCreateDialogOpen(open);
              if (!open) {
                setEditingSaleId(null);
                resetForm();
              }
            }}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="mr-2 h-4 w-4" /> Add Sale
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingSaleId ? 'Edit Sale' : 'Add Sale'}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="saleId" className="text-right">* Sale ID</Label>
                    <Input
                      id="saleId"
                      name="saleId"
                      value={formData.saleId}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.saleId ? 'border-red-500' : ''}`}
                      placeholder="Enter sale ID"
                    />
                    {errors.saleId && <p className="col-span-4 text-red-500 text-xs">{errors.saleId}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="customerId" className="text-right">* Customer</Label>
                    <Select
                      value={formData.customerId.toString()}
                      onValueChange={(value) => handleSelectChange('customerId', value)}
                    >
                      <SelectTrigger className={`col-span-3 ${errors.customerId ? 'border-red-500' : ''}`}>
                        <SelectValue placeholder="Select customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map(customer => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.customerId && <p className="col-span-4 text-red-500 text-xs">{errors.customerId}</p>}
                    {errors.customerName && <p className="col-span-4 text-red-500 text-xs">{errors.customerName}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="productId" className="text-right">* Product</Label>
                    <Select
                      value={formData.productId.toString()}
                      onValueChange={(value) => handleSelectChange('productId', value)}
                    >
                      <SelectTrigger className={`col-span-3 ${errors.productId ? 'border-red-500' : ''}`}>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        {products.map(product => (
                          <SelectItem key={product.id} value={product.id.toString()}>
                           {product.kind} {product.lot} (Units: {product.balance_unit}, Weight: {product.balance_weight})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.productId && <p className="col-span-4 text-red-500 text-xs">{errors.productId}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="weight" className="text-right">* Weight (per unit)</Label>
                    <Input
                      id="weight"
                      name="weight"
                      type="number"
                      step="0.01"
                      value={formData.weight}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.weight ? 'border-red-500' : ''}`}
                      placeholder="Enter weight per unit"
                    />
                    {errors.weight && <p className="col-span-4 text-red-500 text-xs">{errors.weight}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="balanceUnits" className="text-right">* Balance Units</Label>
                    <Input
                      id="balanceUnits"
                      name="balanceUnits"
                      type="number"
                      value={formData.balanceUnits}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.balanceUnits ? 'border-red-500' : ''}`}
                      placeholder="Enter units sold"
                    />
                    {errors.balanceUnits && <p className="col-span-4 text-red-500 text-xs">{errors.balanceUnits}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="unitPrice" className="text-right">* Price (per 45 kg)</Label>
                    <Input
                      id="unitPrice"
                      name="unitPrice"
                      type="number"
                      step="0.01"
                      value={formData.unitPrice}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.unitPrice ? 'border-red-500' : ''}`}
                      placeholder="Enter price per 45 kg"
                    />
                    {errors.unitPrice && <p className="col-span-4 text-red-500 text-xs">{errors.unitPrice}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">Calculated Amount</Label>
                    <div className="col-span-3 text-sm">Rs {calculatedAmount().toFixed(2)}</div>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="discount" className="text-right">Discount</Label>
                    <Select
                      value={formData.discount}
                      onValueChange={(value) => handleSelectChange('discount', value)}
                    >
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select discount" />
                      </SelectTrigger>
                      <SelectContent>
                        {discounts.map(discount => (
                          <SelectItem key={discount} value={discount}>{discount.replace('_', ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paymentMethod" className="text-right">* Payment Method</Label>
                    <Select
                      value={formData.paymentMethod}
                      onValueChange={(value) => handleSelectChange('paymentMethod', value)}
                    >
                      <SelectTrigger className={`col-span-3 ${errors.paymentMethod ? 'border-red-500' : ''}`}>
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentMethods.map(method => (
                          <SelectItem key={method} value={method}>{method.replace('_', ' ')}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.paymentMethod && <p className="col-span-4 text-red-500 text-xs">{errors.paymentMethod}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="status" className="text-right">* Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleSelectChange('status', value)}
                    >
                      <SelectTrigger className={`col-span-3 ${errors.status ? 'border-red-500' : ''}`}>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {statuses.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.status && <p className="col-span-4 text-red-500 text-xs">{errors.status}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="notes" className="text-right">Notes</Label>
                    <Input
                      id="notes"
                      name="notes"
                      value={formData.notes}
                      onChange={handleInputChange}
                      className="col-span-3"
                      placeholder="Enter notes (optional)"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)} disabled={loading}>
                    Cancel
                  </Button>
                  <Button onClick={handleSave} disabled={loading}>
                    <Save className="mr-2 h-4 w-4" /> {editingSaleId ? 'Update' : 'Save'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
      {error && <div className="p-4 text-red-600 bg-red-50 rounded-md mb-4">{error}</div>}
      <div className="bg-white rounded-lg shadow">
        <div className="p-4 overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sale ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center">
                    <Inbox className="h-12 w-12 mx-auto text-gray-400" />
                    <p className="mt-2 text-sm text-gray-500">No sales found</p>
                  </td>
                </tr>
              ) : (
                filteredSales.map(sale => (
                  <tr key={sale.id}>
                    <td className="px-6 py-4 text-sm">{sale.saleId}</td>
                    <td className="px-6 py-4 text-sm">{sale.customerName}</td>
                    <td className="px-6 py-4 text-sm">{sale.productLot}</td>
                    <td className="px-6 py-4 text-sm">Rs {sale.amount.toFixed(2)}</td>
                    <td className="px-6 py-4 text-sm">{sale.createdAt.split('T')[0]}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`px-2 py-1 rounded-full text-xs ${sale.status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                        {sale.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className="flex space-x-2">
                        {allowedActions.includes('read') && (
                          <Button variant="outline" size="sm" onClick={() => handleView(sale)} disabled={loading}>
                            <Eye className="h-4 w-4" />
                          </Button>
                        )}
                        {allowedActions.includes('update') && (
                          <Button variant="outline" 
                          size="sm" 
                          onClick={() => handleEdit(sale.id)} 
                          disabled={loading || sale.status.toUpperCase() === 'COMPLETED'}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                        {allowedActions.includes('delete') && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setDeletingSaleId(sale.id);
                              setIsDeleteDialogOpen(true);
                            }}
                            disabled={loading}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan={3} className="px-6 py-3 text-sm font-medium">Total</td>
                <td className="px-6 py-3 text-sm font-medium">Rs {totalAmount.toFixed(2)}</td>
                <td colSpan={3}></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Sale Details</DialogTitle>
          </DialogHeader>
          {viewingSale && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><strong>Sale ID:</strong> {viewingSale.saleId}</div>
                <div><strong>Customer:</strong> {viewingSale.customerName}</div>
                <div><strong>Product Lot:</strong> {viewingSale.productLot}</div>
                <div><strong>File No:</strong> {viewingSale.productFileno}</div>
                <div><strong>Weight (per unit):</strong> {viewingSale.weight}</div>
                <div><strong>Balance Units:</strong> {viewingSale.balanceUnits}</div>
                <div><strong>Balance Weight:</strong> {viewingSale.balanceWeight}</div>
                <div><strong>Price (per 45 kg):</strong> Rs {viewingSale.unitPrice.toFixed(2)}</div>
                <div><strong>Total Amount:</strong> Rs {viewingSale.amount.toFixed(2)}</div>
                <div><strong>Date:</strong> {viewingSale.createdAt.split('T')[0]}</div>
                <div><strong>Discount:</strong> {viewingSale.discount.replace('_', ' ')}</div>
                <div><strong>Payment Method:</strong> {viewingSale.paymentMethod.replace('_', ' ')}</div>
                <div><strong>Status:</strong> {viewingSale.status}</div>
                <div><strong>Notes:</strong> {viewingSale.notes || 'N/A'}</div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsViewDialogOpen(false)} disabled={loading}>
                  <X className="h-4 w-4 mr-2" /> Close
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <p className="text-sm text-gray-600">Are you sure you want to delete this sale? This action cannot be undone.</p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsDeleteDialogOpen(false);
                setDeletingSaleId(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deletingSaleId && handleDelete(deletingSaleId)}
              disabled={loading}
            >
              <Trash2 className="h-4 w-4 mr-2" /> Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SaleForm;