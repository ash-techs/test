import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, RefreshCw, Plus, Save, Download, Edit, Trash2, Eye, X, Inbox } from 'lucide-react';
import { paymentsAPI } from '../services/payments';
import { customerAPI } from '../services/customers';
import { useToast } from '@/hooks/use-toast';

interface Customer {
  id: string;
  name: string;
  amount: number;
}

interface Payment {
  id: string;
  customerId: string;
  customerName: string; // Added
  amount: number;
  date: string;
  transactionDate: string;
  paymentMode: string;
  paymentTransaction: string;
  status: string;
  notes: string;
}

interface ValidationErrors {
  customerId?: string;
  customerName?: string; // Added
  amount?: string;
  date?: string;
  transactionDate?: string;
  paymentMode?: string;
  status?: string;
}

const paymentModes = ['Cash', 'Credit Card', 'Bank Transfer', 'Cheque', 'Digital Wallet'];
const paymentStatuses = ['Pending', 'Processing', 'Completed', 'Failed', 'Refunded'];

const LightGlassCard = ({ children, className = '', gradient = false }: any) => (
  <div className={`backdrop-blur-xl bg-white/80 border border-gray-200/50 rounded-2xl shadow-lg ${gradient ? 'bg-gradient-to-br from-white/90 to-gray-50/80' : ''} ${className}`}>
    {children}
  </div>
);

const PaymentsForm = () => {
  const { toast } = useToast();
  const [payments, setPayments] = useState<Payment[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [newPayment, setNewPayment] = useState<Payment>({
    id: '',
    customerId: '',
    customerName: '', // Added
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    transactionDate: new Date().toISOString().split('T')[0],
    paymentMode: 'Cash',
    paymentTransaction: '',
    status: 'Pending',
    notes: '',
  });
  const [open, setOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [viewingPayment, setViewingPayment] = useState<Payment | null>(null);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState<string>('7d');
  const [visiblePayments, setVisiblePayments] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [errors, setErrors] = useState<ValidationErrors>({});

  useEffect(() => {
    loadCustomers();
    loadPayments();
  }, [dateRange]);

  const loadCustomers = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await customerAPI.getCustomers();
      const customers = Array.isArray(response.data) ? response.data : response.data?.data || [];
      if (!Array.isArray(customers)) {
        throw new Error('Expected an array of customers, received: ' + JSON.stringify(response.data));
      }
      setCustomers(customers);
    } catch (err: any) {
      console.error('Error loading customers:', { error: err.message, response: err.response?.data });
      const errorMessage = err.response?.data?.error || err.message || 'Failed to load customers.';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const loadPayments = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await paymentsAPI.getPayments();
      const payments = Array.isArray(response.data) ? response.data : response.data?.data || [];
      if (!Array.isArray(payments)) {
        throw new Error('Expected an array of payments, received: ' + JSON.stringify(response.data));
      }
      const validPayments = payments.map((payment) => ({
        ...payment,
        amount: Number(payment.amount) || 0,
        customerId: payment.customerId || '',
        customerName: payment.customerName || '', // Added
        paymentTransaction: payment.paymentTransaction || '',
        notes: payment.notes || '',
      }));
      setPayments(validPayments);
    } catch (err: any) {
      console.error('Error loading payments:', { error: err.message, response: err.response?.data });
      const errorMessage = err.response?.data?.error || err.message || 'Failed to load payments.';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const validatePayment = (data: Payment) => {
    const newErrors: ValidationErrors = {};

    if (!data.customerId || !customers.find(c => c.id === data.customerId)) {
      newErrors.customerId = 'Please select a valid customer';
    }

    if (!data.customerName || !customers.find(c => c.name === data.customerName)) {
      newErrors.customerName = 'Customer name does not match selected customer';
    }

    if (!data.amount || isNaN(Number(data.amount)) || Number(data.amount) <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }

    if (!data.date || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
      newErrors.date = 'Date is required (YYYY-MM-DD)';
    }

    if (!data.transactionDate || !/^\d{4}-\d{2}-\d{2}$/.test(data.transactionDate)) {
      newErrors.transactionDate = 'Transaction date is required (YYYY-MM-DD)';
    } else if (new Date(data.transactionDate) > new Date()) {
      newErrors.transactionDate = 'Transaction date cannot be in the future';
    }

    if (!data.paymentMode || !paymentModes.includes(data.paymentMode)) {
      newErrors.paymentMode = 'Payment mode is required';
    }

    if (!data.status || !paymentStatuses.includes(data.status)) {
      newErrors.status = 'Status is required';
    }

    return newErrors;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    let parsedValue: any = value;

    if (name === 'amount') {
      parsedValue = value === '' ? '' : parseFloat(value);
      if (parsedValue !== '' && (isNaN(parsedValue) || parsedValue < 0)) {
        setErrors((prev) => ({ ...prev, amount: 'Amount must be a positive number' }));
      } else {
        setErrors((prev) => ({ ...prev, amount: undefined }));
      }
    } else if (name === 'number') {
      if (value && !/^[a-zA-Z0-9-]{1,20}$/.test(value)) {
        setErrors((prev) => ({ ...prev, number: 'Number must be alphanumeric with hyphens and up to 20 characters' }));
      } else {
        setErrors((prev) => ({ ...prev, number: value ? undefined : 'Number is required' }));
      }
    } else if (name === 'transactionDate') {
      if (value && new Date(value) > new Date()) {
        setErrors((prev) => ({ ...prev, transactionDate: 'Transaction date cannot be in the future' }));
      } else {
        setErrors((prev) => ({ ...prev, transactionDate: value ? undefined : 'Transaction date is required' }));
      }
    } else if (value.trim()) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }

    setNewPayment((prev) => ({ ...prev, [name]: parsedValue }));
  };

  const handleSelectChange = (name: string, value: string) => {
    if (name === 'customerId') {
      const selectedCustomer = customers.find(c => c.id === value);
      setNewPayment((prev) => ({
        ...prev,
        customerId: value,
        customerName: selectedCustomer?.name || '',
      }));
      setErrors((prev) => ({
        ...prev,
        customerId: selectedCustomer ? undefined : 'Please select a valid customer',
        customerName: selectedCustomer ? undefined : 'Customer name does not match selected customer',
      }));
    } else {
      setNewPayment((prev) => ({ ...prev, [name]: value }));
      if (name === 'paymentMode' && paymentModes.includes(value)) {
        setErrors((prev) => ({ ...prev, paymentMode: undefined }));
      } else if (name === 'status' && paymentStatuses.includes(value)) {
        setErrors((prev) => ({ ...prev, status: undefined }));
      }
    }
  };

  const resetForm = () => {
    setNewPayment({
      id: '',
      customerId: '',
      customerName: '',
      amount: 0,
      date: new Date().toISOString().split('T')[0],
      transactionDate: new Date().toISOString().split('T')[0],
      paymentMode: 'Cash',
      paymentTransaction: '',
      status: 'Pending',
      notes: '',
    });
    setErrors({});
  };

  const handleSave = async () => {
    setLoading(true);
    setError(null);

    try {
      const validationErrors = validatePayment(newPayment);
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        toast({
          title: 'Validation Error',
          description: 'Please correct the form errors',
          variant: 'destructive',
        });
        return;
      }

      const paymentToSave = {
        ...newPayment,
        amount: Number(newPayment.amount) || 0,
        customerName: newPayment.customerName || '', // Added
        paymentTransaction: newPayment.paymentTransaction || '',
        notes: newPayment.notes || '',
      };

      if (editingId) {
        await paymentsAPI.updatePayment(editingId, paymentToSave);
        toast({
          title: 'Success',
          description: 'Payment updated successfully',
        });
      } else {
        await paymentsAPI.createPayment(paymentToSave);
        toast({
          title: 'Success',
          description: 'Payment created successfully',
        });
      }

      await loadPayments();
      setOpen(false);
      setEditingId(null);
      resetForm();

    } catch (err: any) {
      console.error('Error saving payment:', { error: err.message, response: err.response?.data });
      const errorMessage = err.response?.data?.error || err.message || 'Failed to save payment.';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: string) => {
    setLoading(true);
    setError(null);
    setErrors({});
    try {
      const response = await paymentsAPI.getPayment(id);
      const paymentData = {
        ...response.data,
        amount: Number(response.data.amount) || 0,
        customerId: response.data.customerId || '',
        customerName: response.data.customerName || '', // Added
        date: response.data.date ? response.data.date.split('T')[0] : new Date().toISOString().split('T')[0],
        transactionDate: response.data.transactionDate ? response.data.transactionDate.split('T')[0] : new Date().toISOString().split('T')[0],
        paymentTransaction: response.data.paymentTransaction || '',
        notes: response.data.notes || '',
      };
      setNewPayment(paymentData);
      setEditingId(id);
      setOpen(true);
    } catch (err: any) {
      console.error('Error loading payment for edit:', { error: err.message, response: err.response?.data });
      const errorMessage = err.response?.data?.error || err.message || 'Failed to load payment.';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleView = (payment: Payment) => {
    setViewingPayment(payment);
    setIsViewDialogOpen(true);
  };

  const handleDelete = async (id: string | null) => {
    if (!id) return;

    setLoading(true);
    setError(null);
    try {
      await paymentsAPI.deletePayment(id);
      await loadPayments();
      toast({
        title: 'Success',
        description: 'Payment deleted successfully',
      });
      setItemToDelete(null);
      setIsDeleteDialogOpen(false);
    } catch (err: any) {
      console.error('Error deleting payment:', { error: err.message, response: err.response?.data });
      const errorMessage = err.response?.data?.error || err.message || 'Failed to delete payment.';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDF = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await paymentsAPI.downloadPaymentsPDF();
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'payments-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download PDF error:', err);
    } finally {
      setLoading(false);
    }
  };


  const filteredPayments = payments.filter(payment =>
    (payment.customerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (payment.paymentTransaction || '').toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, visiblePayments);

  const totalAmount = filteredPayments.reduce((sum, payment) => sum + (Number(payment.amount) || 0), 0);

  const handleScroll = () => {
    const table = document.querySelector('.payment-table-container');
    if (table) {
      const { scrollTop, scrollHeight, clientHeight } = table;
      if (scrollTop + clientHeight >= scrollHeight - 20) {
        setVisiblePayments(prev => prev + 10);
      }
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 sm:mb-6">
        <h1 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-0">Payments</h1>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search payments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-full sm:w-32">
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="14d">Last 14 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" onClick={loadPayments} disabled={loading}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
          <Button onClick={handleDownloadPDF} disabled={loading}>
            <Download className="mr-2 h-4 w-4" /> Download PDF
          </Button>
          <Dialog open={open} onOpenChange={(isOpen) => {
            setOpen(isOpen);
            if (!isOpen) {
              setEditingId(null);
              resetForm();
            }
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Add Payment
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
              <LightGlassCard className="p-6" gradient>
                <DialogHeader>
                  <DialogTitle>{editingId ? 'Edit Payment' : 'Add Payment'}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="customerId" className="text-right">* From</Label>
                    <Select
                      value={newPayment.customerId}
                      onValueChange={(value) => handleSelectChange('customerId', value)}
                    >
                      <SelectTrigger
                        id="customerId"
                        name="customerId"
                        className={`col-span-3 ${errors.customerId ? 'border-red-500 bg-red-50' : ''}`}
                      >
                        <SelectValue placeholder="Select customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map(customer => (
                          <SelectItem key={customer.id} value={customer.id}>{customer.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.customerId && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.customerId}</p>}
                    {errors.customerName && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.customerName}</p>}
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="amount" className="text-right">* Amount</Label>
                    <Input
                      id="amount"
                      name="amount"
                      type="number"
                      min="0"
                      step="0.01"
                      value={newPayment.amount || ''}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.amount ? 'border-red-500 bg-red-50' : ''}`}
                      placeholder="Enter amount"
                    />
                    {errors.amount && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.amount}</p>}
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="date" className="text-right">* Date</Label>
                    <Input
                      id="date"
                      name="date"
                      type="date"
                      value={newPayment.date}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.date ? 'border-red-500 bg-red-50' : ''}`}
                    />
                    {errors.date && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.date}</p>}
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="transactionDate" className="text-right">* Transaction Date</Label>
                    <Input
                      id="transactionDate"
                      name="transactionDate"
                      type="date"
                      value={newPayment.transactionDate}
                      onChange={handleInputChange}
                      className={`col-span-3 ${errors.transactionDate ? 'border-red-500 bg-red-50' : ''}`}
                    />
                    {errors.transactionDate && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.transactionDate}</p>}
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paymentMode" className="text-right">* Payment Mode</Label>
                    <Select
                      value={newPayment.paymentMode}
                      onValueChange={(value) => handleSelectChange('paymentMode', value)}
                    >
                      <SelectTrigger
                        id="paymentMode"
                        name="paymentMode"
                        className={`col-span-3 ${errors.paymentMode ? 'border-red-500 bg-red-50' : ''}`}
                      >
                        <SelectValue placeholder="Select payment mode" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentModes.map(mode => (
                          <SelectItem key={mode} value={mode}>{mode}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.paymentMode && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.paymentMode}</p>}
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="paymentTransaction" className="text-right">Transaction Number</Label>
                    <Input
                      id="paymentTransaction"
                      name="paymentTransaction"
                      value={newPayment.paymentTransaction}
                      onChange={handleInputChange}
                      className="col-span-3"
                      placeholder="Enter transaction number"
                    />
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="status" className="text-right">* Status</Label>
                    <Select
                      value={newPayment.status}
                      onValueChange={(value) => handleSelectChange('status', value)}
                    >
                      <SelectTrigger
                        id="status"
                        name="status"
                        className={`col-span-3 ${errors.status ? 'border-red-500 bg-red-50' : ''}`}
                      >
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {paymentStatuses.map(status => (
                          <SelectItem key={status} value={status}>{status}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.status && <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.status}</p>}
                  </div>

                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="notes" className="text-right">Notes</Label>
                    <Input
                      id="notes"
                      name="notes"
                      value={newPayment.notes}
                      onChange={handleInputChange}
                      className="col-span-3"
                      placeholder="Enter notes (optional)"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setOpen(false);
                      setEditingId(null);
                      resetForm();
                    }}
                    disabled={loading}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleSave} disabled={loading}>
                    <Save className="mr-2 h-4 w-4" /> {editingId ? 'Update' : 'Save'}
                  </Button>
                </div>
              </LightGlassCard>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {error && (
        <LightGlassCard className="mb-4 p-4" gradient>
          <p className="text-red-700">{error}</p>
        </LightGlassCard>
      )}

      <LightGlassCard className="p-4" gradient>
        <div className="payment-table-container" onScroll={handleScroll}>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Mode</th>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-3 sm:px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredPayments.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                      <div className="flex flex-col items-center">
                        <Inbox className="h-12 w-12 mb-2 text-gray-400" />
                        <p className="text-lg font-medium mb-1">No payments yet</p>
                        <p className="text-sm">Click "Add Payment" to get started</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredPayments.map(payment => (
                    <tr key={payment.id}>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <span className="text-gray-700">{payment.customerName || 'N/A'}</span>
                      </td>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <span className="text-gray-700">Rs {Number(payment.amount).toFixed(2)}</span>
                      </td>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <span className="text-gray-700">{payment.date || 'N/A'}</span>
                      </td>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <span className="text-gray-700">{payment.paymentMode || 'N/A'}</span>
                      </td>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${payment.status === 'Completed' ? 'bg-green-100 text-green-800' :
                              payment.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                                payment.status === 'Processing' ? 'bg-orange-100 text-orange-800' :
                                  payment.status === 'Received' ? 'bg-blue-100 text-blue-800' :
                                    payment.status === 'Refunded' ? 'bg-purple-100 text-purple-800' :
                                      'bg-red-100 text-red-800'
                            }`}
                        >
                          {payment.status || 'N/A'}
                        </span>
                      </td>
                      <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleView(payment)}
                            disabled={loading}
                            title="View Payment"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEdit(payment.id)}
                            disabled={loading}
                            title="Edit Payment"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setItemToDelete(payment.id);
                              setIsDeleteDialogOpen(true);
                            }}
                            disabled={loading}
                            title="Delete Payment"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
              {filteredPayments.length > 0 && (
                <tfoot className="bg-gray-50 border-t">
                  <tr>
                    <td colSpan={2} className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">
                      Total
                    </td>
                    <td className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">
                      Rs {totalAmount.toFixed(2)}
                    </td>
                    <td colSpan={4}></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      </LightGlassCard>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Eye className="h-5 w-5 mr-2" />
                View Payment Details
              </DialogTitle>
            </DialogHeader>
            {viewingPayment && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">From</label>
                    <p className="text-lg text-gray-900">{viewingPayment.customerName || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Amount</label>
                    <p className="text-lg text-gray-900">Rs {(Number(viewingPayment.amount) || 0).toFixed(2)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Date</label>
                    <p className="text-lg text-gray-900">{viewingPayment.date || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Transaction Date</label>
                    <p className="text-lg text-gray-900">{viewingPayment.transactionDate || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Payment Mode</label>
                    <p className="text-lg text-gray-900">{viewingPayment.paymentMode || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Transaction Number</label>
                    <p className="text-lg text-gray-900">{viewingPayment.paymentTransaction || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Status</label>
                    <p className="text-lg text-gray-900">{viewingPayment.status || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Notes</label>
                    <p className="text-lg text-gray-900">{viewingPayment.notes || 'N/A'}</p>
                  </div>
                </div>
                <div className="flex justify-end pt-6">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsViewDialogOpen(false);
                      setViewingPayment(null);
                    }}
                    className="px-6 py-2"
                    disabled={loading}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Close
                  </Button>
                </div>
              </div>
            )}
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle>Confirm Delete</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-gray-700">Are you sure you want to delete this payment? This action cannot be undone.</p>
              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsDeleteDialogOpen(false);
                    setItemToDelete(null);
                  }}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => handleDelete(itemToDelete)}
                  disabled={loading || !itemToDelete}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </LightGlassCard>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PaymentsForm;