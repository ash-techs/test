import React, { useState, useEffect } from 'react';
import { Save, Plus, Trash2, Pencil, Search, RefreshCw, Grid2x2Plus, Eye, Info, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { productAPI } from '../services/products';

interface ProductData {
  id?: number;
  lot: string;
  fileno: string;
  color?: string;
  kind?: string;
  mix?: string;
  balance_unit: number;
  weight: number;
  issue: number;
  balance_weight: number;
  price: number;
  description?: string;
}

interface ProductsProps {
  allowedActions: string[];
}

const Products: React.FC<ProductsProps> = ({ allowedActions }) => {
  const { toast } = useToast();
  const [products, setProducts] = useState<ProductData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState<ProductData>({
    lot: '',
    fileno: '',
    color: '',
    kind: '',
    mix: '',
    balance_unit: 0,
    weight: 0,
    issue: 0,
    balance_weight: 0,
    price: 0,
    description: '',
  });

  const [isAddEditDialogOpen, setIsAddEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isConfirmDeleteDialogOpen, setIsConfirmDeleteDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [viewingProduct, setViewingProduct] = useState<ProductData | null>(null);
  const [productToDelete, setProductToDelete] = useState<number | null>(null);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await productAPI.getProducts();
      setProducts(response.data);
    } catch (err) {
      console.error('Error loading products:', err);
      setError('Failed to load products. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let parsedValue: string | number = value;

    // Parse numeric fields to numbers, handling empty or invalid inputs
    if (['price', 'balance_unit', 'weight', 'issue', 'balance_weight'].includes(name)) {
      parsedValue = value === '' ? 0 : parseFloat(value);
      if (isNaN(parsedValue)) {
        parsedValue = 0; // Default to 0 for invalid inputs
      }
    }

    let newFormData = {
      ...formData,
      [name]: parsedValue,
    };

    // Compute balance_weight or issue based on input
    if (name === 'balance_unit' || name === 'weight' || name === 'issue') {
      const calculatedBalanceWeight = (newFormData.balance_unit * newFormData.weight) + (newFormData.issue || 0);
      newFormData.balance_weight = calculatedBalanceWeight >= 0 ? calculatedBalanceWeight : 0;
      if (calculatedBalanceWeight < 0) {
        setError('Balance weight cannot be negative. Adjust the issue value.');
      } else {
        setError(null);
      }
    } else if (name === 'balance_weight') {
      // Ensure parsedValue is a number
      const numericValue = typeof parsedValue === 'number' ? parsedValue : 0;
      if (numericValue < 0) {
        setError('Balance weight cannot be negative.');
        newFormData.balance_weight = 0;
      } else {
        setError(null);
        newFormData.issue = numericValue - (newFormData.balance_unit * newFormData.weight);
      }
    }

    setFormData(newFormData);
  };

  const resetForm = () => {
    setFormData({
      lot: '',
      fileno: '',
      color: '',
      kind: '',
      mix: '',
      balance_unit: 0,
      weight: 0,
      issue: 0,
      balance_weight: 0,
      price: 0,
      description: '',
    });
    setEditingId(null);
    setError(null);
  };

  const handleAddOrUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Validate balance_unit and balance_weight
    if (formData.balance_unit < 0) {
      setError('Balance unit cannot be negative.');
      setLoading(false);
      return;
    }
    if (formData.balance_weight < 0) {
      setError('Balance weight cannot be negative.');
      setLoading(false);
      return;
    }

    try {
      if (editingId) {
        await productAPI.updateProduct(editingId, formData);
        toast({
          title: 'Product updated successfully!',
          description: `Product with ID ${editingId} has been updated.`,
        });
      } else {
        await productAPI.createProduct(formData);
        toast({
          title: 'Product added successfully!',
          description: `New product with lot "${formData.lot}" has been created.`,
        });
      }
      
      await loadProducts();
      resetForm();
      setIsAddEditDialogOpen(false);
    } catch (err: any) {
      console.error('Error saving product:', err);
      const errorMessage = err.response?.data?.error || 'Failed to save product. Please check your input and try again.';
      setError(errorMessage);
      toast({
        title: 'Error saving product',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: number) => {
    setLoading(true);
    setError(null);
    try {
      const response = await productAPI.getProduct(id);
      const productData = {
        ...response.data,
        lot: response.data.lot || '',
        fileno: response.data.fileno || '',
        color: response.data.color || '',
        kind: response.data.kind || '',
        mix: response.data.mix || '',
        price: parseFloat(response.data.price) || 0,
        balance_unit: parseFloat(response.data.balance_unit) || 0,
        weight: parseFloat(response.data.weight) || 0,
        issue: parseFloat(response.data.issue) || 0,
        balance_weight: parseFloat(response.data.balance_weight) || 0,
        description: response.data.description || '',
      };
      setFormData(productData);
      setEditingId(id);
      setIsAddEditDialogOpen(true);
    } catch (err) {
      console.error('Error fetching product for edit:', err);
      setError('Failed to load product for editing. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleView = async (id: number) => {
    setLoading(true);
    setError(null);
    try {
      const response = await productAPI.getProduct(id);
      const productData = {
        ...response.data,
        lot: response.data.lot || '',
        fileno: response.data.fileno || '',
        color: response.data.color || '',
        kind: response.data.kind || '',
        mix: response.data.mix || '',
        price: parseFloat(response.data.price) || 0,
        balance_unit: parseFloat(response.data.balance_unit) || 0,
        weight: parseFloat(response.data.weight) || 0,
        issue: parseFloat(response.data.issue) || 0,
        balance_weight: parseFloat(response.data.balance_weight) || 0,
        description: response.data.description || '',
      };
      setViewingProduct(productData);
      setIsViewDialogOpen(true);
    } catch (err) {
      console.error('Error fetching product for view:', err);
      setError('Failed to load product for viewing. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (productToDelete === null) return;
    setLoading(true);
    setError(null);
    try {
      await productAPI.deleteProduct(productToDelete);
      await loadProducts();
      toast({
        title: 'Product deleted successfully!',
        description: `Product with ID ${productToDelete} has been deleted.`,
      });
      setIsConfirmDeleteDialogOpen(false);
      setProductToDelete(null);
    } catch (err) {
      console.error('Error deleting product:', err);
      setError('Failed to delete product. Please try again.');
      toast({
        title: 'Error deleting product',
        description: 'Failed to delete product. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    loadProducts();
  };
  const handleDownloadPDF = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await productAPI.downloadProductsPdf();
        const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'products-report.pdf');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
        toast({
          title: 'Success',
          description: 'PDF downloaded successfully',
        });
      } catch (err: any) {
        const errorMessage = err.response?.data?.error || 'Failed to download PDF';
        toast({
          title: 'Error',
          description: errorMessage,
          variant: 'destructive',
        });
        console.error('Download PDF error:', err);
      } finally {
        setLoading(false);
      }
    };
  

  const filteredProducts = products.filter(
    (p) =>
      p.lot.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.fileno.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-3 sm:space-y-0">
        <h1 className="text-xl sm:text-2xl font-bold">Stock List</h1>
        <div className="flex flex-wrap space-x-2 sm:space-x-3 items-center">
          <div className="relative w-full sm:w-auto">
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </div>
          <Button
            variant="outline"
            onClick={handleDownloadPDF}
            className="px-4 py-2"
            disabled={loading}
          >
            <Download className="h-4 w-4 mr-2" />
            Download Pdf
          </Button>
           <Button
            variant="outline"
            onClick={handleRefresh}
            className="px-4 py-2"
            disabled={loading}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          {allowedActions.includes('create') && (
            <Dialog open={isAddEditDialogOpen} onOpenChange={setIsAddEditDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={resetForm} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 min-w-[160px] justify-center">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Stock
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl">
                <DialogHeader>
                  <DialogTitle>{editingId !== null ? 'Edit Product' : 'Add Product'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleAddOrUpdateProduct} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">* Lot</label>
                      <input
                        name="lot"
                        value={formData.lot}
                        onChange={handleInputChange}
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">* File No</label>
                      <input
                        name="fileno"
                        value={formData.fileno}
                        onChange={handleInputChange}
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Color</label>
                      <input
                        name="color"
                        value={formData.color}
                        onChange={handleInputChange}
                        type="text"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Kind</label>
                      <input
                        name="kind"
                        value={formData.kind}
                        onChange={handleInputChange}
                        type="text"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Mix</label>
                      <input
                        name="mix"
                        value={formData.mix}
                        onChange={handleInputChange}
                        type="text"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">* Balance Unit</label>
                      <input
                        name="balance_unit"
                        value={formData.balance_unit}
                        onChange={handleInputChange}
                        type="number"
                        min="0"
                        step="0.01"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Weight</label>
                      <input
                        name="weight"
                        value={formData.weight}
                        onChange={handleInputChange}
                        type="number"        
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Issue (Adjustment)</label>
                      <input
                        name="issue"
                        value={formData.issue}
                        onChange={handleInputChange}
                        type="number"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">* Balance Weight</label>
                      <input
                        name="balance_weight"
                        value={formData.balance_weight}
                        onChange={handleInputChange}
                        type="number"
                        min="0"
                        step="0.01"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">* Price</label>
                      <input
                        name="price"
                        value={formData.price}
                        onChange={handleInputChange}
                        type="number"
                        step="0.01"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">Description</label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-background text-foreground focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      rows={3}
                    />
                  </div>

                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                      {error}
                    </div>
                  )}

                  <div className="flex justify-end space-x-3">
                    <Button type="button" variant="outline" onClick={() => setIsAddEditDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white" disabled={loading}>
                      <Save className="h-4 w-4 mr-2" />
                      {loading ? 'Saving...' : (editingId !== null ? 'Update' : 'Add') + ' Product'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      {error && !isAddEditDialogOpen && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <Dialog open={isConfirmDeleteDialogOpen} onOpenChange={setIsConfirmDeleteDialogOpen}>
        <DialogContent className="max-w-md rounded-xl">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <div className="py-4 text-center">
            Are you sure you want to delete this stock? This action cannot be undone.
          </div>
          <DialogFooter className="flex justify-end space-x-3">
            <Button
              variant="outline"
              onClick={() => {
                setIsConfirmDeleteDialogOpen(false);
                setProductToDelete(null);
              }}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl rounded-xl">
          <DialogHeader>
            <DialogTitle>Stock Details</DialogTitle>
          </DialogHeader>
          {viewingProduct && (
            <div className="grid grid-cols-1 gap-6 p-4">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold text-gray-900">{viewingProduct.lot}</h2>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Info className="h-5 w-5" />
                  <span className="text-xl font-semibold">RS{viewingProduct.price.toFixed(2)}</span>
                </div>
                <div className="text-sm space-y-1">
                  <p className="flex items-center">
                    <span className="font-medium mr-2">File No:</span>
                    <span className="text-gray-700">{viewingProduct.fileno}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Color:</span>
                    <span className="text-gray-700">{viewingProduct.color || 'N/A'}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Kind:</span>
                    <span className="text-gray-700">{viewingProduct.kind || 'N/A'}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Mix:</span>
                    <span className="text-gray-700">{viewingProduct.mix || 'N/A'}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Balance Unit:</span>
                    <span className="text-gray-700">{viewingProduct.balance_unit.toFixed(2)}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Weight:</span>
                    <span className="text-gray-700">{viewingProduct.weight.toFixed(2)}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Issue (Adjustment):</span>
                    <span className="text-gray-700">{viewingProduct.issue.toFixed(2)}</span>
                  </p>
                  <p className="flex items-center">
                    <span className="font-medium mr-2">Balance Weight:</span>
                    <span className="text-gray-700">{viewingProduct.balance_weight.toFixed(2)}</span>
                  </p>
                  <p className="mt-4">
                    <span className="font-medium block mb-1">Description:</span>
                    <span className="text-gray-700">{viewingProduct.description || 'No description provided.'}</span>
                  </p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setIsViewDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="bg-white rounded-lg border border-border shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto text-left">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Lot</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">File No</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Color</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Kind</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Mix</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Balance Unit</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Weight</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Issue</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Balance Weight</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Price</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Description</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={12} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center">
                      <Grid2x2Plus className="h-12 w-12 mb-2 text-gray-400" />
                      <p className="text-lg font-medium mb-1">No stock yet</p>
                      <p className="text-sm">
                        {allowedActions.includes('create')
                          ? 'Click "Add Stock" to get started'
                          : 'You do not have permission to add stock.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="font-medium text-gray-900">{product.lot}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.fileno}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.color || '—'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.kind || '—'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.mix || '—'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.balance_unit.toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.weight.toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.issue.toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{product.balance_weight.toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">RS{product.price.toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700 truncate block max-w-xs">{product.description || 'N/A'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <div className="flex flex-col sm:flex-row space-y-1 sm:space-y-0 sm:space-x-2">
                        {allowedActions.includes('read') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleView(product.id!)}
                            className="hover:bg-blue-50 text-xs px-2 py-1"
                            disabled={loading}
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                        )}
                        {allowedActions.includes('update') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(product.id!)}
                            className="hover:bg-blue-50 text-xs px-2 py-1"
                            disabled={loading}
                          >
                            <Pencil className="h-3 w-3" />
                          </Button>
                        )}
                        {allowedActions.includes('delete') && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              setProductToDelete(product.id!);
                              setIsConfirmDeleteDialogOpen(true);
                            }}
                            className="border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 text-xs px-2 py-1"
                            disabled={loading}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Products;