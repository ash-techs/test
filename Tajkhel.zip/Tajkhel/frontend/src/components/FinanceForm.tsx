import React, { useState, useEffect } from 'react';
import { transactionsAPI } from '../services/transactions';
import { customerAPI } from '../services/customers';
import { Button } from '@/components/ui/button';
import { Save, Edit, Trash2, Plus, Search, RefreshCw, DollarSign, Calendar, Briefcase, Eye, Loader2, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

export interface Transaction {
  id: string;
  type: 'Income' | 'Expense' | 'Transfer';
  amount: number;
  bank: string;
  checkNumber: string;
  customername: string | null;
  customerid: number | null;
  fromcustomerid: number | null;
  tocustomerid: number | null;
  status: 'Pending' | 'Completed' | 'Cancelled';
  category: string;
  date: string;
  description: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface Customer {
  id: number;
  name: string;
  amount: number;
}

interface ValidationErrors {
  type?: string;
  amount?: string;
  bank?: string;
  category?: string;
  status?: string;
  date?: string;
  customerid?: string;
  fromcustomerid?: string;
  tocustomerid?: string;
}

interface EnumOptions {
  transactionTypes: string[];
  statuses: string[];
  categories: string[];
}

interface FinanceFormProps {
  allowedActions: string[];
}

const LightGlassCard = ({ children, className = '', gradient = false }: { children: React.ReactNode; className?: string; gradient?: boolean }) => (
  <div className={`backdrop-blur-xl bg-white/80 border border-gray-200/50 rounded-2xl shadow-lg ${gradient ? 'bg-gradient-to-br from-white/90 to-gray-50/80' : ''} ${className}`}>
    {children}
  </div>
);

const FinanceForm: React.FC<FinanceFormProps> = ({ allowedActions }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<Transaction>({
    id: '',
    type: 'Income',
    amount: 0,
    bank: '',
    checkNumber: '',
    customername: null,
    customerid: null,
    fromcustomerid: null,
    tocustomerid: null,
    status: 'Pending',
    category: 'Sales',
    date: new Date().toISOString().split('T')[0],
    description: '',
    createdBy: 'Admin',
    createdAt: '',
    updatedAt: '',
  });

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(false);
  const [enumOptions, setEnumOptions] = useState<EnumOptions>({
    transactionTypes: ['Income', 'Expense', 'Transfer'],
    statuses: ['Pending', 'Completed', 'Cancelled'],
    categories: ['Office Supplies', 'Marketing', 'Travel', 'Utilities', 'Salaries', 'Equipment', 'Software', 'Professional Services', 'Sales', 'Rent', 'Payroll', 'Other'],
  });

  const [balance, setBalance] = useState<number | null>(null);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [transactionToView, setTransactionToView] = useState<Transaction | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [apiError, setApiError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchTransactions = async () => {
    setIsRefreshing(true);
    try {
      const response = await transactionsAPI.getTransactions();
      const transactionsData = Array.isArray(response.data) ? response.data : response.data?.data || [];
      if (!Array.isArray(transactionsData)) {
        throw new Error('Expected an array of transactions');
      }
      setTransactions(transactionsData.map((t: Transaction) => {
        // Warn if customer IDs are strings to debug backend issues
        if (t.customerid && typeof t.customerid === 'string') console.warn(`Received string customerid: ${t.customerid}`);
        if (t.fromcustomerid && typeof t.fromcustomerid === 'string') console.warn(`Received string fromcustomerid: ${t.fromcustomerid}`);
        if (t.tocustomerid && typeof t.tocustomerid === 'string') console.warn(`Received string tocustomerid: ${t.tocustomerid}`);
          return {
            ...t,
            customername: t.customername || null,
            customerid: t.customerid !== null && t.customerid !== undefined ? Number(t.customerid) : null,
            fromcustomerid: t.fromcustomerid !== null && t.fromcustomerid !== undefined ? parseInt(String(t.fromcustomerid), 10) : null,
            tocustomerid: t.tocustomerid !== null && t.tocustomerid !== undefined ? parseInt(String(t.tocustomerid), 10) : null,
            amount: t.amount !== null && t.amount !== undefined ? Number(t.amount) : 0,
        };
      }));
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to fetch transactions';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      setTransactions([]);
    } finally {
      setIsRefreshing(false);
    }
  };

  const fetchCustomers = async () => {
    setLoading(true);
    try {
      const response = await customerAPI.getCustomers();
      const customersData = Array.isArray(response.data) ? response.data : response.data?.data || [];
      if (!Array.isArray(customersData)) {
        throw new Error('Expected an array of customers');
      }
      setCustomers(customersData.map((c: Customer) => {
        if (c.id && typeof c.id === 'string') console.warn(`Received string customer id: ${c.id}`);
        return {
          ...c,
          id: c.id,
          amount: Number(c.amount) || 0,
        };
      }));
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to fetch customers';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchEnumOptions = async () => {
    try {
      const response = await transactionsAPI.getEnumOptions();
      if (response.data && response.data.transactionTypes && response.data.statuses && response.data.categories) {
        setEnumOptions({
          transactionTypes: response.data.transactionTypes,
          statuses: response.data.statuses,
          categories: response.data.categories,
        });
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to fetch enum options';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  const fetchBalance = async () => {
    try {
      const response = await transactionsAPI.getBalance();
      if (typeof response.data.balance !== 'number') {
        throw new Error('Expected a numeric balance');
      }
      setBalance(response.data.balance);
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to fetch balance';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      setBalance(null);
    }
  };

  useEffect(() => {
    fetchTransactions();
    fetchCustomers();
    fetchEnumOptions();
    fetchBalance();
  }, []);

  const validateForm = (data: Transaction): ValidationErrors => {
    const newErrors: ValidationErrors = {};

    if (!data.type || !enumOptions.transactionTypes.includes(data.type)) {
      newErrors.type = `Valid transaction type is required (${enumOptions.transactionTypes.join(', ')})`;
    }
    if (!data.amount || isNaN(data.amount) || data.amount <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }
    if (!data.bank || data.bank.trim() === '') {
      newErrors.bank = 'Bank is required';
    }
    if (!data.category || !enumOptions.categories.includes(data.category)) {
      newErrors.category = `Valid category is required (${enumOptions.categories.join(', ')})`;
    }
    if (!data.date || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
      newErrors.date = 'Valid date is required (YYYY-MM-DD)';
    }
    if (!data.status || !enumOptions.statuses.includes(data.status)) {
      newErrors.status = `Valid status is required (${enumOptions.statuses.join(', ')})`;
    }
    if (data.type !== 'Transfer' && data.customerid !== null) {
      const customer = customers.find(c => c.id === data.customerid);
      if (!customer) {
        newErrors.customerid = 'Please select a valid customer';
      } else if (data.type === 'Expense' && data.status === 'Completed' && customer.amount < data.amount) {
        newErrors.amount = 'Insufficient customer balance for expense';
      }
    }
    if (data.type === 'Transfer') {
      if (data.fromcustomerid === null || !customers.find(c => c.id === data.fromcustomerid)) {
        newErrors.fromcustomerid = 'Please select a valid from customer';
      }
      if (data.tocustomerid === null || !customers.find(c => c.id === data.tocustomerid)) {
        newErrors.tocustomerid = 'Please select a valid to customer';
      }
      if (data.fromcustomerid !== null && data.tocustomerid !== null && data.fromcustomerid === data.tocustomerid) {
        newErrors.tocustomerid = 'From and To customers must be different';
      }
      if (data.fromcustomerid !== null && data.status === 'Completed') {
        const fromCustomer = customers.find(c => c.id === data.fromcustomerid);
        if (fromCustomer && fromCustomer.amount < data.amount) {
          newErrors.amount = 'Insufficient balance in from customer';
        }
      }
    }

    return newErrors;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    let parsedValue: any = value;

    if (name === 'amount') {
      parsedValue = value === '' ? 0 : parseFloat(value);
      if (parsedValue !== 0 && (isNaN(parsedValue) || parsedValue <= 0)) {
        setErrors((prev) => ({ ...prev, amount: 'Amount must be greater than 0' }));
      } else {
        setErrors((prev) => ({ ...prev, amount: undefined }));
      }
    } else if (value.trim()) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }

    setFormData((prev) => ({ ...prev, [name]: parsedValue }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => {
      const updated: Transaction = { ...prev };
      if (name === 'type') {
        updated.type = value as 'Income' | 'Expense' | 'Transfer';
        updated.customerid = null;
        updated.customername = null;
        updated.fromcustomerid = null;
        updated.tocustomerid = null;
      } else if (name === 'customerid') {
        if (value === 'none' || !value) {
          updated.customerid = null;
          updated.customername = null;
        } else {
          const customerId = parseInt(value);
          const selectedCustomer = customers.find(c => c.id === customerId);
          updated.customerid = customerId;
          updated.customername = selectedCustomer ? selectedCustomer.name : null;
        }
      } else if (name === 'fromcustomerid') {
        updated.fromcustomerid = (value === 'none' || !value) ? null : parseInt(value);
        updated.customername = null;
      } else if (name === 'tocustomerid') {
        updated.tocustomerid = (value === 'none' || !value) ? null : parseInt(value);
        updated.customername = null;
      } else if (name === 'status') {
        updated.status = value as 'Pending' | 'Completed' | 'Cancelled';
      } else if (name === 'category') {
        updated.category = value;
      }
      return updated;
    });

    setErrors((prev) => ({
      ...prev,
      [name]: undefined,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) {
      toast({
        title: 'Error',
        description: 'Please wait until customer data is loaded',
        variant: 'destructive',
      });
      setIsSaving(false);
      return;
    }
    setApiError(null);
    setIsSaving(true);

    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      setIsSaving(false);
      return;
    }

    try {
      const transactionData: Transaction = {
        ...formData,
        amount: Number(formData.amount) || 0,
        customerid: formData.type !== 'Transfer' ? formData.customerid : null,
        customername: formData.type !== 'Transfer' && formData.customerid !== null ? customers.find(c => c.id === formData.customerid)?.name || null : null,
        fromcustomerid: formData.type === 'Transfer' ? formData.fromcustomerid : null,
        tocustomerid: formData.type === 'Transfer' ? formData.tocustomerid : null,
        checkNumber: formData.checkNumber || '',
        description: formData.description || '',
      };

      if (editingTransaction) {
        await transactionsAPI.updateTransaction(editingTransaction.id, transactionData);
        toast({
          title: 'Success',
          description: 'Transaction updated successfully',
        });
      } else {
        await transactionsAPI.createTransaction(transactionData);
        toast({
          title: 'Success',
          description: 'Transaction created successfully',
        });
      }

      await Promise.all([
        fetchTransactions(),
        fetchBalance(),
        fetchCustomers(),
      ]);
      setShowAddModal(false);
      setEditingTransaction(null);
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to save transaction';
      if (errorMessage.includes('Customer not found')) {
        setErrors((prev) => ({
          ...prev,
          customerid: formData.type !== 'Transfer' ? 'Selected customer does not exist' : undefined,
          fromcustomerid: formData.type === 'Transfer' ? 'From customer does not exist' : undefined,
          tocustomerid: formData.type === 'Transfer' ? 'To customer does not exist' : undefined,
        }));
      } else if (errorMessage.includes('Invalid customer ID')) {
        setErrors((prev) => ({
          ...prev,
          customerid: formData.type !== 'Transfer' ? 'Invalid customer ID format' : undefined,
          fromcustomerid: formData.type === 'Transfer' ? 'Invalid from customer ID format' : undefined,
          tocustomerid: formData.type === 'Transfer' ? 'Invalid to customer ID format' : undefined,
        }));
      }
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const openAddModal = () => {
    setFormData({
      id: '',
      type: 'Income',
      amount: 0,
      bank: '',
      checkNumber: '',
      customername: null,
      customerid: null,
      fromcustomerid: null,
      tocustomerid: null,
      status: 'Pending',
      category: 'Sales',
      date: new Date().toISOString().split('T')[0],
      description: '',
      createdBy: 'Admin',
      createdAt: '',
      updatedAt: '',
    });
    setEditingTransaction(null);
    setErrors({});
    setApiError(null);
    setShowAddModal(true);
  };

  const openEditModal = (transaction: Transaction) => {
    const customer = transaction.customerid !== null ? customers.find(c => c.id === transaction.customerid) : null;
    if (transaction.customerid !== null && !customer) {
      console.warn(`Customer with ID ${transaction.customerid} not found for transaction ${transaction.id}`);
    }
    const fromCustomer = transaction.fromcustomerid !== null ? customers.find(c => c.id === transaction.fromcustomerid) : null;
    if (transaction.fromcustomerid !== null && !fromCustomer) {
      console.warn(`From customer with ID ${transaction.fromcustomerid} not found for transaction ${transaction.id}`);
    }
    const toCustomer = transaction.tocustomerid !== null ? customers.find(c => c.id === transaction.tocustomerid) : null;
    if (transaction.tocustomerid !== null && !toCustomer) {
      console.warn(`To customer with ID ${transaction.tocustomerid} not found for transaction ${transaction.id}`);
    }

    setFormData({
      ...transaction,
      customername: customer ? customer.name : null,
      customerid: transaction.customerid !== null ? parseInt(String(transaction.customerid)) : null,
      fromcustomerid: transaction.fromcustomerid !== null ? parseInt(String(transaction.fromcustomerid)) : null,
      tocustomerid: transaction.tocustomerid !== null ? parseInt(String(transaction.tocustomerid)) : null,
      amount: Number(transaction.amount) || 0,
    });
    setEditingTransaction(transaction);
    setErrors({});
    setApiError(null);
    setShowAddModal(true);
  };

  const openViewModal = (transaction: Transaction) => {
    setTransactionToView(transaction);
    setShowViewModal(true);
  };

  const confirmDelete = async () => {
    if (!transactionToDelete) return;
    setIsDeleting(true);
    try {
      await transactionsAPI.deleteTransaction(transactionToDelete);
      toast({
        title: 'Success',
        description: 'Transaction deleted successfully',
      });
      await Promise.all([
        fetchTransactions(),
        fetchBalance(),
        fetchCustomers(),
      ]);
      setShowDeleteConfirm(false);
      setTransactionToDelete(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to delete transaction';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredTransactions = transactions.filter((t) =>
    (t.customername || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (t.description || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (t.fromcustomerid !== null ? customers.find(c => c.id === t.fromcustomerid)?.name?.toLowerCase().includes(searchTerm.toLowerCase()) : false) ||
    (t.tocustomerid !== null ? customers.find(c => c.id === t.tocustomerid)?.name?.toLowerCase().includes(searchTerm.toLowerCase()) : false)
  );

  const handleDownloadPDF = async () => {
    try {
      const response = await transactionsAPI.downloadTransactionsPDF();
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'finance-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to download PDF report';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <LightGlassCard gradient className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Financial Transactions</h2>
          <div className="flex space-x-2 mt-4 sm:mt-0">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                className="pl-10 w-64"
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            {allowedActions.includes('create') && (
              <Button onClick={openAddModal} disabled={loading}>
                <Plus className="h-4 w-4 mr-2" /> Add Transaction
              </Button>
            )}
            <Button variant="outline" onClick={fetchTransactions} disabled={isRefreshing}>
              {isRefreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            </Button>
            <Button onClick={handleDownloadPDF}>
              <Download className="h-4 w-4 mr-2" /> Download PDF
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <LightGlassCard className="p-4">
            <div className="flex items-center">
              <DollarSign className="h-6 w-6 text-blue-500 mr-2" />
              <div>
                <p className="text-sm text-gray-500">Total Balance</p>
                <p className="text-xl font-semibold">{balance !== null ? `RS ${balance.toFixed(2)}` : 'N/A'}</p>
              </div>
            </div>
          </LightGlassCard>
          <LightGlassCard className="p-4">
            <div className="flex items-center">
              <Calendar className="h-6 w-6 text-green-500 mr-2" />
              <div>
                <p className="text-sm text-gray-500">Last Transaction</p>
                <p className="text-xl font-semibold">{transactions[0]?.date ? new Date(transactions[0].date).toLocaleDateString() : 'N/A'}</p>
              </div>
            </div>
          </LightGlassCard>
          <LightGlassCard className="p-4">
            <div className="flex items-center">
              <Briefcase className="h-6 w-6 text-purple-500 mr-2" />
              <div>
                <p className="text-sm text-gray-500">Total Transactions</p>
                <p className="text-xl font-semibold">{transactions.length}</p>
              </div>
            </div>
          </LightGlassCard>
        </div>

        {loading ? (
          <div className="text-center py-4">
            <Loader2 className="h-6 w-6 animate-spin mx-auto" />
            <p>Loading transactions...</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bank</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredTransactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">{transaction.type}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{transaction.category}</td>
                    <td className="px-6 py-4">{transaction.description || 'N/A'}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{transaction.bank}</td>
                    <td className="px-6 py-4 whitespace-nowrap">RS {Number(transaction.amount).toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{transaction.status}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {transaction.type === 'Transfer'
                        ? `From: ${customers.find(c => c.id === transaction.fromcustomerid)?.name || 'N/A'} To: ${customers.find(c => c.id === transaction.tocustomerid)?.name || 'N/A'}`
                        : transaction.customername || 'N/A'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{new Date(transaction.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" onClick={() => openViewModal(transaction)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        {allowedActions.includes('update') && (
                          <Button variant="outline" size="sm" onClick={() => openEditModal(transaction)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {allowedActions.includes('delete') && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setTransactionToDelete(transaction.id);
                              setShowDeleteConfirm(true);
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </LightGlassCard>

      <Dialog open={showAddModal} onOpenChange={(isOpen) => {
        setShowAddModal(isOpen);
        if (!isOpen) {
          setEditingTransaction(null);
          setFormData({
            id: '',
            type: 'Income',
            amount: 0,
            bank: '',
            checkNumber: '',
            customername: null,
            customerid: null,
            fromcustomerid: null,
            tocustomerid: null,
            status: 'Pending',
            category: 'Sales',
            date: new Date().toISOString().split('T')[0],
            description: '',
            createdBy: 'Admin',
            createdAt: '',
            updatedAt: '',
          });
          setErrors({});
          setApiError(null);
        }
      }}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle>{editingTransaction ? 'Edit Transaction' : 'Add Transaction'}</DialogTitle>
            </DialogHeader>
            {loading ? (
              <div className="text-center py-4">
                <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                <p>Loading customers...</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Type</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value) => handleSelectChange('type', value)}
                  >
                    <SelectTrigger className={`col-span-3 ${errors.type ? 'border-red-500 bg-red-50' : ''}`}>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {enumOptions.transactionTypes.map((type) => (
                        <SelectItem key={type} value={type}>{type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.type && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.type}</p>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Amount</Label>
                  <Input
                    name="amount"
                    type="number"
                    step="0.01"
                    value={formData.amount || ''}
                    onChange={handleInputChange}
                    className={`col-span-3 ${errors.amount ? 'border-red-500 bg-red-50' : ''}`}
                    placeholder="Enter amount"
                  />
                  {errors.amount && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.amount}</p>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Bank</Label>
                  <Input
                    name="bank"
                    value={formData.bank}
                    onChange={handleInputChange}
                    className={`col-span-3 ${errors.bank ? 'border-red-500 bg-red-50' : ''}`}
                    placeholder="Enter bank name"
                  />
                  {errors.bank && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.bank}</p>
                  )}
                </div>
                {formData.type === 'Transfer' ? (
                  <>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">* From Customer</Label>
                      <Select
                        value={formData.fromcustomerid?.toString() || 'none'}
                        onValueChange={(value) => handleSelectChange('fromcustomerid', value)}
                        disabled={loading || customers.length === 0}
                      >
                        <SelectTrigger id="fromcustomerid" className={`col-span-3 ${errors.fromcustomerid ? 'border-red-500 bg-red-50' : ''}`}>
                          <SelectValue placeholder={customers.length === 0 ? 'No customers available' : 'Select from customer'} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Select a customer</SelectItem>
                          {customers.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id.toString()}>
                              {customer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.fromcustomerid && (
                        <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.fromcustomerid}</p>
                      )}
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label className="text-right">* To Customer</Label>
                      <Select
                        value={formData.tocustomerid?.toString() || 'none'}
                        onValueChange={(value) => handleSelectChange('tocustomerid', value)}
                        disabled={loading || customers.length === 0}
                      >
                        <SelectTrigger id="tocustomerid" className={`col-span-3 ${errors.tocustomerid ? 'border-red-500 bg-red-50' : ''}`}>
                          <SelectValue placeholder={customers.length === 0 ? 'No customers available' : 'Select to customer'} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Select a customer</SelectItem>
                          {customers.map((customer) => (
                            <SelectItem key={customer.id} value={customer.id.toString()}>
                              {customer.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.tocustomerid && (
                        <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.tocustomerid}</p>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label className="text-right">Customer</Label>
                    <Select
                      value={formData.customerid?.toString() || 'none'}
                      onValueChange={(value) => handleSelectChange('customerid', value)}
                      disabled={loading || customers.length === 0}
                    >
                      <SelectTrigger id="customerid" className={`col-span-3 ${errors.customerid ? 'border-red-500 bg-red-50' : ''}`}>
                        <SelectValue placeholder={customers.length === 0 ? 'No customers available' : 'Select customer (optional)'} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {customers.map((customer) => (
                          <SelectItem key={customer.id} value={customer.id.toString()}>
                            {customer.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.customerid && (
                      <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.customerid}</p>
                    )}
                  </div>
                )}
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Category</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => handleSelectChange('category', value)}
                  >
                    <SelectTrigger className={`col-span-3 ${errors.category ? 'border-red-500 bg-red-50' : ''}`}>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {enumOptions.categories.map((category) => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.category && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.category}</p>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Date</Label>
                  <Input
                    name="date"
                    type="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className={`col-span-3 ${errors.date ? 'border-red-500 bg-red-50' : ''}`}
                    placeholder="Select date"
                  />
                  {errors.date && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.date}</p>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">* Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => handleSelectChange('status', value)}
                  >
                    <SelectTrigger className={`col-span-3 ${errors.status ? 'border-red-500 bg-red-50' : ''}`}>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {enumOptions.statuses.map((status) => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.status && (
                    <p className="col-span-4 text-red-500 text-xs ml-auto">{errors.status}</p>
                  )}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Check Number</Label>
                  <Input
                    name="checkNumber"
                    value={formData.checkNumber}
                    onChange={handleInputChange}
                    className="col-span-3"
                    placeholder="Enter check number (optional)"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Description</Label>
                  <Input
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="col-span-3"
                    placeholder="Enter description (optional)"
                  />
                </div>
                {apiError && (
                  <div className="col-span-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                    {apiError}
                  </div>
                )}
                <div className="flex justify-end space-x-3">
                  <Button type="button" variant="outline" onClick={() => setShowAddModal(false)} disabled={isSaving}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSaving || loading}>
                    {isSaving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
                    {editingTransaction ? 'Update' : 'Save'} Transaction
                  </Button>
                </div>
              </form>
            )}
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      <Dialog open={showViewModal} onOpenChange={setShowViewModal}>
        <DialogContent className="sm:max-w-[600px]">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle>Transaction Details</DialogTitle>
            </DialogHeader>
            {transactionToView && (
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Transaction ID</h4>
                    <p className="text-lg text-gray-900">{transactionToView.id}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Type</h4>
                    <p className="text-lg text-gray-900">{transactionToView.type}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Amount</h4>
                    <p className="text-lg text-gray-900">RS {Number(transactionToView.amount).toFixed(2)}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Bank</h4>
                    <p className="text-lg text-gray-900">{transactionToView.bank || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Customer</h4>
                    <p className="text-lg text-gray-900">
                      {transactionToView.type === 'Transfer'
                        ? `From: ${customers.find(c => c.id === transactionToView.fromcustomerid)?.name || 'N/A'} To: ${customers.find(c => c.id === transactionToView.tocustomerid)?.name || 'N/A'}`
                        : transactionToView.customername || 'N/A'}
                    </p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Category</h4>
                    <p className="text-lg text-gray-900">{transactionToView.category}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Date</h4>
                    <p className="text-lg text-gray-900">{new Date(transactionToView.date).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Status</h4>
                    <p className="text-lg text-gray-900">{transactionToView.status}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Check Number</h4>
                    <p className="text-lg text-gray-900">{transactionToView.checkNumber || 'N/A'}</p>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-500">Description</h4>
                    <p className="text-lg text-gray-900">{transactionToView.description || 'N/A'}</p>
                  </div>
                </div>
              </div>
            )}
            <DialogFooter className="flex justify-end">
              <Button onClick={() => setShowViewModal(false)}>Close</Button>
            </DialogFooter>
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="sm:max-w-md">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle>Confirm Deletion</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <p>Are you sure you want to delete this transaction? This action cannot be undone.</p>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setShowDeleteConfirm(false)}
                  disabled={isDeleting}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={confirmDelete}
                  disabled={isDeleting}
                >
                  {isDeleting ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Trash2 className="h-4 w-4 mr-2" />}
                  Delete
                </Button>
              </div>
            </div>
          </LightGlassCard>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FinanceForm;