import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Save, Plus, RefreshCw, Edit, Trash2, Search, Download, Grid2x2Plus, Eye, AlertCircle, Calculator } from 'lucide-react';
import { invoiceAPI } from '../services/invoices';
import { productAPI } from '../services/products';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface Product {
  id: number;
  fileno: string;
  weight: number;
  lot: string;
  balance_unit: number;
  balance_weight: number;
  // Enhanced for better lookup
  name?: string;
  description?: string;
  category?: string;
}

interface InvoiceItem {
  id?: number;
  productId: number;
  productName: string;
  productLot: string;
  productFileno: string;
  weight: number;
  balanceUnits: number;
  balanceWeight: number;
  unitPrice: number;
  discount: string;
  amount: number;
}

interface InvoiceData {
  id?: number;
  number: string;
  customer: string;
  email: string;
  address: string;
  phone: string;
  date: string;
  expireDate: string;
  year: string;
  currency: string;
  status: 'DRAFT' | 'PENDING' | 'UNPAID' | 'OVERDUE' | 'PARTIALLY_PAID' | 'PAID';
  note: string;
  items: InvoiceItem[];
  createdBy: string;
  tax?: number;
  total: number;
  paid?: number;
}

interface ValidationErrors {
  number?: string;
  customer?: string;
  email?: string;
  address?: string;
  phone?: string;
  date?: string;
  expireDate?: string;
  year?: string;
  currency?: string;
  items?: string;
  tax?: string;
  paid?: string;
  [key: string]: string | undefined;
}

interface InvoicesProps {
  allowedActions: string[];
}

const discounts = ['NO_DISCOUNT', 'FIVE_PERCENT', 'TEN_PERCENT', 'FIFTEEN_PERCENT'];

// Enhanced product search and filter functionality
const useProductSearch = (products: Product[], searchTerm: string) => {
  return useMemo(() => {
    if (!searchTerm.trim()) return products;
    
    const term = searchTerm.toLowerCase();
    return products.filter(product => 
      product.id.toString().includes(term) ||
      product.fileno.toLowerCase().includes(term) ||
      product.lot.toLowerCase().includes(term) ||
      (product.name && product.name.toLowerCase().includes(term)) ||
      (product.description && product.description.toLowerCase().includes(term)) ||
      (product.category && product.category.toLowerCase().includes(term))
    );
  }, [products, searchTerm]);
};

const Invoices: React.FC<InvoicesProps> = ({ allowedActions }) => {
  const { toast } = useToast();
  const [invoices, setInvoices] = useState<InvoiceData[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [productSearchTerms, setProductSearchTerms] = useState<{ [key: number]: string }>({});
  const [newInvoice, setNewInvoice] = useState<InvoiceData>({
    number: '',
    customer: '',
    email: '',
    address: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    expireDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    year: new Date().getFullYear().toString(),
    currency: 'PKR',
    status: 'DRAFT',
    note: '',
    items: [{ productId: 0, productName: '', productLot: '', productFileno: '', weight: 0, balanceUnits: 0, balanceWeight: 0, unitPrice: 0, discount: 'NO_DISCOUNT', amount: 0 }],
    createdBy: 'Admin',
    tax: 0,
    paid: 0,
    total: 0,
  });
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [invoiceToDelete, setInvoiceToDelete] = useState<number | null>(null);
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceData | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [visibleInvoices, setVisibleInvoices] = useState(10);
  const [loading, setLoading] = useState(false);
  const [downloadLoading, setDownloadLoading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [errors, setErrors] = useState<ValidationErrors>({});

  useEffect(() => {
    if (allowedActions.includes('read')) {
      loadInvoices();
      loadProducts();
    } else {
      toast({
        title: 'Error',
        description: 'You are not authorized to read invoices',
        variant: 'destructive',
      });
    }

    const table = document.querySelector('.invoice-table-container');
    if (table) {
      table.addEventListener('scroll', handleScroll);
      return () => table.removeEventListener('scroll', handleScroll);
    }
  }, [allowedActions]);

  const loadProducts = async () => {
    setLoading(true);
    try {
      const response = await productAPI.getProducts();
      setProducts(Array.isArray(response.data) ? response.data : []);
    } catch (err: any) {
      setError('Failed to load products. Please check the server connection.');
      toast({ title: 'Error', description: 'Failed to load products.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleScroll = () => {
    const table = document.querySelector('.invoice-table-container');
    if (table) {
      const { scrollTop, scrollHeight, clientHeight } = table;
      if (scrollTop + clientHeight >= scrollHeight - 20) {
        setVisibleInvoices(prev => prev + 10);
      }
    }
  };

  const calculateStatus = (invoice: InvoiceData): InvoiceData['status'] => {
    const total = invoice.total;
    const paid = invoice.paid || 0;
    const isExpired = new Date(invoice.expireDate) < new Date();
    const userSelectedStatus = invoice.status;

    if (paid > total) {
      throw new Error('Paid amount cannot be greater than total invoice amount');
    }

    if (paid >= total && total > 0) {
      return 'PAID';
    }

    if (paid > 0 && paid < total) {
      return 'PARTIALLY_PAID';
    }

    const normalizedStatus = typeof userSelectedStatus === 'string'
      ? userSelectedStatus.toUpperCase()
      : 'UNPAID';

    if (isExpired && ['DRAFT', 'PENDING', 'UNPAID'].includes(normalizedStatus)) {
      return 'OVERDUE';
    }

    if (['DRAFT', 'PENDING', 'UNPAID'].includes(normalizedStatus)) {
      return normalizedStatus as InvoiceData['status'];
    }

    console.warn(`Unexpected invoice status: ${userSelectedStatus}, defaulting to UNPAID`);
    return 'UNPAID';
  };

  const getStatusBadgeProps = (status: InvoiceData['status']) => {
    const statusConfig = {
      'PAID': { variant: 'default' as const, className: 'bg-green-100 text-green-800 hover:bg-green-200' },
      'PARTIALLY_PAID': { variant: 'secondary' as const, className: 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200' },
      'OVERDUE': { variant: 'destructive' as const, className: 'bg-red-100 text-red-800 hover:bg-red-200' },
      'UNPAID': { variant: 'destructive' as const, className: 'bg-red-100 text-red-800 hover:bg-red-200' },
      'PENDING': { variant: 'outline' as const, className: 'bg-orange-100 text-orange-800 hover:bg-orange-200' },
      'DRAFT': { variant: 'outline' as const, className: 'bg-gray-100 text-gray-800 hover:bg-gray-200' },
    };
    return statusConfig[status] || statusConfig['UNPAID'];
  };

  const loadInvoices = async () => {
    if (!allowedActions.includes('read')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to read invoices',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const response = await invoiceAPI.getInvoices();

      if (!Array.isArray(response.data)) {
        console.error('Invalid response: Expected an array, got:', response.data);
        throw new Error('Expected an array of invoices');
      }

      const updatedInvoices = response.data.map(invoice => {
        try {
          const status = calculateStatus(invoice);
          return {
            ...invoice,
            id: invoice.id ? Number(invoice.id) : undefined,
            year: String(invoice.year ?? new Date().getFullYear()),
            tax: parseFloat(invoice.tax?.toString() ?? '0') || 0,
            paid: parseFloat(invoice.paid?.toString() ?? '0') || 0,
            items: invoice.items.map(item => ({
              ...item,
              id: item.id ? Number(item.id) : undefined,
              productId: Number(item.productId),
              weight: parseFloat(item.weight?.toString() ?? '0') || 0,
              balanceUnits: parseInt(item.balanceUnits?.toString() ?? '0') || 0,
              balanceWeight: parseFloat(item.balanceWeight?.toString() ?? '0') || 0,
              unitPrice: parseFloat(item.unitPrice?.toString() ?? '0') || 0,
              amount: parseFloat(item.amount?.toString() ?? '0') || 0,
            })),
            status,
          };
        } catch (err) {
          console.error('Error processing invoice:', invoice, err);
          return null;
        }
      }).filter((invoice): invoice is InvoiceData => invoice !== null);

      setInvoices(updatedInvoices);

      if (updatedInvoices.length === 0) {
        setError('No invoices found');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to load invoices';
      console.error('Load invoices error:', err, 'Response:', err.response);
      setError(errorMessage);
      setInvoices([]);
      if (errorMessage !== 'No invoices found') {
        toast({
          title: 'Error',
          description: errorMessage,
          variant: 'destructive',
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setNewInvoice({
      ...newInvoice,
      [name]: name === 'tax' || name === 'paid' ? parseFloat(value) || 0 : value,
    });
    setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  const handleItemChange = (index: number, e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const updatedItems = [...newInvoice.items];
    const { name, value } = e.target;
    updatedItems[index] = {
      ...updatedItems[index],
      [name]: name === 'weight' || name === 'balanceUnits' || name === 'unitPrice'
        ? parseFloat(value) || 0
        : name === 'productId'
        ? Number(value)
        : value,
    };

    if (name === 'productId') {
      const product = products.find(p => p.id === Number(value));
      if (product) {
        updatedItems[index] = {
          ...updatedItems[index],
          productName: product.name || `Product #${product.id}`,
          productLot: product.lot,
          productFileno: product.fileno,
          weight: product.weight,
          balanceUnits: updatedItems[index].balanceUnits || 1,
        };
      }
    }

    const weight = updatedItems[index].weight;
    const balanceUnits = updatedItems[index].balanceUnits;
    const unitPrice = updatedItems[index].unitPrice;
    const discount = updatedItems[index].discount || 'NO_DISCOUNT';
    const discountPercentage = discounts.includes(discount) ? {
      'NO_DISCOUNT': 0,
      'FIVE_PERCENT': 0.05,
      'TEN_PERCENT': 0.10,
      'FIFTEEN_PERCENT': 0.15
    }[discount] : 0;
    const baseAmount = (weight * balanceUnits / 45) * unitPrice;
    updatedItems[index].balanceWeight = weight * balanceUnits;
    updatedItems[index].amount = baseAmount * (1 - discountPercentage);

    setNewInvoice({ ...newInvoice, items: updatedItems });
    setErrors(prev => ({
      ...prev,
      [`productId_${index}`]: undefined,
      [`weight_${index}`]: undefined,
      [`balanceUnits_${index}`]: undefined,
      [`unitPrice_${index}`]: undefined,
    }));
  };

  const addItem = () => {
    setNewInvoice({
      ...newInvoice,
      items: [...newInvoice.items, { 
        productId: 0, 
        productName: '', 
        productLot: '', 
        productFileno: '', 
        weight: 0, 
        balanceUnits: 0, 
        balanceWeight: 0, 
        unitPrice: 0, 
        discount: 'NO_DISCOUNT', 
        amount: 0 
      }],
    });
  };

  const removeItem = (index: number) => {
    const updatedItems = newInvoice.items.filter((_, i) => i !== index);
    setNewInvoice({ ...newInvoice, items: updatedItems });
    // Clean up search term for removed item
    setProductSearchTerms(prev => {
      const newTerms = { ...prev };
      delete newTerms[index];
      return newTerms;
    });
  };

  const calculateSubtotal = () => {
    return newInvoice.items.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
  };

  const calculateTotal = (invoice?: InvoiceData) => {
    const targetInvoice = invoice || newInvoice;
    const subtotal = targetInvoice.items.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
    const discountAmount = targetInvoice.items.reduce((sum, item) => {
      const discountPercentage = discounts.includes(item.discount) ? {
        'NO_DISCOUNT': 0,
        'FIVE_PERCENT': 0.05,
        'TEN_PERCENT': 0.10,
        'FIFTEEN_PERCENT': 0.15
      }[item.discount] : 0;
      return sum + ((item.weight * item.balanceUnits / 45) * item.unitPrice * discountPercentage);
    }, 0);
    const taxAmount = targetInvoice.tax ? subtotal * (targetInvoice.tax / 100) : 0;
    return subtotal - discountAmount + taxAmount;
  };

  const calculateOutstanding = (invoice?: InvoiceData) => {
    const targetInvoice = invoice || newInvoice;
    const total = calculateTotal(targetInvoice);
    return total - (targetInvoice.paid || 0);
  };

  const validateInvoice = (invoice: InvoiceData): ValidationErrors => {
    const errors: ValidationErrors = {};
    if (!invoice.number.trim()) errors.number = 'Invoice number is required';
    if (!invoice.customer.trim()) errors.customer = 'Customer is required';
    if (invoice.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(invoice.email)) {
      errors.email = 'Invalid email format';
    }
    if (!invoice.address.trim()) errors.address = 'Address is required';
    if (!invoice.phone.trim()) errors.phone = 'Phone is required';
    if (!invoice.date) errors.date = 'Issue date is required';
    if (!invoice.expireDate) errors.expireDate = 'Due date is required';
    if (!invoice.year || isNaN(parseInt(invoice.year)) || parseInt(invoice.year) < 2000 || parseInt(invoice.year) > new Date().getFullYear() + 1) {
      errors.year = 'Enter a valid year';
    }
    if (!invoice.currency) errors.currency = 'Currency is required';
    if (invoice.tax && (invoice.tax < 0 || invoice.tax > 100)) {
      errors.tax = 'Tax must be between 0 and 100%';
    }
    if (invoice.paid && invoice.paid < 0) {
      errors.paid = 'Paid amount must be a positive number';
    }
    if (invoice.items.length === 0) errors.items = 'At least one item is required';
    invoice.items.forEach((item, index) => {
      if (!item.productId || !products.find(p => p.id === item.productId)) {
        errors[`productId_${index}`] = `Valid product is required for item ${index + 1}`;
      }
      if (item.weight <= 0) errors[`weight_${index}`] = `Weight must be greater than 0 for item ${index + 1}`;
      if (item.balanceUnits <= 0) errors[`balanceUnits_${index}`] = `Balance units must be greater than 0 for item ${index + 1}`;
      else {
        const product = products.find(p => p.id === item.productId);
        if (product && item.balanceUnits > product.balance_unit) {
          errors[`balanceUnits_${index}`] = `Balance units cannot exceed available units (${product.balance_unit}) for item ${index + 1}`;
        }
      }
      if (item.unitPrice <= 0) errors[`unitPrice_${index}`] = `Unit price must be greater than 0 for item ${index + 1}`;
    });
    return errors;
  };

  const handleSave = async () => {
    if (!allowedActions.includes(editingId ? 'update' : 'create')) {
      toast({
        title: 'Error',
        description: `You are not authorized to ${editingId ? 'update' : 'create'} invoices`,
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const validationErrors = validateInvoice(newInvoice);
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        toast({
          title: 'Error',
          description: 'Please correct the form errors',
          variant: 'destructive',
        });
        return;
      }

      const total = calculateTotal();
      const finalStatus = calculateStatus({ ...newInvoice, total });

      const invoiceToSave = {
        ...newInvoice,
        year: newInvoice.year.toString(),
        tax: parseFloat(newInvoice.tax?.toString()) || 0,
        paid: parseFloat(newInvoice.paid?.toString()) || 0,
        status: finalStatus,
        items: newInvoice.items.map(item => ({
          ...item,
          productId: Number(item.productId),
          weight: parseFloat(item.weight.toString()),
          balanceUnits: parseInt(item.balanceUnits.toString()),
          balanceWeight: parseFloat(item.balanceWeight.toString()),
          unitPrice: parseFloat(item.unitPrice.toString()),
          amount: parseFloat(item.amount.toString()),
        })),
      };

      if (editingId) {
        await invoiceAPI.updateInvoice(editingId, invoiceToSave);
      } else {
        await invoiceAPI.createInvoice(invoiceToSave);
      }

      await loadInvoices();
      setOpen(false);
      setEditingId(null);
      setNewInvoice({
        number: '',
        customer: '',
        email: '',
        address: '',
        phone: '',
        date: new Date().toISOString().split('T')[0],
        expireDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        year: new Date().getFullYear().toString(),
        currency: 'PKR',
        status: 'DRAFT',
        note: '',
        items: [{ productId: 0, productName: '', productLot: '', productFileno: '', weight: 0, balanceUnits: 0, balanceWeight: 0, unitPrice: 0, discount: 'NO_DISCOUNT', amount: 0 }],
        createdBy: 'Admin',
        tax: 0,
        paid: 0,
        total: 0,
      });
      setErrors({});
      setProductSearchTerms({});
      toast({
        title: 'Success',
        description: `Invoice ${editingId ? 'updated' : 'created'} successfully`,
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to save invoice';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (invoice: InvoiceData) => {
    if (!allowedActions.includes('update')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to update invoices',
        variant: 'destructive',
      });
      return;
    }
    setEditingId(Number(invoice.id));
    setNewInvoice({
      ...invoice,
      date: new Date(invoice.date).toISOString().split('T')[0],
      expireDate: new Date(invoice.expireDate).toISOString().split('T')[0],
      year: invoice.year.toString(),
      tax: parseFloat(invoice.tax?.toString()) || 0,
      paid: parseFloat(invoice.paid?.toString()) || 0,
      items: invoice.items.map(item => ({
        ...item,
        productId: Number(item.productId),
        weight: parseFloat(item.weight.toString()),
        balanceUnits: parseInt(item.balanceUnits.toString()),
        balanceWeight: parseFloat(item.balanceWeight.toString()),
        unitPrice: parseFloat(item.unitPrice.toString()),
        amount: parseFloat(item.amount.toString()),
      })),
    });
    setOpen(true);
  };

  const handleDelete = async () => {
    if (!allowedActions.includes('delete')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to delete invoices',
        variant: 'destructive',
      });
      return;
    }
    if (!invoiceToDelete) return;

    setLoading(true);
    try {
      await invoiceAPI.deleteInvoice(invoiceToDelete);
      await loadInvoices();
      setDeleteOpen(false);
      setInvoiceToDelete(null);
      toast({
        title: 'Success',
        description: 'Invoice deleted successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to delete invoice';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleView = (invoice: InvoiceData) => {
    setSelectedInvoice(invoice);
    setViewOpen(true);
  };

  const handleDownloadPDF = async (id: number) => {
    setDownloadLoading(id);
    try {
      const response = await invoiceAPI.downloadPDFById(id);
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `invoice-${id}.pdf`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setDownloadLoading(null);
    }
  };

  const handleDownloadAllPDF = async () => {
    setDownloadLoading(-1);
    try {
      const response = await invoiceAPI.downloadInvoicesPDF();
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'invoices-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || err.message || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setDownloadLoading(null);
    }
  };

  const filteredInvoices = invoices.filter(invoice =>
    invoice.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.customer.toLowerCase().includes(searchTerm.toLowerCase())
  ).slice(0, visibleInvoices);

  // Enhanced product search component
  const ProductSearchSelect = ({ index, item }: { index: number; item: InvoiceItem }) => {
    const searchTerm = productSearchTerms[index] || '';
    const filteredProducts = useProductSearch(products, searchTerm);
    
    return (
      <div>
        <Label htmlFor={`productId_${index}`}>Product</Label>
        <div className="space-y-2">
          <Input
            placeholder="Search products by ID, File No, Lot..."
            value={searchTerm}
            onChange={(e) => setProductSearchTerms(prev => ({ ...prev, [index]: e.target.value }))}
            className="mb-2"
          />
          <Select
            name="productId"
            value={item.productId.toString()}
            onValueChange={(value) => {
              handleItemChange(index, { target: { name: 'productId', value } } as any);
              // Clear search term when product is selected
              setProductSearchTerms(prev => ({ ...prev, [index]: '' }));
            }}
          >
            <SelectTrigger className={errors[`productId_${index}`] ? 'border-red-500' : ''}>
              <SelectValue placeholder="Select product" />
            </SelectTrigger>
            <SelectContent>
              {filteredProducts.slice(0, 10).map(product => (
                <SelectItem key={product.id} value={product.id.toString()}>
                  <div className="flex flex-col">
                    <div className="font-medium">
                      Product #{product.id} {product.name && `- ${product.name}`}
                    </div>
                    <div className="text-sm text-gray-500">
                      Lot: {product.lot} | File: {product.fileno} | Available: {product.balance_unit} units
                    </div>
                  </div>
                </SelectItem>
              ))}
              {filteredProducts.length > 10 && (
                <SelectItem value="more" disabled>
                  ... {filteredProducts.length - 10} more results
                </SelectItem>
              )}
              {filteredProducts.length === 0 && searchTerm && (
                <SelectItem value="no-results" disabled>
                  No products found
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
        {errors[`productId_${index}`] && <p className="text-red-500 text-sm">{errors[`productId_${index}`]}</p>}
      </div>
    );
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Invoices</h1>
        <div className="flex space-x-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search invoices..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-8 w-64"
            />
          </div>
          {allowedActions.includes('create') && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => {
                  setEditingId(null);
                  setNewInvoice({
                    number: '',
                    customer: '',
                    email: '',
                    address: '',
                    phone: '',
                    date: new Date().toISOString().split('T')[0],
                    expireDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                    year: new Date().getFullYear().toString(),
                    currency: 'PKR',
                    status: 'DRAFT',
                    note: '',
                    items: [{ productId: 0, productName: '', productLot: '', productFileno: '', weight: 0, balanceUnits: 0, balanceWeight: 0, unitPrice: 0, discount: 'NO_DISCOUNT', amount: 0 }],
                    createdBy: 'Admin',
                    tax: 0,
                    paid: 0,
                    total: 0,
                  });
                  setErrors({});
                  setProductSearchTerms({});
                }}>
                  <Plus className="mr-2 h-4 w-4" /> Create Invoice
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingId ? 'Edit Invoice' : 'Create Invoice'}</DialogTitle>
                </DialogHeader>
                
                {/* Status Auto-calculation Alert */}
                <Alert className="mb-4">
                  <Calculator className="h-4 w-4" />
                  <AlertDescription>
                    Invoice status will be automatically calculated based on payment amount, due date, and current date. 
                    Balance calculations are also automatic based on product weight and units.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="number">Invoice Number</Label>
                    <Input
                      id="number"
                      name="number"
                      value={newInvoice.number}
                      onChange={handleChange}
                      className={errors.number ? 'border-red-500' : ''}
                    />
                    {errors.number && <p className="text-red-500 text-sm">{errors.number}</p>}
                  </div>
                  <div>
                    <Label htmlFor="customer">Customer</Label>
                    <Input
                      id="customer"
                      name="customer"
                      value={newInvoice.customer}
                      onChange={handleChange}
                      className={errors.customer ? 'border-red-500' : ''}
                    />
                    {errors.customer && <p className="text-red-500 text-sm">{errors.customer}</p>}
                  </div>
                  <div>
                    <Label htmlFor="email">Email (Optional)</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={newInvoice.email}
                      onChange={handleChange}
                      className={errors.email ? 'border-red-500' : ''}
                    />
                    {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      name="address"
                      value={newInvoice.address}
                      onChange={handleChange}
                      className={errors.address ? 'border-red-500' : ''}
                    />
                    {errors.address && <p className="text-red-500 text-sm">{errors.address}</p>}
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={newInvoice.phone}
                      onChange={handleChange}
                      className={errors.phone ? 'border-red-500' : ''}
                    />
                    {errors.phone && <p className="text-red-500 text-sm">{errors.phone}</p>}
                  </div>
                  <div>
                    <Label htmlFor="date">Issue Date</Label>
                    <Input
                      id="date"
                      name="date"
                      type="date"
                      value={newInvoice.date}
                      onChange={handleChange}
                      className={errors.date ? 'border-red-500' : ''}
                    />
                    {errors.date && <p className="text-red-500 text-sm">{errors.date}</p>}
                  </div>
                  <div>
                    <Label htmlFor="expireDate">Due Date</Label>
                    <Input
                      id="expireDate"
                      name="expireDate"
                      type="date"
                      value={newInvoice.expireDate}
                      onChange={handleChange}
                      className={errors.expireDate ? 'border-red-500' : ''}
                    />
                    {errors.expireDate && <p className="text-red-500 text-sm">{errors.expireDate}</p>}
                  </div>
                  <div>
                    <Label htmlFor="year">Year</Label>
                    <Input
                      id="year"
                      name="year"
                      value={newInvoice.year}
                      onChange={handleChange}
                      className={errors.year ? 'border-red-500' : ''}
                    />
                    {errors.year && <p className="text-red-500 text-sm">{errors.year}</p>}
                  </div>
                  <div>
                    <Label htmlFor="currency">Currency</Label>
                    <Select name="currency" value={newInvoice.currency} onValueChange={(value) => handleChange({ target: { name: 'currency', value } } as any)}>
                      <SelectTrigger className={errors.currency ? 'border-red-500' : ''}>
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="PKR">PKR</SelectItem>
                        <SelectItem value="USD">USD</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.currency && <p className="text-red-500 text-sm">{errors.currency}</p>}
                  </div>
                  <div>
                    <Label htmlFor="status">
                      Initial Status 
                      <span className="text-sm text-gray-500 ml-1">(Auto-calculated on save)</span>
                    </Label>
                    <Select name="status" value={newInvoice.status} onValueChange={(value) => handleChange({ target: { name: 'status', value } } as any)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DRAFT">Draft</SelectItem>
                        <SelectItem value="PENDING">Pending</SelectItem>
                        <SelectItem value="UNPAID">Unpaid</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">
                      Final status calculated based on payment and due date
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="tax">Tax (%)</Label>
                    <Input
                      id="tax"
                      name="tax"
                      type="number"
                      min="0"
                      max="100"
                      step="0.01"
                      value={newInvoice.tax}
                      onChange={handleChange}
                      className={errors.tax ? 'border-red-500' : ''}
                    />
                    {errors.tax && <p className="text-red-500 text-sm">{errors.tax}</p>}
                  </div>
                  <div>
                    <Label htmlFor="paid">Paid Amount</Label>
                    <Input
                      id="paid"
                      name="paid"
                      type="number"
                      min="0"
                      step="0.01"
                      value={newInvoice.paid}
                      onChange={handleChange}
                      className={errors.paid ? 'border-red-500' : ''}
                    />
                    {errors.paid && <p className="text-red-500 text-sm">{errors.paid}</p>}
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="note">Note</Label>
                    <Input
                      id="note"
                      name="note"
                      value={newInvoice.note}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-2">Invoice Items</h3>
                  {errors.items && <p className="text-red-500 text-sm mb-2">{errors.items}</p>}
                  
                  <div className="space-y-4">
                    {newInvoice.items.map((item, index) => (
                      <div key={index} className="border rounded-lg p-4 bg-gray-50">
                        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
                          <div className="lg:col-span-2">
                            <ProductSearchSelect index={index} item={item} />
                          </div>
                          
                          <div>
                            <Label htmlFor={`weight_${index}`}>
                              Weight (Auto)
                              <span className="text-xs text-gray-500 block">From product</span>
                            </Label>
                            <Input
                              id={`weight_${index}`}
                              name="weight"
                              type="number"
                              value={item.weight}
                              readOnly
                              className={`bg-gray-100 ${errors[`weight_${index}`] ? 'border-red-500' : ''}`}
                            />
                            {errors[`weight_${index}`] && <p className="text-red-500 text-sm">{errors[`weight_${index}`]}</p>}
                          </div>
                          
                          <div>
                            <Label htmlFor={`balanceUnits_${index}`}>Balance Units</Label>
                            <Input
                              id={`balanceUnits_${index}`}
                              name="balanceUnits"
                              type="number"
                              min="1"
                              value={item.balanceUnits}
                              onChange={(e) => handleItemChange(index, e)}
                              className={errors[`balanceUnits_${index}`] ? 'border-red-500' : ''}
                            />
                            {errors[`balanceUnits_${index}`] && <p className="text-red-500 text-sm">{errors[`balanceUnits_${index}`]}</p>}
                          </div>
                          
                          <div>
                            <Label htmlFor={`balanceWeight_${index}`}>
                              Balance Weight (Auto)
                              <span className="text-xs text-gray-500 block">Weight × Units</span>
                            </Label>
                            <Input
                              id={`balanceWeight_${index}`}
                              name="balanceWeight"
                              type="number"
                              value={item.balanceWeight.toFixed(2)}
                              readOnly
                              className="bg-gray-100"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor={`unitPrice_${index}`}>Unit Price</Label>
                            <Input
                              id={`unitPrice_${index}`}
                              name="unitPrice"
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unitPrice}
                              onChange={(e) => handleItemChange(index, e)}
                              className={errors[`unitPrice_${index}`] ? 'border-red-500' : ''}
                            />
                            {errors[`unitPrice_${index}`] && <p className="text-red-500 text-sm">{errors[`unitPrice_${index}`]}</p>}
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                          <div>
                            <Label htmlFor={`discount_${index}`}>Discount</Label>
                            <Select
                              name="discount"
                              value={item.discount}
                              onValueChange={(value) => handleItemChange(index, { target: { name: 'discount', value } } as any)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select discount" />
                              </SelectTrigger>
                              <SelectContent>
                                {discounts.map(discount => (
                                  <SelectItem key={discount} value={discount}>
                                    {discount.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          
                          <div>
                            <Label>
                              Amount (Auto)
                              <span className="text-xs text-gray-500 block">After discount</span>
                            </Label>
                            <div className="p-2 bg-gray-100 rounded border font-medium">
                              {newInvoice.currency} {item.amount.toFixed(2)}
                            </div>
                          </div>
                          
                          <div className="flex items-end">
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => removeItem(index)}
                              disabled={newInvoice.items.length === 1}
                              className="w-full"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Remove Item
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button onClick={addItem} className="mt-4" variant="outline">
                    <Plus className="mr-2 h-4 w-4" /> Add Item
                  </Button>
                </div>
                
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2 p-4 bg-gray-50 rounded-lg">
                    <h4 className="font-semibold">Invoice Summary</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>{newInvoice.currency} {calculateSubtotal().toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tax ({newInvoice.tax}%):</span>
                        <span>{newInvoice.currency} {(calculateSubtotal() * (newInvoice.tax || 0) / 100).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-semibold border-t pt-1">
                        <span>Total:</span>
                        <span>{newInvoice.currency} {calculateTotal().toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Paid:</span>
                        <span>{newInvoice.currency} {(newInvoice.paid || 0).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-semibold text-red-600">
                        <span>Outstanding:</span>
                        <span>{newInvoice.currency} {calculateOutstanding().toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col justify-end space-y-2">
                    <div className="text-sm text-gray-600 p-3 bg-blue-50 rounded">
                      <div className="flex items-start space-x-2">
                        <AlertCircle className="h-4 w-4 mt-0.5 text-blue-600" />
                        <div>
                          <p className="font-medium">Status will be auto-calculated:</p>
                          <ul className="mt-1 text-xs space-y-1">
                            <li>• PAID: When paid ≥ total</li>
                            <li>• PARTIALLY_PAID: When some amount paid</li>
                            <li>• OVERDUE: When past due date</li>
                            <li>• Otherwise: Your selected status</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                    
                    <Button onClick={handleSave} disabled={loading} className="w-full">
                      {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                      {editingId ? 'Update Invoice' : 'Create Invoice'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
          <Button onClick={loadInvoices} disabled={loading}>
            <RefreshCw className="mr-2 h-4 w-4" /> Refresh
          </Button>
          {allowedActions.includes('read') && (
            <Button onClick={handleDownloadAllPDF} disabled={downloadLoading === -1}>
              {downloadLoading === -1 ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
              Download All PDF
            </Button>
          )}
        </div>
      </div>
      
      {error && <p className="text-red-500 mb-4">{error}</p>}
      
      <div className="invoice-table-container max-h-[600px] overflow-auto border rounded-lg">
        <table className="min-w-full bg-white">
          <thead className="bg-gray-50 sticky top-0">
            <tr>
              <th className="p-3 text-left border-b font-semibold">Invoice #</th>
              <th className="p-3 text-left border-b font-semibold">Customer</th>
              <th className="p-3 text-left border-b font-semibold">Date</th>
              <th className="p-3 text-left border-b font-semibold">Due Date</th>
              <th className="p-3 text-left border-b font-semibold">
                Status 
                <span className="block text-xs text-gray-500 font-normal">(Auto-calculated)</span>
              </th>
              <th className="p-3 text-left border-b font-semibold">Total</th>
              <th className="p-3 text-left border-b font-semibold">Outstanding</th>
              <th className="p-3 text-center border-b font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-gray-500">
                  {loading ? 'Loading invoices...' : 'No invoices found'}
                </td>
              </tr>
            ) : (
              filteredInvoices.map(invoice => {
                const statusProps = getStatusBadgeProps(invoice.status);
                return (
                  <tr key={invoice.id} className="hover:bg-gray-50 border-b">
                    <td className="p-3 font-medium">{invoice.number}</td>
                    <td className="p-3">{invoice.customer}</td>
                    <td className="p-3">{new Date(invoice.date).toLocaleDateString()}</td>
                    <td className="p-3">{new Date(invoice.expireDate).toLocaleDateString()}</td>
                    <td className="p-3">
                      <Badge {...statusProps}>
                        {invoice.status.replace('_', ' ')}
                      </Badge>
                    </td>
                    <td className="p-3 font-medium">{invoice.currency} {invoice.total.toFixed(2)}</td>
                    <td className="p-3">
                      <span className={calculateOutstanding(invoice) > 0 ? 'text-red-600 font-medium' : 'text-green-600'}>
                        {invoice.currency} {calculateOutstanding(invoice).toFixed(2)}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="flex justify-center space-x-1">
                        <Button variant="outline" size="sm" onClick={() => handleView(invoice)} title="View Details">
                          <Eye className="h-4 w-4" />
                        </Button>
                        {allowedActions.includes('update') && (
                          <Button variant="outline" size="sm" onClick={() => handleEdit(invoice)} title="Edit Invoice">
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {allowedActions.includes('delete') && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setInvoiceToDelete(Number(invoice.id));
                              setDeleteOpen(true);
                            }}
                            className="text-red-600 hover:text-red-700"
                            title="Delete Invoice"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                        {allowedActions.includes('read') && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownloadPDF(Number(invoice.id))}
                            disabled={downloadLoading === Number(invoice.id)}
                            title="Download PDF"
                          >
                            {downloadLoading === Number(invoice.id) ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <Download className="h-4 w-4" />
                            )}
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* View Invoice Dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
          </DialogHeader>
          {selectedInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="font-semibold text-lg">Invoice Information</h4>
                  <div className="space-y-2 text-sm">
                    <div><span className="font-medium">Number:</span> {selectedInvoice.number}</div>
                    <div><span className="font-medium">Customer:</span> {selectedInvoice.customer}</div>
                    <div><span className="font-medium">Email:</span> {selectedInvoice.email || 'N/A'}</div>
                    <div><span className="font-medium">Address:</span> {selectedInvoice.address}</div>
                    <div><span className="font-medium">Phone:</span> {selectedInvoice.phone}</div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-lg">Payment & Status</h4>
                  <div className="space-y-2 text-sm">
                    <div><span className="font-medium">Issue Date:</span> {new Date(selectedInvoice.date).toLocaleDateString()}</div>
                    <div><span className="font-medium">Due Date:</span> {new Date(selectedInvoice.expireDate).toLocaleDateString()}</div>
                    <div><span className="font-medium">Year:</span> {selectedInvoice.year}</div>
                    <div><span className="font-medium">Currency:</span> {selectedInvoice.currency}</div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">Status:</span>
                      <Badge {...getStatusBadgeProps(selectedInvoice.status)}>
                        {selectedInvoice.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <div><span className="font-medium">Tax:</span> {selectedInvoice.tax}%</div>
                    <div><span className="font-medium">Paid:</span> {selectedInvoice.currency} {(selectedInvoice.paid || 0).toFixed(2)}</div>
                  </div>
                </div>
              </div>
              
              {selectedInvoice.note && (
                <div>
                  <h4 className="font-semibold mb-2">Note</h4>
                  <p className="text-sm bg-gray-50 p-3 rounded">{selectedInvoice.note}</p>
                </div>
              )}
              
              <div>
                <h4 className="font-semibold text-lg mb-3">Invoice Items</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full border rounded-lg">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="p-3 text-left border-b text-sm font-semibold">Product</th>
                        <th className="p-3 text-left border-b text-sm font-semibold">Lot</th>
                        <th className="p-3 text-left border-b text-sm font-semibold">File No</th>
                        <th className="p-3 text-right border-b text-sm font-semibold">Weight</th>
                        <th className="p-3 text-right border-b text-sm font-semibold">Units</th>
                        <th className="p-3 text-right border-b text-sm font-semibold">Balance Weight</th>
                        <th className="p-3 text-right border-b text-sm font-semibold">Unit Price</th>
                        <th className="p-3 text-left border-b text-sm font-semibold">Discount</th>
                        <th className="p-3 text-right border-b text-sm font-semibold">Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedInvoice.items.map((item, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="p-3 text-sm">{item.productName}</td>
                          <td className="p-3 text-sm">{item.productLot}</td>
                          <td className="p-3 text-sm">{item.productFileno}</td>
                          <td className="p-3 text-sm text-right">{item.weight.toFixed(2)}</td>
                          <td className="p-3 text-sm text-right">{item.balanceUnits}</td>
                          <td className="p-3 text-sm text-right">{item.balanceWeight.toFixed(2)}</td>
                          <td className="p-3 text-sm text-right">{selectedInvoice.currency} {item.unitPrice.toFixed(2)}</td>
                          <td className="p-3 text-sm">{item.discount.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</td>
                          <td className="p-3 text-sm text-right font-medium">{selectedInvoice.currency} {item.amount.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-3">Invoice Summary</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>{selectedInvoice.currency} {calculateSubtotal().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax ({selectedInvoice.tax}%):</span>
                      <span>{selectedInvoice.currency} {(calculateSubtotal() * (selectedInvoice.tax || 0) / 100).toFixed(2)}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between font-semibold">
                      <span>Total:</span>
                      <span>{selectedInvoice.currency} {calculateTotal(selectedInvoice).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Paid:</span>
                      <span>{selectedInvoice.currency} {(selectedInvoice.paid || 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-semibold text-red-600">
                      <span>Outstanding:</span>
                      <span>{selectedInvoice.currency} {calculateOutstanding(selectedInvoice).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p>Are you sure you want to delete this invoice? This action cannot be undone.</p>
          </div>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              Delete Invoice
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Invoices;