import React, { useState, useEffect } from 'react';
import { orderAPI } from '../services/orders';
import { companiesAPI } from '../services/companies';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Edit, Trash2, X, Plus, Search, RefreshCw, ShoppingCart, Grid2X2Plus, Eye, Download } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface Order {
  id: number;
  number: string;
  quantity: number;
  price: number;
  discount: number;
  total: number;
  tax: number | null;
  fairCharges: number | null;
  customDuties: number | null;
  localFair: number | null;
  salesTax: number | null;
  officeExpense: number | null;
  misc: number | null;
  totalAmount: number;
  rate: number | null;
  priceInPKR: number | null;
  status: string;
  phone: string;
  state: string;
  city: string;
  note: string;
  companyId: string | null;
  companyName: string | null;
}

interface Company {
  id: string;
  name: string;
  amount: number; // Added amount field
}

interface ValidationErrors {
  number?: string;
  quantity?: string;
  price?: string;
  rate?: string;
  companyId?: string;
}

interface OrdersProps {
  allowedActions: string[];
}

// Utility to format priceInPKR to 12 digits + 2 decimal places
const formatPriceInPKR = (value: number | null): string => {
  if (value === null || isNaN(value)) return 'N/A';
  const formatted = value.toFixed(2);
  const [integerPart, decimalPart] = formatted.split('.');
  return `${integerPart}.${decimalPart}`;
};

const LightGlassCard = ({ children, className = '', gradient = false }: { children: React.ReactNode; className?: string; gradient?: boolean }) => (
  <div className={`backdrop-blur-xl bg-white/80 border border-gray-200/50 rounded-2xl shadow-lg ${gradient ? 'bg-gradient-to-br from-white/90 to-gray-50/80' : ''} ${className}`}>
    {children}
  </div>
);

const OrdersForm: React.FC<OrdersProps> = ({ allowedActions }) => {
  const [formData, setFormData] = useState<Partial<Order>>({
    number: '',
    quantity: 0,
    price: 0,
    discount: 0,
    tax: null,
    fairCharges: null,
    customDuties: null,
    localFair: null,
    salesTax: null,
    officeExpense: null,
    misc: null,
    total: 0,
    totalAmount: 0,
    rate: null,
    priceInPKR: null,
    status: 'Pending',
    phone: '',
    state: '',
    city: '',
    note: '',
    companyId: null,
  });
  const [orders, setOrders] = useState<Order[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [editForm, setEditForm] = useState<Partial<Order> | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<Order | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [apiError, setApiError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [addLoading, setAddLoading] = useState(false);
  const [dateRange, setDateRange] = useState<string>('7d');
  const { toast } = useToast();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isViewingDetails, setIsViewingDetails] = useState(false);

  const hasPermission = (action: string): boolean => {
    return allowedActions.includes(action) || allowedActions.includes('*');
  };

  const normalizeStatus = (status: string): string => {
    const validStatuses = ['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'];
    return validStatuses.includes(status) ? status : 'Pending';
  };

  const fetchOrders = async () => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to read orders',
        variant: 'destructive',
      });
      return;
    }
    try {
      setLoading(true);
      const response = await orderAPI.getOrders();
      const normalizedOrders = Array.isArray(response.data) ? response.data.map(order => ({
        ...order,
        status: normalizeStatus(order.status),
        customDuties: typeof order.customDuties === 'number' ? order.customDuties : null,
        fairCharges: typeof order.fairCharges === 'number' ? order.fairCharges : null,
        localFair: typeof order.localFair === 'number' ? order.localFair : null,
        salesTax: typeof order.salesTax === 'number' ? order.salesTax : null,
        officeExpense: typeof order.officeExpense === 'number' ? order.officeExpense : null,
        misc: typeof order.misc === 'number' ? order.misc : null,
        tax: typeof order.tax === 'number' ? order.tax : null,
        rate: typeof order.rate === 'number' ? order.rate : null,
        priceInPKR: typeof order.priceInPKR === 'number' ? order.priceInPKR : null,
        quantity: typeof order.quantity === 'number' ? order.quantity : 0,
        price: typeof order.price === 'number' ? order.price : 0,
        discount: typeof order.discount === 'number' ? order.discount : 0,
        total: typeof order.total === 'number' ? order.total : 0,
        totalAmount: typeof order.totalAmount === 'number' ? order.totalAmount : 0,
        companyName: order.companyId ? companies.find(c => c.id === order.companyId)?.name || 'N/A' : 'N/A',
      })) : [];
      setOrders(normalizedOrders);
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to fetch orders';
      console.error('Fetch orders error:', err.message, err.response?.data, err.config);
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCompanies = async () => {
    try {
      const response = await companiesAPI.getCompanies();
      const companiesData = Array.isArray(response.data) ? response.data.map(company => ({
        ...company,
        amount: typeof company.amount === 'number' ? company.amount : 0, // Ensure amount is a number
      })) : [];
      setCompanies(companiesData);
    } catch (err: any) {
      console.error('Fetch companies error:', err.message, err.response?.data);
      toast({
        title: 'Error',
        description: 'Failed to fetch companies',
        variant: 'destructive',
      });
    }
  };

  useEffect(() => {
    if (hasPermission('read')) {
      Promise.all([fetchCompanies(), fetchOrders()]).catch(err => {
        console.error('Error in useEffect:', err);
      });
    } else {
      setApiError('You do not have permission to view orders');
      setLoading(false);
    }
  }, [dateRange]);

  const calculateTotal = (data: Partial<Order>) => {
    return ((data.quantity || 0) * (data.price || 0)) - (Number(data.discount) || 0) ;
  };

  const calculateTotalAmount = (data: Partial<Order>) => {
    const baseTotal = calculateTotal(data);
    const taxAmount = baseTotal * ((data.tax || 0) / 100);
    return (
      baseTotal +
      taxAmount +
      (Number(data.fairCharges) || 0) +
      (Number(data.customDuties) || 0) +
      (Number(data.localFair) || 0) +
      (Number(data.salesTax) || 0) +
      (Number(data.officeExpense) || 0) +
      (Number(data.misc) || 0)
    );
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const updated = {
        ...prev,
        [name]: ['quantity', 'price', 'discount', 'tax', 'fairCharges', 'customDuties', 'localFair', 'salesTax', 'officeExpense', 'misc', 'rate'].includes(name)
          ? (value === '' ? null : parseFloat(value))
          : name === 'companyId' && value === '' ? null : value,
      };
      updated.total = calculateTotal(updated);
      updated.totalAmount = calculateTotalAmount(updated);
      updated.priceInPKR = updated.rate && updated.totalAmount ? updated.rate * updated.totalAmount : null;
      return updated;
    });
    if (errors[name as keyof ValidationErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (editForm) {
      setEditForm(prev => {
        const updated = {
          ...prev!,
          [name]: ['quantity', 'price', 'discount', 'tax', 'fairCharges', 'customDuties', 'localFair', 'salesTax', 'officeExpense', 'misc', 'rate'].includes(name)
            ? (value === '' ? null : parseFloat(value))
            : name === 'companyId' && value === '' ? null : value,
        };
        updated.total = calculateTotal(updated);
        updated.totalAmount = calculateTotalAmount(updated);
        updated.priceInPKR = updated.rate && updated.totalAmount ? updated.rate * updated.totalAmount : null;
        return updated;
      });
      if (errors[name as keyof ValidationErrors]) {
        setErrors(prev => ({ ...prev, [name]: undefined }));
      }
    }
  };

  const validateForm = (data: Partial<Order>): ValidationErrors => {
    const newErrors: ValidationErrors = {};
    if (!data.number?.trim()) newErrors.number = 'Order number is required';
    if (!data.quantity || data.quantity <= 0 || isNaN(data.quantity)) newErrors.quantity = 'Quantity must be a positive number';
    if (!data.price || data.price <= 0 || isNaN(data.price)) newErrors.price = 'Price must be a positive number';
    if (data.rate && (data.rate <= 0 || isNaN(data.rate))) newErrors.rate = 'Rate must be a positive number';
    return newErrors;
  };

  const handleAddOrder = async () => {
    if (!hasPermission('create')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to create orders',
        variant: 'destructive',
      });
      return;
    }
    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      return;
    }

    try {
      setAddLoading(true);
      const total = calculateTotal(formData);
      const totalAmount = calculateTotalAmount(formData);
      const payload = {
        ...formData,
        total,
        totalAmount,
        quantity: Number(formData.quantity),
        price: Number(formData.price),
        discount: Number(formData.discount) || 0,
        tax: formData.tax !== null ? Number(formData.tax) : null,
        fairCharges: formData.fairCharges !== null ? Number(formData.fairCharges) : null,
        customDuties: formData.customDuties !== null ? Number(formData.customDuties) : null,
        localFair: formData.localFair !== null ? Number(formData.localFair) : null,
        salesTax: formData.salesTax !== null ? Number(formData.salesTax) : null,
        officeExpense: formData.officeExpense !== null ? Number(formData.officeExpense) : null,
        misc: formData.misc !== null ? Number(formData.misc) : null,
        rate: formData.rate !== null ? Number(formData.rate) : null,
        priceInPKR: formData.rate && totalAmount ? Number(formData.rate) * totalAmount : null,
      };
      const response = await orderAPI.createOrder(payload);
      const normalizedOrder = {
        ...response.data,
        status: normalizeStatus(response.data.status),
        companyName: payload.companyId ? companies.find(c => c.id === payload.companyId)?.name || 'N/A' : 'N/A',
      };
      
      // Update company amount if companyId exists
      if (payload.companyId) {
        const company = companies.find(c => c.id === payload.companyId);
        if (company) {
          const newAmount = (company.amount || 0) + total;
          await companiesAPI.updateCompany(payload.companyId, { ...company, amount: newAmount });
          setCompanies(prev => prev.map(c => c.id === payload.companyId ? { ...c, amount: newAmount } : c));
        }
      }

      setOrders(prev => [...prev, normalizedOrder]);
      setShowAddModal(false);
      toast({
        title: 'Success',
        description: 'Order added successfully',
      });
      setFormData({
        number: '',
        quantity: 0,
        price: 0,
        discount: 0,
        tax: null,
        fairCharges: null,
        customDuties: null,
        localFair: null,
        salesTax: null,
        officeExpense: null,
        misc: null,
        total: 0,
        totalAmount: 0,
        rate: null,
        priceInPKR: null,
        status: 'Pending',
        phone: '',
        state: '',
        city: '',
        note: '',
        companyId: null,
      });
      setErrors({});
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to add order';
      if (errorMessage === 'Company not found') {
        setErrors(prev => ({ ...prev, companyId: 'Selected company does not exist' }));
      }
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setAddLoading(false);
    }
  };

  const handleEdit = (order: Order) => {
    if (!hasPermission('update')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to edit orders',
        variant: 'destructive',
      });
      return;
    }
    setEditingOrder(order);
    setEditForm({
      ...order,
      quantity: order.quantity || 0,
      price: order.price || 0,
      discount: order.discount || 0,
      tax: order.tax ?? null,
      fairCharges: order.fairCharges ?? null,
      customDuties: order.customDuties ?? null,
      localFair: order.localFair ?? null,
      salesTax: order.salesTax ?? null,
      officeExpense: order.officeExpense ?? null,
      misc: order.misc ?? null,
      rate: order.rate ?? null,
      priceInPKR: order.priceInPKR ?? null,
      total: order.total || 0,
      totalAmount: order.totalAmount || 0,
    });
    setShowEditModal(true);
    setErrors({});
    setApiError(null);
  };

  const handleSaveEdit = async () => {
    if (!hasPermission('update')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to update orders',
        variant: 'destructive',
      });
      return;
    }
    if (!editingOrder || !editForm) return;

    const validationErrors = validateForm(editForm);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      return;
    }

    try {
      setAddLoading(true);
      const total = calculateTotal(editForm);
      const totalAmount = calculateTotalAmount(editForm);
      const payload = {
        ...editForm,
        total,
        totalAmount,
        quantity: Number(editForm.quantity),
        price: Number(editForm.price),
        discount: Number(editForm.discount) || 0,
        tax: editForm.tax !== null ? Number(editForm.tax) : null,
        fairCharges: editForm.fairCharges !== null ? Number(editForm.fairCharges) : null,
        customDuties: editForm.customDuties !== null ? Number(editForm.customDuties) : null,
        localFair: editForm.localFair !== null ? Number(editForm.localFair) : null,
        salesTax: editForm.salesTax !== null ? Number(editForm.salesTax) : null,
        officeExpense: editForm.officeExpense !== null ? Number(editForm.officeExpense) : null,
        misc: editForm.misc !== null ? Number(editForm.misc) : null,
        rate: editForm.rate !== null ? Number(editForm.rate) : null,
        priceInPKR: editForm.rate && totalAmount ? Number(editForm.rate) * totalAmount : null,
      };
      
      // Update company amount if companyId exists
      if (payload.companyId) {
        const company = companies.find(c => c.id === payload.companyId);
        if (company) {
          const oldTotal = editingOrder.quantity * editingOrder.price;
          const amountDiff = total - oldTotal;
          const newAmount = (company.amount || 0) + amountDiff;
          await companiesAPI.updateCompany(payload.companyId, { ...company, amount: newAmount });
          setCompanies(prev => prev.map(c => c.id === payload.companyId ? { ...c, amount: newAmount } : c));
        }
      }

      const response = await orderAPI.updateOrder(editingOrder.id, payload);
      const normalizedOrder = {
        ...response.data,
        status: normalizeStatus(response.data.status),
        companyName: payload.companyId ? companies.find(c => c.id === payload.companyId)?.name || 'N/A' : 'N/A',
      };
      setOrders(orders.map(ord => ord.id === editingOrder.id ? normalizedOrder : ord));
      setShowEditModal(false);
      setEditingOrder(null);
      setEditForm(null);
      toast({
        title: 'Success',
        description: 'Order updated successfully',
      });
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to update order';
      if (errorMessage === 'Company not found') {
        setErrors(prev => ({ ...prev, companyId: 'Selected company does not exist' }));
      }
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setAddLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!hasPermission('delete')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to delete orders',
        variant: 'destructive',
      });
      return;
    }
    if (!orderToDelete) return;

    try {
      setAddLoading(true);
      await orderAPI.deleteOrder(orderToDelete.id);
      setOrders(orders.filter(ord => ord.id !== orderToDelete.id));
      setShowDeleteModal(false);
      setOrderToDelete(null);
      toast({
        title: 'Success',
        description: 'Order deleted successfully',
      });
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to delete order';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setAddLoading(false);
    }
  };

  const handleView = (order: Order) => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to view order details',
        variant: 'destructive',
      });
      return;
    }
    setSelectedOrder(order);
    setIsViewingDetails(true);
  };

  const handleDownloadPDF = async () => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to download PDF',
        variant: 'destructive',
      });
      return;
    }
    try {
      setLoading(true);
      const response = await orderAPI.downloadOrdersPDF();
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'orders-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download PDF error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPDFbyID = async (id: number) => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to download PDF',
        variant: 'destructive',
      });
      return;
    }
    try {
      setLoading(true);
      const response = await orderAPI.downloadPDFById(id);
      const order = orders.find(o => o.id === id);
      const filename = order ? `order-${order.number}.pdf` : 'order.pdf';
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'Order PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download order PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download order PDF error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to refresh orders',
        variant: 'destructive',
      });
      return;
    }
    fetchOrders();
  };

  const filteredOrders = orders.filter(order =>
    order.number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!hasPermission('read')) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <Card className="text-center py-12">
          <CardContent>
            <div className="text-red-500 text-6xl mb-4">🔒</div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
            <p className="text-gray-600">You do not have permission to view orders.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6">
      {apiError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <span>{apiError}</span>
        </div>
      )}

      {/* Add Modal */}
      <Dialog open={showAddModal} onOpenChange={setShowAddModal}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Add Shipment</DialogTitle>
          </DialogHeader>
          <LightGlassCard className="p-6" gradient>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Order Number *</label>
                <Input
                  type="text"
                  name="number"
                  value={formData.number || ''}
                  onChange={handleChange}
                  className={`w-full ${errors.number ? 'border-red-500 bg-red-50' : ''}`}
                  placeholder="ORD001"
                  disabled={addLoading}
                />
                {errors.number && <p className="text-red-500 text-xs mt-1">{errors.number}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company</label>
                <Select
                  name="companyId"
                  value={formData.companyId || 'none'}
                  onValueChange={(value) => handleChange({ target: { name: 'companyId', value: value === 'none' ? '' : value } } as any)}
                  disabled={addLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a company" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Select a company</SelectItem>
                    {companies.map(company => (
                      <SelectItem key={company.id} value={company.id}>{company.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.companyId && <p className="text-red-500 text-xs mt-1">{errors.companyId}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Quantity *</label>
                <Input
                  type="number"
                  name="quantity"
                  value={formData.quantity || ''}
                  onChange={handleChange}
                  className={`w-full ${errors.quantity ? 'border-red-500 bg-red-50' : ''}`}
                  min="1"
                  step="1"
                  disabled={addLoading}
                />
                {errors.quantity && <p className="text-red-500 text-xs mt-1">{errors.quantity}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price *</label>
                <Input
                  type="number"
                  name="price"
                  value={formData.price || ''}
                  onChange={handleChange}
                  className={`w-full ${errors.price ? 'border-red-500 bg-red-50' : ''}`}
                  step="0.01"
                  min="0.01"
                  disabled={addLoading}
                />
                {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Discount</label>
                <Input
                  type="number"
                  name="discount"
                  value={formData.discount || ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tax (%)</label>
                <Input
                  type="number"
                  name="tax"
                  value={formData.tax ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fair Charges</label>
                <Input
                  type="number"
                  name="fairCharges"
                  value={formData.fairCharges ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Custom Duties</label>
                <Input
                  type="number"
                  name="customDuties"
                  value={formData.customDuties ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Local Fair</label>
                <Input
                  type="number"
                  name="localFair"
                  value={formData.localFair ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sales Tax</label>
                <Input
                  type="number"
                  name="salesTax"
                  value={formData.salesTax ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Office Expense</label>
                <Input
                  type="number"
                  name="officeExpense"
                  value={formData.officeExpense ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Miscellaneous</label>
                <Input
                  type="number"
                  name="misc"
                  value={formData.misc ?? ''}
                  onChange={handleChange}
                  className="w-full"
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rate (PKR/USD)</label>
                <Input
                  type="number"
                  name="rate"
                  value={formData.rate ?? ''}
                  onChange={handleChange}
                  className={`w-full ${errors.rate ? 'border-red-500 bg-red-50' : ''}`}
                  step="0.01"
                  min="0"
                  disabled={addLoading}
                />
                {errors.rate && <p className="text-red-500 text-xs mt-1">{errors.rate}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total (PKR)</label>
                <Input
                  type="text"
                  name="priceInPKR"
                  value={formatPriceInPKR(formData.priceInPKR)}
                  className="w-full bg-gray-100 cursor-not-allowed"
                  readOnly
                  disabled
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total</label>
                <Input
                  type="number"
                  name="total"
                  value={formData.total ?? ''}
                  className="w-full bg-gray-100 cursor-not-allowed"
                  readOnly
                  disabled
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Total Amount (USD)</label>
                <Input
                  type="number"
                  name="totalAmount"
                  value={formData.totalAmount ?? ''}
                  className="w-full bg-gray-100 cursor-not-allowed"
                  readOnly
                  disabled
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <Select
                  name="status"
                  value={formData.status || 'Pending'}
                  onValueChange={(value) => handleChange({ target: { name: 'status', value } } as any)}
                  disabled={addLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    {['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'].map(status => (
                      <SelectItem key={status} value={status}>{status}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <Input
                  type="text"
                  name="phone"
                  value={formData.phone || ''}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="+1234567890"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                <Input
                  type="text"
                  name="state"
                  value={formData.state || ''}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="State"
                  disabled={addLoading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                <Input
                  type="text"
                  name="city"
                  value={formData.city || ''}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="City"
                  disabled={addLoading}
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
                <Input
                  type="text"
                  name="note"
                  value={formData.note || ''}
                  onChange={handleChange}
                  className="w-full"
                  placeholder="Additional notes"
                  disabled={addLoading}
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end space-x-4">
              <Button variant="outline" onClick={() => setShowAddModal(false)} disabled={addLoading}>
                Cancel
              </Button>
              <Button onClick={handleAddOrder} disabled={addLoading}>
                {addLoading ? 'Adding...' : 'Add Order'}
              </Button>
            </div>
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      {/* Edit Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Shipment</DialogTitle>
          </DialogHeader>
          {editForm && (
            <LightGlassCard className="p-6" gradient>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Order Number *</label>
                  <Input
                    type="text"
                    name="number"
                    value={editForm.number || ''}
                    onChange={handleEditChange}
                    className={`w-full ${errors.number ? 'border-red-500 bg-red-50' : ''}`}
                    placeholder="ORD001"
                    disabled={addLoading}
                  />
                  {errors.number && <p className="text-red-500 text-xs mt-1">{errors.number}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Company</label>
                  <Select
                    name="companyId"
                    value={editForm.companyId || 'none'}
                    onValueChange={(value) => handleEditChange({ target: { name: 'companyId', value: value === 'none' ? '' : value } } as any)}
                    disabled={addLoading}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a company" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Select a company</SelectItem>
                      {companies.map(company => (
                        <SelectItem key={company.id} value={company.id}>{company.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.companyId && <p className="text-red-500 text-xs mt-1">{errors.companyId}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quantity *</label>
                  <Input
                    type="number"
                    name="quantity"
                    value={editForm.quantity || ''}
                    onChange={handleEditChange}
                    className={`w-full ${errors.quantity ? 'border-red-500 bg-red-50' : ''}`}
                    min="1"
                    step="1"
                    disabled={addLoading}
                  />
                  {errors.quantity && <p className="text-red-500 text-xs mt-1">{errors.quantity}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price *</label>
                  <Input
                    type="number"
                    name="price"
                    value={editForm.price || ''}
                    onChange={handleEditChange}
                    className={`w-full ${errors.price ? 'border-red-500 bg-red-50' : ''}`}
                    step="0.01"
                    min="0.01"
                    disabled={addLoading}
                  />
                  {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Discount</label>
                  <Input
                    type="number"
                    name="discount"
                    value={editForm.discount || ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tax (%)</label>
                  <Input
                    type="number"
                    name="tax"
                    value={editForm.tax ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Fair Charges</label>
                  <Input
                    type="number"
                    name="fairCharges"
                    value={editForm.fairCharges ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Custom Duties</label>
                  <Input
                    type="number"
                    name="customDuties"
                    value={editForm.customDuties ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Local Fair</label>
                  <Input
                    type="number"
                    name="localFair"
                    value={editForm.localFair ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sales Tax</label>
                  <Input
                    type="number"
                    name="salesTax"
                    value={editForm.salesTax ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Office Expense</label>
                  <Input
                    type="number"
                    name="officeExpense"
                    value={editForm.officeExpense ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Miscellaneous</label>
                  <Input
                    type="number"
                    name="misc"
                    value={editForm.misc ?? ''}
                    onChange={handleEditChange}
                    className="w-full"
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rate (PKR/USD)</label>
                  <Input
                    type="number"
                    name="rate"
                    value={editForm.rate ?? ''}
                    onChange={handleEditChange}
                    className={`w-full ${errors.rate ? 'border-red-500 bg-red-50' : ''}`}
                    step="0.01"
                    min="0"
                    disabled={addLoading}
                  />
                  {errors.rate && <p className="text-red-500 text-xs mt-1">{errors.rate}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Total (PKR)</label>
                  <Input
                    type="text"
                    name="priceInPKR"
                    value={formatPriceInPKR(editForm.priceInPKR)}
                    className="w-full bg-gray-100 cursor-not-allowed"
                    readOnly
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Total</label>
                  <Input
                    type="number"
                    name="total"
                    value={editForm.total ?? ''}
                    className="w-full bg-gray-100 cursor-not-allowed"
                    readOnly
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Total Amount (USD)</label>
                  <Input
                    type="number"
                    name="totalAmount"
                    value={editForm.totalAmount ?? ''}
                    className="w-full bg-gray-100 cursor-not-allowed"
                    readOnly
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <Select
                    name="status"
                    value={editForm.status || 'Pending'}
                    onValueChange={(value) => handleEditChange({ target: { name: 'status', value } } as any)}
                    disabled={addLoading}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'].map(status => (
                        <SelectItem key={status} value={status}>{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <Input
                    type="text"
                    name="phone"
                    value={editForm.phone || ''}
                    onChange={handleEditChange}
                    className="w-full"
                    placeholder="+1234567890"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
                  <Input
                    type="text"
                    name="state"
                    value={editForm.state || ''}
                    onChange={handleEditChange}
                    className="w-full"
                    placeholder="State"
                    disabled={addLoading}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
                  <Input
                    type="text"
                    name="city"
                    value={editForm.city || ''}
                    onChange={handleEditChange}
                    className="w-full"
                    placeholder="City"
                    disabled={addLoading}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Note</label>
                  <Input
                    type="text"
                    name="note"
                    value={editForm.note || ''}
                    onChange={handleEditChange}
                    className="w-full"
                    placeholder="Additional notes"
                    disabled={addLoading}
                  />
                </div>
              </div>
              <div className="mt-6 flex justify-end space-x-4">
                <Button variant="outline" onClick={() => setShowEditModal(false)} disabled={addLoading}>
                  Cancel
                </Button>
                <Button onClick={handleSaveEdit} disabled={addLoading}>
                  {addLoading ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </LightGlassCard>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog open={showDeleteModal} onOpenChange={setShowDeleteModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
          </DialogHeader>
          <LightGlassCard className="p-6">
            <p>Are you sure you want to delete order {orderToDelete?.number}?</p>
            <div className="mt-6 flex justify-end space-x-4">
              <Button variant="outline" onClick={() => setShowDeleteModal(false)} disabled={addLoading}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDelete} disabled={addLoading}>
                {addLoading ? 'Deleting...' : 'Delete'}
              </Button>
            </div>
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      {/* View Details Modal */}
      <Dialog open={isViewingDetails} onOpenChange={setIsViewingDetails}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <LightGlassCard className="p-6" gradient>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <strong>Order Number:</strong> {selectedOrder.number}
                </div>
                <div>
                  <strong>Company:</strong> {companies.find(c => c.id === selectedOrder.companyId)?.name || 'N/A'}
                </div>
                <div>
                  <strong>Quantity:</strong> {selectedOrder.quantity}
                </div>
                <div>
                  <strong>Price:</strong> ${selectedOrder.price.toFixed(2)}
                </div>
                <div>
                  <strong>Discount:</strong> ${selectedOrder.discount.toFixed(2)}
                </div>
                <div>
                  <strong>Total:</strong> ${selectedOrder.total.toFixed(2)}
                </div>
                <div>
                  <strong>Tax (%):</strong> {selectedOrder.tax ? `${selectedOrder.tax.toFixed(1)}%` : 'N/A'}
                </div>
                <div>
                  <strong>Fair Charges:</strong> {selectedOrder.fairCharges ? `$${selectedOrder.fairCharges.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Custom Duties:</strong> {selectedOrder.customDuties ? `$${selectedOrder.customDuties.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Local Fair:</strong> {selectedOrder.localFair ? `$${selectedOrder.localFair.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Sales Tax:</strong> {selectedOrder.salesTax ? `$${selectedOrder.salesTax.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Office Expense:</strong> {selectedOrder.officeExpense ? `$${selectedOrder.officeExpense.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Miscellaneous:</strong> {selectedOrder.misc ? `$${selectedOrder.misc.toFixed(2)}` : 'N/A'}
                </div>
                <div>
                  <strong>Total Amount (USD):</strong> ${selectedOrder.totalAmount.toFixed(2)}
                </div>
                <div>
                  <strong>Rate (PKR/USD):</strong> {selectedOrder.rate ? selectedOrder.rate.toFixed(2) : 'N/A'}
                </div>
                <div>
                  <strong>Total (PKR):</strong> {formatPriceInPKR(selectedOrder.priceInPKR)}
                </div>
                <div>
                  <strong>Status:</strong> {selectedOrder.status}
                </div>
                <div>
                  <strong>Phone:</strong> {selectedOrder.phone || 'N/A'}
                </div>
                <div>
                  <strong>State:</strong> {selectedOrder.state || 'N/A'}
                </div>
                <div>
                  <strong>City:</strong> {selectedOrder.city || 'N/A'}
                </div>
                <div className="md:col-span-2">
                  <strong>Note:</strong> {selectedOrder.note || 'N/A'}
                </div>
              </div>
              <div className="mt-6 flex justify-end">
                <Button variant="outline" onClick={() => setIsViewingDetails(false)}>
                  Close
                </Button>
              </div>
            </LightGlassCard>
          )}
        </DialogContent>
      </Dialog>

      {/* Main Content */}
      <LightGlassCard className="max-w-7xl mx-auto p-6" gradient>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl font-bold flex items-center gap-2">
            <ShoppingCart className="h-6 w-6" />
            Orders
          </CardTitle>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                type="text"
                placeholder="Search orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="14d">Last 14 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleRefresh} disabled={loading}>
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
            {hasPermission('create') && (
              <Button onClick={() => setShowAddModal(true)}>
                <Plus className="h-4 w-4 mr-2" /> Add Order
              </Button>
            )}
            {hasPermission('read') && (
              <Button onClick={handleDownloadPDF} disabled={loading}>
                <Download className="h-4 w-4 mr-2" /> Download PDF
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading orders...</p>
            </div>
          ) : orders.length === 0 ? (
            <div className="text-center py-12">
              <Grid2X2Plus className="h-12 w-12 mx-auto text-gray-400" />
              <p className="mt-4 text-gray-600">No orders found</p>
              {hasPermission('create') && (
                <Button className="mt-4" onClick={() => setShowAddModal(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Add Your First Order
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Order No</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Disc.</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total Amount (USD)</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Rate</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total (PKR)</th>
                    <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredOrders.map(order => (
                    <tr key={order.id} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.number}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                        {companies.find(c => c.id === order.companyId)?.name || order.companyName || 'N/A'}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{order.quantity}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${order.price.toFixed(2)}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${order.discount.toFixed(2)}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${order.total.toFixed(2)}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">${order.totalAmount.toFixed(2)}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">{order.rate ? order.rate.toFixed(2) : 'N/A'}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 text-right">{formatPriceInPKR(order.priceInPKR)}</td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-center">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                          ${order.status === 'Delivered' ? 'bg-green-100 text-green-800' :
                            order.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                            order.status === 'Pending' || order.status === 'Confirmed' || order.status === 'Shipped' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'}`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-right font-medium">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="sm" onClick={() => handleView(order)}>
                            <Eye className="h-4 w-4" />
                          </Button>
                          {hasPermission('read') && (
                            <Button variant="ghost" size="sm" onClick={() => handleDownloadPDFbyID(order.id)}>
                              <Download className="h-4 w-4" />
                            </Button>
                          )}
                          {hasPermission('update') && (
                            <Button variant="ghost" size="sm" onClick={() => handleEdit(order)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          )}
                          {hasPermission('delete') && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setOrderToDelete(order);
                                setShowDeleteModal(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </LightGlassCard>
    </div>
  );
};

export default OrdersForm;