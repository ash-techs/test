import React, { useState, useEffect, useCallback } from 'react';
import { Save, Search, Download, Plus, Pencil, Trash2, RefreshCw, Grid2x2Plus, Eye,X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { inventoryAPI } from '../services/inventories';
import { useToast } from '@/hooks/use-toast';

interface InventoryData {
  id?: number;
  vendor: string;
  item: string;
  unitPrice: number;
  quantity: number;
  itemType: string;
  description?: string;
}

interface InventoryFormProps {
  allowedActions: string[];
}

const LightGlassCard = ({ children, className = '', gradient = false }: { children: React.ReactNode; className?: string; gradient?: boolean }) => (
  <div className={`backdrop-blur-xl bg-white/80 border border-gray-200/50 rounded-2xl shadow-lg ${gradient ? 'bg-gradient-to-br from-white/90 to-gray-50/80' : ''} ${className}`}>
    {children}
  </div>
);

const InventoryForm: React.FC<InventoryFormProps> = ({ allowedActions }) => {
  const [inventory, setInventory] = useState<InventoryData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState<InventoryData>({
    vendor: '',
    item: '',
    unitPrice: 0,
    quantity: 0,
    itemType: '',
    description: '',
  });
  const [isAddEditDialogOpen, setIsAddEditDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [viewingItem, setViewingItem] = useState<InventoryData | null>(null);
  const [itemToDelete, setItemToDelete] = useState<number | null>(null);
  const { toast } = useToast();

  const hasPermission = useCallback((action: string): boolean => {
    return allowedActions.includes(action) || allowedActions.includes('*');
  }, [allowedActions]);

  const loadInventory = useCallback(async (signal: AbortSignal) => {
    if (!hasPermission('read')) {
      setApiError('You do not have permission to view inventory');
      setLoading(false);
      return;
    }
    setLoading(true);
    setApiError(null);
    try {
      const response = await inventoryAPI.getInventories();
      const inventoryData = Array.isArray(response.data) ? response.data : [];
      setInventory(inventoryData);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        return;
      }
      console.error('Error loading inventory:', err);
      const errorMessage = err.response?.data?.error || 'Failed to load inventory. Please try again.';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      setInventory([]);
    } finally {
      setLoading(false);
    }
  }, [hasPermission, toast]);

  useEffect(() => {
    if (!hasPermission('read')) {
      setApiError('You do not have permission to view inventory');
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => {
      controller.abort();
      setApiError('Request timed out');
      toast({
        title: 'Error',
        description: 'Request timed out. Please try again.',
        variant: 'destructive',
      });
      setLoading(false);
    }, 10000); // 10-second timeout

    loadInventory(controller.signal);

    return () => {
      controller.abort();
      clearTimeout(timeout);
    };
  }, [hasPermission, loadInventory, toast]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'unitPrice' || name === 'quantity' ? parseFloat(value) || 0 : value,
    });
    if (apiError) setApiError(null);
  };

  const resetForm = () => {
    setFormData({
      vendor: '',
      item: '',
      unitPrice: 0,
      quantity: 0,
      itemType: '',
      description: '',
    });
    setEditingId(null);
    setApiError(null);
  };

  const validateForm = (data: InventoryData): { [key: string]: string } => {
    const errors: { [key: string]: string } = {};
    if (!data.vendor.trim()) errors.vendor = 'Vendor is required';
    if (!data.item.trim()) errors.item = 'Item is required';
    if (data.unitPrice <= 0) errors.unitPrice = 'Unit Price must be greater than 0';
    if (data.quantity <= 0) errors.quantity = 'Quantity must be greater than 0';
    if (!data.itemType.trim()) errors.itemType = 'Item Type is required';
    return errors;
  };

  const handleAddOrUpdateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!hasPermission(editingId ? 'update' : 'create')) {
      toast({
        title: 'Permission Denied',
        description: `You do not have permission to ${editingId ? 'update' : 'create'} inventory items`,
        variant: 'destructive',
      });
      return;
    }

    const errors = validateForm(formData);
    if (Object.keys(errors).length > 0) {
      setApiError(Object.values(errors)[0]);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    setApiError(null);
    try {
      if (editingId) {
        await inventoryAPI.updateInventory(editingId, formData);
        toast({
          title: 'Success',
          description: 'Inventory item updated successfully',
        });
      } else {
        await inventoryAPI.createInventory(formData);
        toast({
          title: 'Success',
          description: 'Inventory item added successfully',
        });
      }
      await loadInventory(new AbortController().signal);
      resetForm();
      setIsAddEditDialogOpen(false);
    } catch (err: any) {
      console.error('Error saving inventory item:', err);
      const errorMessage = err.response?.data?.error || 'Failed to save item. Please check your input and try again.';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: number) => {
    if (!hasPermission('update')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to edit inventory items',
        variant: 'destructive',
      });
      return;
    }
    setLoading(true);
    setApiError(null);
    try {
      const response = await inventoryAPI.getInventory(id);
      const itemData = {
        ...response.data,
        unitPrice: parseFloat(response.data.unitPrice) || 0,
        quantity: parseInt(response.data.quantity) || 0,
        itemType: response.data.itemType || '',
      };
      setFormData(itemData);
      setEditingId(id);
      setIsAddEditDialogOpen(true);
    } catch (err: any) {
      console.error('Error fetching inventory item for edit:', err);
      const errorMessage = err.response?.data?.error || 'Failed to load item for editing. Please try again.';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleView = (item: InventoryData) => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to view inventory item details',
        variant: 'destructive',
      });
      return;
    }
    setViewingItem(item);
    setIsViewDialogOpen(true);
  };

  const handleDelete = async () => {
    if (!hasPermission('delete')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to delete inventory items',
        variant: 'destructive',
      });
      return;
    }
    if (!itemToDelete) return;

    setLoading(true);
    setApiError(null);
    try {
      await inventoryAPI.deleteInventory(itemToDelete);
      await loadInventory(new AbortController().signal);
      toast({
        title: 'Success',
        description: 'Inventory item deleted successfully',
      });
      setItemToDelete(null);
      setIsDeleteDialogOpen(false);
    } catch (err: any) {
      console.error('Error deleting inventory item:', err);
      const errorMessage = err.response?.data?.error || 'Failed to delete item. Please try again.';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    if (!hasPermission('read')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to refresh inventory',
        variant: 'destructive',
      });
      return;
    }
    await loadInventory(new AbortController().signal);
  };

  const handleDownloadPDF = async () => {
    if (!hasPermission('download')) {
      toast({
        title: 'Permission Denied',
        description: 'You do not have permission to download inventory reports',
        variant: 'destructive',
      });
      return;
    }
    setLoading(true);
    setApiError(null);
    try {
      const response = await inventoryAPI.downloadInventoryPDF();
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'inventory-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'Inventory report downloaded successfully',
      });
    } catch (err: any) {
      console.error('Error downloading PDF:', err);
      const errorMessage = err.response?.data?.error || 'Failed to download PDF report. Please try again.';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredInventory = inventory.filter((item) =>
    (typeof item.item === 'string' ? item.item.toLowerCase().includes(searchTerm.toLowerCase()) : false) ||
    (typeof item.vendor === 'string' ? item.vendor.toLowerCase().includes(searchTerm.toLowerCase()) : false)
  );

  if (!hasPermission('read')) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <Card className="text-center py-12">
          <CardContent>
            <div className="text-red-500 text-6xl mb-4">🔒</div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
            <p className="text-gray-600">You do not have permission to view inventory.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {apiError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
          <span>{apiError}</span>
        </div>
      )}

      {loading && (
        <div className="flex justify-center items-center py-6">
          <RefreshCw className="animate-spin h-8 w-8 text-blue-500" />
          <span className="ml-2 text-gray-700">Loading...</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-3 sm:space-y-0">
        <h1 className="text-xl sm:text-2xl font-bold">Inventory List</h1>
        <div className="flex space-x-3">
          <div className="relative">
            <input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={loading}
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </div>
          <Button
            variant="outline"
            onClick={handleRefresh}
            className="px-4 py-2"
            disabled={loading || !hasPermission('read')}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          {hasPermission('create') && (
            <Dialog open={isAddEditDialogOpen} onOpenChange={setIsAddEditDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={resetForm}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 min-w-[160px] justify-center"
                  disabled={loading}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <LightGlassCard className="p-6" gradient>
                  <DialogHeader>
                    <DialogTitle>{editingId !== null ? 'Edit Item' : 'Add Item'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleAddOrUpdateItem} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Vendor *</label>
                        <input
                          name="vendor"
                          value={formData.vendor}
                          onChange={handleInputChange}
                          type="text"
                          required
                          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                        />
                        {apiError?.includes('Vendor') && <p className="text-red-500 text-xs mt-1">{apiError}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Item *</label>
                        <input
                          name="item"
                          value={formData.item}
                          onChange={handleInputChange}
                          type="text"
                          required
                          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                        />
                        {apiError?.includes('Item') && <p className="text-red-500 text-xs mt-1">{apiError}</p>}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Unit Price *</label>
                        <input
                          name="unitPrice"
                          value={formData.unitPrice || ''}
                          onChange={handleInputChange}
                          type="number"
                          step="0.01"
                          min="0"
                          required
                          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                        />
                        {apiError?.includes('Unit Price') && <p className="text-red-500 text-xs mt-1">{apiError}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Quantity *</label>
                        <input
                          name="quantity"
                          value={formData.quantity || ''}
                          onChange={handleInputChange}
                          type="number"
                          min="0"
                          required
                          className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                        />
                        {apiError?.includes('Quantity') && <p className="text-red-500 text-xs mt-1">{apiError}</p>}
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Item Type *</label>
                      <input
                        name="itemType"
                        value={formData.itemType || ''}
                        onChange={handleInputChange}
                        type="text"
                        required
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                      />
                      {apiError?.includes('Item Type') && <p className="text-red-500 text-xs mt-1">{apiError}</p>}
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                      <textarea
                        name="description"
                        value={formData.description || ''}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm border-gray-300"
                        rows={3}
                      />
                    </div>
                    {apiError && !apiError.includes('Vendor') && !apiError.includes('Item') && !apiError.includes('Unit Price') && !apiError.includes('Quantity') && !apiError.includes('Item Type') && (
                      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
                        {apiError}
                      </div>
                    )}
                    <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsAddEditDialogOpen(false)}
                        className="flex-1"
                        disabled={loading}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:from-blue-600 hover:to-purple-700"
                        disabled={loading || !formData.vendor || !formData.item || !formData.unitPrice || !formData.quantity || !formData.itemType}
                      >
                        <Save className="h-4 w-4 mr-2" />
                        {loading ? 'Saving...' : (editingId !== null ? 'Update' : 'Add') + ' Item'}
                      </Button>
                    </div>
                  </form>
                </LightGlassCard>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-gray-700">Are you sure you want to delete this inventory item? This action cannot be undone.</p>
            <div className="flex justify-end space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsDeleteDialogOpen(false);
                  setItemToDelete(null);
                }}
                disabled={loading}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={handleDelete}
                disabled={loading}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <Eye className="h-5 w-5 mr-2" />
                View Inventory Item
              </DialogTitle>
            </DialogHeader>
            {viewingItem && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Vendor</label>
                    <p className="text-lg text-gray-900">{viewingItem.vendor || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Item</label>
                    <p className="text-lg text-gray-900">{viewingItem.item || 'N/A'}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Unit Price</label>
                    <p className="text-lg text-gray-900">Rs {(viewingItem.unitPrice || 0).toFixed(2)}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Quantity</label>
                    <p className="text-lg text-gray-900">{viewingItem.quantity || 0}</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Item Type</label>
                    <p className="text-lg text-gray-900">{viewingItem.itemType || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-500 mb-1">Description</label>
                    <p className="text-lg text-gray-900">{viewingItem.description || 'N/A'}</p>
                  </div>
                </div>
                <div className="flex justify-end pt-6">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsViewDialogOpen(false);
                      setViewingItem(null);
                    }}
                    className="px-6 py-2"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Close
                  </Button>
                </div>
              </div>
            )}
          </LightGlassCard>
        </DialogContent>
      </Dialog>

      <div className="bg-white rounded-lg border border-border shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full table-auto text-left">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Vendor</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Item</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Unit Price</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Quantity</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Item Type</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Description</th>
                <th className="px-3 sm:px-6 py-3 text-xs sm:text-sm font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center">
                      <RefreshCw className="animate-spin h-12 w-12 mb-2 text-blue-500" />
                      <p className="text-lg font-medium mb-1">Loading inventory...</p>
                    </div>
                  </td>
                </tr>
              ) : filteredInventory.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center">
                      <Grid2x2Plus className="h-12 w-12 mb-2 text-gray-400" />
                      <p className="text-lg font-medium mb-1">No inventory items yet</p>
                      {hasPermission('create') && (
                        <p className="text-sm">Click "Add Item" to get started</p>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredInventory.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="font-medium text-gray-900">{item.vendor || 'N/A'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{item.item || 'N/A'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">Rs {(item.unitPrice || 0).toFixed(2)}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{item.quantity || 0}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700">{item.itemType || 'N/A'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <span className="text-gray-700 truncate block max-w-xs">{item.description || 'N/A'}</span>
                    </td>
                    <td className="px-3 sm:px-6 py-4 text-xs sm:text-sm">
                      <div className="flex flex-col sm:flex-row space-y-1 sm:space-y-0 sm:space-x-2">
                        {hasPermission('read') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleView(item)}
                            className="hover:bg-blue-50 text-xs px-2 py-1"
                            disabled={loading}
                            title="View Item"
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                        )}
                        {hasPermission('update') && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(item.id!)}
                            className="hover:bg-blue-50 text-xs px-2 py-1"
                            disabled={loading}
                            title="Edit Item"
                          >
                            <Pencil className="h-3 w-3" />
                          </Button>
                        )}
                        {hasPermission('delete') && (
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              setItemToDelete(item.id!);
                              setIsDeleteDialogOpen(true);
                            }}
                            className="border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 text-xs px-2 py-1"
                            disabled={loading}
                            title="Delete Item"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {hasPermission('download') && (
        <div className="mt-4 flex justify-end">
          <Button
            onClick={handleDownloadPDF}
            className="bg-blue-600 hover:bg-blue-700 text-white"
            disabled={loading}
          >
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
        </div>
      )}

      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
        <p className="text-sm text-gray-600">
          <strong>Your permissions:</strong> {allowedActions.length > 0 ? allowedActions.join(', ') : 'None'}
        </p>
      </div>
    </div>
  );
};

export default InventoryForm;