import React, { useState, useEffect } from 'react';
import { customerAPI } from '../services/customers';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog'; // Added Dialog imports
import { Save, Edit, Trash2, Check, X, Plus, Search, Phone, RefreshCw, User, Briefcase, MapPin, Download } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

interface Customer {
  id: number;
  name: string;
  phone: string;
  address: string;
  amount: number;
}

interface ValidationErrors {
  name?: string;
  phone?: string;
  address?: string;
  amount?: string;
  adjustAmount?: string;
}

const LightGlassCard = ({ children, className = '', gradient = false }: { children: React.ReactNode; className?: string; gradient?: boolean }) => (
  <div className={`backdrop-blur-xl bg-white/80 border border-gray-200/50 rounded-2xl shadow-lg ${gradient ? 'bg-gradient-to-br from-white/90 to-gray-50/80' : ''} ${className}`}>
    {children}
  </div>
);

const CustomerForm: React.FC = () => {
  const [formData, setFormData] = useState<Customer>({
    id: 0,
    name: '',
    phone: '',
    address: '',
    amount: 0,
  });

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [editForm, setEditForm] = useState<Customer | null>(null);
  const [adjustAmount, setAdjustAmount] = useState<string>(''); // For adding/subtracting amount
  const [adjustmentType, setAdjustmentType] = useState<'add' | 'subtract' | ''>(''); // Track adjustment type
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [apiError, setApiError] = useState<string | null>(null);
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false); // Added for delete dialog
  const [itemToDelete, setItemToDelete] = useState<number | null>(null); // Added for delete dialog

  const fetchCustomers = async () => {
    try {
      const response = await customerAPI.getCustomers();
      const data = response?.data ?? [];
      setCustomers(Array.isArray(data) ? data : []);
      setApiError(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to fetch customers';
      setApiError(errorMessage);
      console.error('Fetch customers error:', err);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const validateForm = (data: Customer, isEdit: boolean = false): ValidationErrors => {
    const newErrors: ValidationErrors = {};
    if (!data.name.trim()) newErrors.name = 'Name is required';
    if (isEdit && adjustAmount) {
      const adjustValue = parseFloat(adjustAmount);
      if (isNaN(adjustValue) || adjustValue < 0) {
        newErrors.adjustAmount = 'Adjustment amount must be a positive number';
      } else if (adjustmentType === 'subtract' && adjustValue > data.amount) {
        newErrors.adjustAmount = 'Cannot subtract more than current amount';
      }
    } else if (!isEdit && (isNaN(data.amount) || data.amount < 0)) {
      newErrors.amount = 'Initial amount must be a non-negative number';
    }
    return newErrors;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'amount' ? parseFloat(value) || 0 : value,
    }));
    if (errors[name as keyof ValidationErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (editForm) {
      setEditForm({
        ...editForm,
        [name]: name === 'amount' ? parseFloat(value) || 0 : value,
      });
    }
    if (errors[name as keyof ValidationErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleAdjustAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setAdjustAmount(e.target.value);
    if (errors.adjustAmount) {
      setErrors(prev => ({ ...prev, adjustAmount: undefined }));
    }
  };

  const handleAddCustomer = async () => {
    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      return;
    }

    try {
      const response = await customerAPI.createCustomer({
        name: formData.name,
        phone: formData.phone,
        address: formData.address,
        amount: formData.amount,
      });
      setCustomers([...customers, response.data]);
      setFormData({
        id: 0,
        name: '',
        phone: '',
        address: '',
        amount: 0,
      });
      setErrors({});
      setShowAddModal(false);
      setApiError(null);
      toast({
        title: 'Success',
        description: 'Customer added successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to create customer';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setEditForm({ ...customer });
    setAdjustAmount('');
    setAdjustmentType('');
  };

  const handleSaveEdit = async () => {
    if (!editForm) return;

    const validationErrors = validateForm(editForm, true);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      toast({
        title: 'Error',
        description: 'Please correct the form errors',
        variant: 'destructive',
      });
      return;
    }

    try {
      let updatedAmount = editForm.amount;
      if (adjustAmount && adjustmentType) {
        const adjustValue = parseFloat(adjustAmount);
        updatedAmount = adjustmentType === 'add' ? editForm.amount + adjustValue : editForm.amount - adjustValue;
      }

      const response = await customerAPI.updateCustomer(`/${editForm.id}`, {
        name: editForm.name,
        phone: editForm.phone,
        address: editForm.address,
        amount: updatedAmount,
      });
      setCustomers(customers.map(cust =>
        cust.id === editForm.id ? response.data : cust
      ));
      setEditingCustomer(null);
      setEditForm(null);
      setAdjustAmount('');
      setAdjustmentType('');
      setErrors({});
      setApiError(null);
      toast({
        title: 'Success',
        description: 'Customer updated successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to update customer';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  const handleDownloadPDF = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await customerAPI.downloadCustomersPdf();
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'customers-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download PDF error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number, event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();

    setItemToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = async () => {
    if (!itemToDelete) return;

    try {
      await customerAPI.deleteCustomer(`/${itemToDelete}`);
      setCustomers(customers.filter(cust => cust.id !== itemToDelete));
      if (editingCustomer?.id === itemToDelete) {
        setEditingCustomer(null);
        setEditForm(null);
      }
      setApiError(null);
      toast({
        title: 'Success',
        description: 'Customer deleted successfully',
      });
      setIsDeleteDialogOpen(false);
      setItemToDelete(null);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to delete customer';
      setApiError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6 lg:space-y-8 p-3 sm:p-4 lg:p-6 bg-gradient-to-br from-blue-50 via-white to-purple-50 min-h-screen">
      {apiError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <span>{apiError}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 flex items-center">
          <Briefcase className="w-6 h-6 sm:w-8 sm:h-8 mr-2 sm:mr-3 text-blue-600" />
          Account/Customers Management
        </h2>
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          <Button
            onClick={fetchCustomers}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white transition-all duration-200 text-sm"
          >
            <RefreshCw className="w-4 h-4 mr-2" /> Refresh
          </Button>
          <Button
            onClick={handleDownloadPDF}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white transition-all duration-200 text-sm"
          >
            <Download className="w-4 h-4 mr-2" /> Download Pdf
          </Button>
          <Button
            onClick={() => setShowAddModal(true)}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white transition-all duration-200 text-sm"
          >
            <Plus className="w-4 h-4 mr-2" /> Add Customer
          </Button>
        </div>
      </div>

      <LightGlassCard className="p-4 sm:p-6" gradient>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-700">
            <thead className="text-xs text-gray-500 uppercase bg-gray-50">
              <tr>
                <th className="px-4 py-3 sm:px-6">Name</th>
                <th className="px-4 py-3 sm:px-6">Phone</th>
                <th className="px-4 py-3 sm:px-6">Address</th>
                <th className="px-4 py-3 sm:px-6">Amount (Rs)</th>
                <th className="px-4 py-3 sm:px-6">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-4 sm:px-6 text-center text-gray-500">
                    No customers found
                  </td>
                </tr>
              ) : (
                filteredCustomers.map(customer => (
                  <tr key={customer.id} className="border-b hover:bg-gray-50/50">
                    <td className="px-4 py-4 sm:px-6">{customer.name}</td>
                    <td className="px-4 py-4 sm:px-6">{customer.phone || 'N/A'}</td>
                    <td className="px-4 py-4 sm:px-6">{customer.address || 'N/A'}</td>
                    <td className="px-4 py-4 sm:px-6">Rs {customer.amount.toFixed(2)}</td>
                    <td className="px-4 py-4 sm:px-6">
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => handleEdit(customer)}
                          className="p-1 bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={(e) => handleDelete(customer.id, e)}
                          className="p-1 bg-red-100 text-red-600 hover:bg-red-200 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </LightGlassCard>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <LightGlassCard className="p-4 sm:p-6 w-full max-w-sm sm:max-w-md max-h-[90vh] overflow-y-auto" gradient>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg sm:text-xl font-bold text-gray-800">Add Customer</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">* Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.name ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                  placeholder="Enter Name"
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.phone ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                  placeholder="+1 555-123-4567"
                />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <input
                  type="text"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.address ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                  placeholder="123 Business Ave, City, State ZIP"
                />
                {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Initial Amount (Rs)</label>
                <input
                  type="number"
                  name="amount"
                  value={formData.amount}
                  onChange={handleChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.amount ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                  placeholder="0.00"
                />
                {errors.amount && <p className="text-red-500 text-xs mt-1">{errors.amount}</p>}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleAddCustomer}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 text-sm"
              >
                Add Customer
              </button>
            </div>
          </LightGlassCard>
        </div>
      )}

      {editingCustomer && editForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <LightGlassCard className="p-4 sm:p-6 w-full max-w-sm sm:max-w-md max-h-[90vh] overflow-y-auto" gradient>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg sm:text-xl font-bold text-gray-800">Edit Customer</h3>
              <button
                onClick={() => setEditingCustomer(null)}
                className="p-1 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">* Name</label>
                <input
                  type="text"
                  name="name"
                  value={editForm.name}
                  onChange={handleEditChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.name ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                />
                {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  value={editForm.phone}
                  onChange={handleEditChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.phone ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                />
                {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <input
                  type="text"
                  name="address"
                  value={editForm.address}
                  onChange={handleEditChange}
                  className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.address ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                />
                {errors.address && <p className="text-red-500 text-xs mt-1">{errors.address}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Current Amount (Rs)</label>
                <input
                  type="number"
                  value={editForm.amount.toFixed(2)}
                  readOnly
                  className="w-full px-3 py-2 border rounded-lg bg-gray-100 cursor-not-allowed text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Adjust Amount (Rs)</label>
                <div className="flex space-x-2">
                  <select
                    value={adjustmentType}
                    onChange={(e) => setAdjustmentType(e.target.value as 'add' | 'subtract' | '')}
                    className="w-1/3 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                  >
                    <option value="">Select</option>
                    <option value="add">Add</option>
                    <option value="subtract">Subtract</option>
                  </select>
                  <input
                    type="number"
                    value={adjustAmount}
                    onChange={handleAdjustAmountChange}
                    className={`w-2/3 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm ${errors.adjustAmount ? 'border-red-500 bg-red-50' : 'border-gray-300'}`}
                    placeholder="0.00"
                  />
                </div>
                {errors.adjustAmount && <p className="text-red-500 text-xs mt-1">{errors.adjustAmount}</p>}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 mt-6">
              <button
                onClick={() => setEditingCustomer(null)}
                className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveEdit}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 text-sm"
              >
                Save Changes
              </button>
            </div>
          </LightGlassCard>
        </div>
      )}

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <LightGlassCard className="p-6" gradient>
            <DialogHeader>
              <DialogTitle>Confirm Delete</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <p className="text-sm text-gray-700">
                Are you sure you want to delete this customer? This action cannot be undone.
              </p>
              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsDeleteDialogOpen(false);
                    setItemToDelete(null);
                  }}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={confirmDelete}
                  disabled={loading || !itemToDelete}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </div>
          </LightGlassCard>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerForm;