import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Save, Plus, RefreshCw, Edit, Trash2, Search, Download, Grid2x2Plus, Eye } from 'lucide-react';
import { quoteAPI } from '../services/quotes';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface QuoteItem {
  item: string;
  description: string;
  quantity: number;
  price: number;
}

interface QuoteData {
  id?: string;
  number: string;
  companyname: string;
  representative: string;
  email: string;
  address: string;
  phone: string;
  date: string;
  expireDate: string;
  year: string;
  currency: string;
  status: 'draft' | 'pending' | 'sent' | 'accepted' | 'declined' | 'expired';
  paid: number;
  total: number;
  note: string;
  items: QuoteItem[];
  createdBy: string;
  tax?: number;
}

interface ValidationErrors {
  number?: string;
  companyname?: string;
  representative?: string;
  email?: string;
  address?: string;
  phone?: string;
  date?: string;
  expireDate?: string;
  year?: string;
  currency?: string;
  items?: string;
  [key: string]: string | undefined;
}

interface QuotesProps {
  allowedActions: string[];
}

const Quotes: React.FC<QuotesProps> = ({ allowedActions }) => {
  const { toast } = useToast();
  const [quotes, setQuotes] = useState<QuoteData[]>([]);
  const [newQuote, setNewQuote] = useState<QuoteData>({
    number: '',
    companyname: '',
    representative: '',
    email: '',
    address: '',
    phone: '',
    date: new Date().toISOString().split('T')[0],
    expireDate: '',
    year: new Date().getFullYear().toString(),
    currency: 'PKR',
    status: 'draft',
    paid: 0,
    total: 0,
    note: '',
    items: [{ item: '', description: '', quantity: 0, price: 0 }],
    createdBy: 'Admin',
    tax: 0,
  });
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [quoteToDelete, setQuoteToDelete] = useState<string | null>(null);
  const [selectedQuote, setSelectedQuote] = useState<QuoteData | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [visibleQuotes, setVisibleQuotes] = useState(10);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [downloadLoading, setDownloadLoading] = useState<string | null>(null);
  const [errors, setErrors] = useState<ValidationErrors>({});

  useEffect(() => {
    const fetchData = async () => {
      await loadQuotes();
    };
    fetchData();
  }, []);

  useEffect(() => {
    const table = document.querySelector('.quote-table-container');
    if (table) {
      table.addEventListener('scroll', handleScroll);
      return () => table.removeEventListener('scroll', handleScroll);
    }
  }, []);

  const loadQuotes = async () => {
    if (!allowedActions.includes('read')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to read quotes',
        variant: 'destructive',
      });
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await quoteAPI.getQuotes();
      if (!Array.isArray(response.data)) {
        throw new Error('Expected an array of quotes');
      }
      const updatedQuotes = response.data.map(quote => ({
        ...quote,
        id: String(quote.id),
        total: calculateTotal(quote),
      }));
      setQuotes(updatedQuotes);
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to load quotes';
      setError(errorMessage);
      setQuotes([]);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Load quotes error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleScroll = () => {
    const table = document.querySelector('.quote-table-container');
    if (table) {
      const { scrollTop, scrollHeight, clientHeight } = table;
      if (scrollTop + clientHeight >= scrollHeight - 20) {
        setVisibleQuotes(prev => prev + 10);
      }
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setNewQuote({
      ...newQuote,
      [name]: name === 'paid' || name === 'tax' ? parseFloat(value) || 0 : value,
    });
    setErrors(prev => ({ ...prev, [name]: undefined }));
  };

  const handleItemChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const updatedItems = [...newQuote.items];
    updatedItems[index] = {
      ...updatedItems[index],
      [e.target.name]: e.target.name === 'quantity' || e.target.name === 'price'
        ? parseFloat(e.target.value) || 0
        : e.target.value,
    };
    setNewQuote({ ...newQuote, items: updatedItems });
    setErrors(prev => ({
      ...prev,
      [`item_${index}`]: undefined,
      [`quantity_${index}`]: undefined,
      [`price_${index}`]: undefined,
      [`description_${index}`]: undefined,
    }));
  };

  const addItem = () => {
    setNewQuote({
      ...newQuote,
      items: [...newQuote.items, { item: '', description: '', quantity: 0, price: 0 }],
    });
  };

  const removeItem = (index: number) => {
    const updatedItems = newQuote.items.filter((_, i) => i !== index);
    setNewQuote({ ...newQuote, items: updatedItems });
  };

  const calculateSubtotal = () => {
    return newQuote.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
  };

  const calculateTotal = (quote?: QuoteData) => {
    const targetQuote = quote || newQuote;
    const subtotal = targetQuote.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
    const taxAmount = targetQuote.tax ? subtotal * (targetQuote.tax / 100) : 0;
    return subtotal + taxAmount;
  };

  const validateQuote = (data: QuoteData): ValidationErrors => {
    const errors: ValidationErrors = {};
    if (!data.number.trim()) errors.number = 'Quote number is required';
    if (!data.companyname.trim()) errors.companyname = 'Company name is required';
    if (!data.representative.trim()) errors.representative = 'Representative is required';
    if (!data.email.trim()) errors.email = 'Email is required';
    if (!data.address.trim()) errors.address = 'Address is required';
    if (!data.phone.trim()) errors.phone = 'Phone is required';
    if (!data.date) errors.date = 'Date is required';
    if (!data.expireDate) errors.expireDate = 'Expire date is required';
    if (!data.year) errors.year = 'Year is required';
    if (!data.currency) errors.currency = 'Currency is required';
    if (data.items.length === 0) errors.items = 'At least one item is required';
    data.items.forEach((item, index) => {
      if (!item.item.trim()) errors[`item_${index}`] = `Item name is required for item ${index + 1}`;
      if (item.quantity <= 0) errors[`quantity_${index}`] = `Quantity must be greater than 0 for item ${index + 1}`;
      if (item.price <= 0) errors[`price_${index}`] = `Price must be greater than 0 for item ${index + 1}`;
      if (!item.description.trim()) errors[`description_${index}`] = `Description is required for item ${index + 1}`;
    });
    return errors;
  };

  const handleSave = async () => {
    if (!allowedActions.includes(editingId ? 'update' : 'create')) {
      toast({
        title: 'Error',
        description: `You are not authorized to ${editingId ? 'update' : 'create'} quotes`,
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const validationErrors = validateQuote(newQuote);
      if (Object.keys(validationErrors).length > 0) {
        setErrors(validationErrors);
        setLoading(false);
        toast({
          title: 'Error',
          description: 'Please correct the form errors',
          variant: 'destructive',
        });
        return;
      }

      const total = calculateTotal();
      const isExpired = new Date(newQuote.expireDate) < new Date() && !['accepted', 'declined'].includes(newQuote.status);
      const finalStatus = isExpired ? 'expired' : newQuote.status;

      const quoteToSave = {
        ...newQuote,
        total,
        status: finalStatus,
        year: newQuote.year.toString(),
        paid: newQuote.paid ? parseFloat(newQuote.paid.toString()) : 0,
        tax: newQuote.tax ? parseFloat(newQuote.tax.toString()) : 0,
        items: newQuote.items.map(item => ({
          ...item,
          quantity: parseFloat(item.quantity.toString()),
          price: parseFloat(item.price.toString()),
        })),
      };

      if (editingId) {
        await quoteAPI.updateQuote(editingId, quoteToSave);
      } else {
        await quoteAPI.createQuote(quoteToSave);
      }

      await loadQuotes();
      setOpen(false);
      setEditingId(null);
      setNewQuote({
        number: '',
        companyname: '',
        representative: '',
        email: '',
        address: '',
        phone: '',
        date: new Date().toISOString().split('T')[0],
        expireDate: '',
        year: new Date().getFullYear().toString(),
        currency: 'PKR',
        status: 'draft',
        paid: 0,
        total: 0,
        note: '',
        items: [{ item: '', description: '', quantity: 0, price: 0 }],
        createdBy: 'Admin',
        tax: 0,
      });
      setErrors({});
      toast({
        title: 'Success',
        description: editingId ? 'Quote updated successfully' : 'Quote created successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to save quote';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Save quote error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (id: string) => {
    if (!allowedActions.includes('update')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to update quotes',
        variant: 'destructive',
      });
      return;
    }
    if (!id) {
      setError('Quote ID is missing');
      toast({
        title: 'Error',
        description: 'Quote ID is missing',
        variant: 'destructive',
      });
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const response = await quoteAPI.getQuote(id);
      if (!response.data) {
        throw new Error('Invalid quote data');
      }
      setNewQuote({
        ...response.data,
        id: String(response.data.id),
        year: response.data.year.toString(),
        paid: parseFloat(response.data.paid.toString()) || 0,
        tax: parseFloat(response.data.tax?.toString() || '0'),
        items: response.data.items.map(item => ({
          ...item,
          quantity: parseFloat(item.quantity.toString()),
          price: parseFloat(item.price.toString()),
        })),
      });
      setEditingId(id);
      setOpen(true);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to load quote for editing';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Edit quote error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!allowedActions.includes('delete')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to delete quotes',
        variant: 'destructive',
      });
      return;
    }
    if (!id) {
      setError('Quote ID is missing');
      toast({
        title: 'Error',
        description: 'Quote ID is missing',
        variant: 'destructive',
      });
      return;
    }
    setQuoteToDelete(id);
    setDeleteOpen(true);
  };

  const confirmDelete = async () => {
    if (!quoteToDelete) return;
    setLoading(true);
    setError(null);
    try {
      await quoteAPI.deleteQuote(quoteToDelete);
      await loadQuotes();
      toast({
        title: 'Success',
        description: 'Quote deleted successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to delete quote';
      setError(errorMessage);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Delete quote error:', err);
    } finally {
      setLoading(false);
      setDeleteOpen(false);
      setQuoteToDelete(null);
    }
  };

  const handleView = (quote: QuoteData) => {
    if (!allowedActions.includes('read')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to view quote details',
        variant: 'destructive',
      });
      return;
    }
    setSelectedQuote(quote);
    setViewOpen(true);
  };

  const handleDownloadPDF = async () => {
    if (!allowedActions.includes('read')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to download quotes',
        variant: 'destructive',
      });
      return;
    }
    try {
      const response = await quoteAPI.downloadQuotesPDF();
      const url = window.URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'quotes-report.pdf');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Failed to download PDF';
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
      console.error('Download PDF error:', err);
    }
  };

  const downloadPDF = async (id: string) => {
    if (!allowedActions.includes('read')) {
      toast({
        title: 'Error',
        description: 'You are not authorized to download quotes',
        variant: 'destructive',
      });
      return;
    }

    setDownloadLoading(id);
    try {
      const quoteResponse = await quoteAPI.getQuote(id);
      const quoteNumber = quoteResponse.data.number || id;

      const response = await quoteAPI.downloadQuotePDFById(id);
      if (!(response.data instanceof Blob)) {
        throw new Error('Invalid response: Expected a Blob');
      }

      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${quoteNumber}.pdf`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({
        title: 'Success',
        description: 'PDF downloaded successfully',
      });
    } catch (err: any) {
      let errorMessage = err.message || 'Failed to download PDF';
      if (err.response && err.response.data instanceof Blob) {
        const text = await err.response.data.text();
        try {
          const json = JSON.parse(text);
          errorMessage = json.error || errorMessage;
        } catch (e) {
          errorMessage = 'Invalid response from server';
        }
      } else if (err.response?.data?.error) {
        errorMessage = err.response.data.error;
      }
      console.error('Download PDF error:', err);
      toast({
        title: 'Error',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setDownloadLoading(null);
    }
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setOpen(false);
      setEditingId(null);
      setNewQuote({
        number: '',
        companyname: '',
        representative: '',
        email: '',
        address: '',
        phone: '',
        date: new Date().toISOString().split('T')[0],
        expireDate: '',
        year: new Date().getFullYear().toString(),
        currency: 'PKR',
        status: 'draft',
        paid: 0,
        total: 0,
        note: '',
        items: [{ item: '', description: '', quantity: 0, price: 0 }],
        createdBy: 'Admin',
        tax: 0,
      });
      setErrors({});
    }
  };

  const handleViewBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      setViewOpen(false);
      setSelectedQuote(null);
    }
  };

  const filteredQuotes = quotes
    .filter(quote =>
      quote.companyname.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.status.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .slice(0, visibleQuotes);

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error}
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 space-y-3 sm:space-y-0">
        <h1 className="text-xl sm:text-2xl font-bold">Quote List</h1>
        <div className="flex space-x-3">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </div>
          <Button
            variant="outline"
            onClick={loadQuotes}
            className="px-4 py-2"
            disabled={loading || !allowedActions.includes('read')}
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button
            variant="outline"
            onClick={handleDownloadPDF}
            className="px-4 py-2"
            disabled={loading || !allowedActions.includes('read')}
          >
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          {allowedActions.includes('create') && (
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 min-w-[160px] justify-center">
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Quote
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                <div onClick={handleBackdropClick}>
                  <DialogHeader>
                    <DialogTitle>{editingId ? 'Edit Quote' : 'New Quote'}</DialogTitle>
                  </DialogHeader>
                  <form className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="companyname">* Company Name</Label>
                        <Input
                          name="companyname"
                          value={newQuote.companyname}
                          onChange={handleChange}
                          type="text"
                          placeholder="Company Name"
                          className={errors.companyname ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.companyname && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.companyname}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="representative">* Representative</Label>
                        <Input
                          name="representative"
                          value={newQuote.representative}
                          onChange={handleChange}
                          type="text"
                          placeholder="Representative Name"
                          className={errors.representative ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.representative && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.representative}</p>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">* Email</Label>
                        <Input
                          name="email"
                          value={newQuote.email}
                          onChange={handleChange}
                          type="email"
                          placeholder="Email"
                          className={errors.email ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.email && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.email}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">* Phone</Label>
                        <Input
                          name="phone"
                          value={newQuote.phone}
                          onChange={handleChange}
                          type="text"
                          placeholder="Phone"
                          className={errors.phone ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.phone && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.phone}</p>
                        )}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="address">* Address</Label>
                      <Input
                        name="address"
                        value={newQuote.address}
                        onChange={handleChange}
                        type="text"
                        placeholder="Address"
                        className={errors.address ? 'border-red-500 bg-red-50' : ''}
                        required
                      />
                      {errors.address && (
                        <p className="text-red-600 text-sm mt-1 font-medium">{errors.address}</p>
                      )}
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="date">* Date</Label>
                        <Input
                          name="date"
                          value={newQuote.date}
                          onChange={handleChange}
                          type="date"
                          className={errors.date ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.date && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.date}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="expireDate">* Expire Date</Label>
                        <Input
                          name="expireDate"
                          value={newQuote.expireDate}
                          onChange={handleChange}
                          type="date"
                          className={errors.expireDate ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.expireDate && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.expireDate}</p>
                        )}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="number">* Number</Label>
                        <Input
                          name="number"
                          value={newQuote.number}
                          onChange={handleChange}
                          type="text"
                          placeholder="QUO-001"
                          className={errors.number ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.number && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.number}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="year">* Year</Label>
                        <Input
                          name="year"
                          value={newQuote.year}
                          onChange={handleChange}
                          type="text"
                          className={errors.year ? 'border-red-500 bg-red-50' : ''}
                          required
                        />
                        {errors.year && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.year}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="currency">* Currency</Label>
                        <Select
                          value={newQuote.currency}
                          onValueChange={(value) => handleChange({ target: { name: 'currency', value } } as any)}
                        >
                          <SelectTrigger className={errors.currency ? 'border-red-500 bg-red-50' : ''}>
                            <SelectValue placeholder="Select Currency" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="PKR">PKR (Pakistan Rupee)</SelectItem>
                            <SelectItem value="USD">USD</SelectItem>
                          </SelectContent>
                        </Select>
                        {errors.currency && (
                          <p className="text-red-600 text-sm mt-1 font-medium">{errors.currency}</p>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="status">Status</Label>
                        <Select
                          value={newQuote.status}
                          onValueChange={(value) => handleChange({ target: { name: 'status', value } } as any)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select Status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="draft">Draft</SelectItem>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="sent">Sent</SelectItem>
                            <SelectItem value="accepted">Accepted</SelectItem>
                            <SelectItem value="declined">Declined</SelectItem>
                            <SelectItem value="expired" disabled>Expired (Auto-calculated)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="tax">Tax (%)</Label>
                      <Input
                        name="tax"
                        value={newQuote.tax || ''}
                        onChange={handleChange}
                        type="number"
                        min="0"
                        step="0.01"
                        placeholder="Tax Percentage"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="note">Note</Label>
                      <Input
                        name="note"
                        value={newQuote.note}
                        onChange={handleChange}
                        type="text"
                        placeholder="Optional note"
                      />
                    </div>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium">* Item Description</h3>
                        <Button type="button" variant="outline" size="sm" onClick={addItem}>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Field
                        </Button>
                      </div>
                      <div className="grid grid-cols-12 gap-2 font-medium text-sm">
                        <div className="col-span-4">* Item</div>
                        <div className="col-span-2">* Quantity</div>
                        <div className="col-span-2">* Price</div>
                        <div className="col-span-3">* Description</div>
                        <div className="col-span-1"></div>
                      </div>
                      {newQuote.items.map((item, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-4">
                            <Input
                              name="item"
                              value={item.item}
                              onChange={e => handleItemChange(index, e)}
                              type="text"
                              placeholder="Item Name"
                              className={errors[`item_${index}`] ? 'border-red-500 bg-red-50' : ''}
                              required
                            />
                            {errors[`item_${index}`] && (
                              <p className="text-red-600 text-sm mt-1 font-medium">{errors[`item_${index}`]}</p>
                            )}
                          </div>
                          <div className="col-span-2">
                            <Input
                              name="quantity"
                              value={item.quantity || ''}
                              onChange={e => handleItemChange(index, e)}
                              type="number"
                              min="0"
                              className={errors[`quantity_${index}`] ? 'border-red-500 bg-red-50' : ''}
                              required
                            />
                            {errors[`quantity_${index}`] && (
                              <p className="text-red-600 text-sm mt-1 font-medium">{errors[`quantity_${index}`]}</p>
                            )}
                          </div>
                          <div className="col-span-2">
                            <Input
                              name="price"
                              value={item.price || ''}
                              onChange={e => handleItemChange(index, e)}
                              type="number"
                              min="0"
                              step="0.01"
                              className={errors[`price_${index}`] ? 'border-red-500 bg-red-50' : ''}
                              required
                            />
                            {errors[`price_${index}`] && (
                              <p className="text-red-600 text-sm mt-1 font-medium">{errors[`price_${index}`]}</p>
                            )}
                          </div>
                          <div className="col-span-3">
                            <Input
                              name="description"
                              value={item.description}
                              onChange={e => handleItemChange(index, e)}
                              type="text"
                              placeholder="Description"
                              className={errors[`description_${index}`] ? 'border-red-500 bg-red-50' : ''}
                              required
                            />
                            {errors[`description_${index}`] && (
                              <p className="text-red-600 text-sm mt-1 font-medium">{errors[`description_${index}`]}</p>
                            )}
                          </div>
                          <div className="col-span-1">
                            <Button
                              type="button"
                              variant="destructive"
                              size="sm"
                              onClick={() => removeItem(index)}
                              disabled={newQuote.items.length === 1}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                      {errors.items && (
                        <p className="text-red-600 text-sm mt-1 font-medium">{errors.items}</p>
                      )}
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-medium">Summary</h3>
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>{newQuote.currency} {calculateSubtotal().toFixed(2)}</span>
                      </div>
                      {newQuote.tax > 0 && (
                        <div className="flex justify-between">
                          <span>Tax ({newQuote.tax}%):</span>
                          <span>{newQuote.currency} {(calculateSubtotal() * (newQuote.tax / 100)).toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-bold">
                        <span>Total:</span>
                        <span>{newQuote.currency} {calculateTotal().toFixed(2)}</span>
                      </div>
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setOpen(false);
                          setEditingId(null);
                          setNewQuote({
                            number: '',
                            companyname: '',
                            representative: '',
                            email: '',
                            address: '',
                            phone: '',
                            date: new Date().toISOString().split('T')[0],
                            expireDate: '',
                            year: new Date().getFullYear().toString(),
                            currency: 'PKR',
                            status: 'draft',
                            paid: 0,
                            total: 0,
                            note: '',
                            items: [{ item: '', description: '', quantity: 0, price: 0 }],
                            createdBy: 'Admin',
                            tax: 0,
                          });
                          setErrors({});
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="button"
                        onClick={handleSave}
                        disabled={loading}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Save className="h-4 w-4 mr-2" />
                        {editingId ? 'Update' : 'Save'}
                      </Button>
                    </div>
                  </form>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <div className="quote-table-container max-h-[70vh] overflow-y-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead className="bg-gray-50 sticky top-0 z-10">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Number</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Currency</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expire Date</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tax</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredQuotes.map((quote, index) => (
              <tr key={quote.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                <td className="px-4 py-2 text-sm">{quote.number}</td>
                <td className="px-4 py-2 text-sm">{quote.companyname}</td>
                <td className="px-4 py-2 text-sm">{quote.currency}</td>
                <td className="px-4 py-2 text-sm">{new Date(quote.date).toLocaleDateString()}</td>
                 <td className="px-4 py-2 text-sm">{new Date(quote.expireDate).toLocaleDateString()}</td>
                <td className="px-4 py-2 text-sm">
                  <span
                    className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${
                      quote.status === 'accepted' ? 'bg-green-100 text-green-800' :
                      quote.status === 'declined' || quote.status === 'expired' ? 'bg-red-100 text-red-800' :
                      quote.status === 'pending' || quote.status === 'sent' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}
                  >
                    {quote.status.charAt(0).toUpperCase() + quote.status.slice(1)}
                  </span>
                </td>
                
                <td className="px-4 py-2 text-sm">{quote.tax.toFixed(2)}%</td>
                <td className="px-4 py-2 text-sm">{quote.currency} {quote.total.toFixed(2)}</td>
                <td className="px-4 py-2 text-sm flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleView(quote)}
                    disabled={!allowedActions.includes('read')}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(quote.id!)}
                    disabled={!allowedActions.includes('update')}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDelete(quote.id!)}
                    disabled={!allowedActions.includes('delete')}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => downloadPDF(quote.id!)}
                    disabled={downloadLoading === quote.id || !allowedActions.includes('read')}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {filteredQuotes.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-2 text-center text-sm text-gray-500">
                  No quotes found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
          <div onClick={handleViewBackdropClick}>
            <DialogHeader>
              <DialogTitle>Quote Details</DialogTitle>
            </DialogHeader>
            {selectedQuote && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-medium">Company Information</h3>
                    <p><strong>Name:</strong> {selectedQuote.companyname}</p>
                    <p><strong>Representative:</strong> {selectedQuote.representative}</p>
                    <p><strong>Email:</strong> {selectedQuote.email}</p>
                    <p><strong>Phone:</strong> {selectedQuote.phone}</p>
                    <p><strong>Address:</strong> {selectedQuote.address}</p>
                  </div>
                  <div>
                    <h3 className="font-medium">Quote Information</h3>
                    <p><strong>Number:</strong> {selectedQuote.number}</p>
                    <p><strong>Date:</strong> {new Date(selectedQuote.date).toLocaleDateString()}</p>
                    <p><strong>Expire Date:</strong> {new Date(selectedQuote.expireDate).toLocaleDateString()}</p>
                    <p><strong>Year:</strong> {selectedQuote.year}</p>
                    <p><strong>Currency:</strong> {selectedQuote.currency}</p>
                    <p><strong>Status:</strong> {selectedQuote.status.charAt(0).toUpperCase() + selectedQuote.status.slice(1)}</p>
                    <p><strong>Paid:</strong> {selectedQuote.currency} {selectedQuote.paid.toFixed(2)}</p>
                    {selectedQuote.tax > 0 && <p><strong>Tax:</strong> {selectedQuote.tax}%</p>}
                    <p><strong>Note:</strong> {selectedQuote.note || 'N/A'}</p>
                  </div>
                </div>
                <div>
                  <h3 className="font-medium">Items</h3>
                  <table className="min-w-full bg-white border border-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Item</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedQuote.items.map((item, index) => (
                        <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                          <td className="px-4 py-2 text-sm">{item.item}</td>
                          <td className="px-4 py-2 text-sm">{item.description}</td>
                          <td className="px-4 py-2 text-sm">{item.quantity}</td>
                          <td className="px-4 py-2 text-sm">{selectedQuote.currency} {item.price.toFixed(2)}</td>
                          <td className="px-4 py-2 text-sm">{selectedQuote.currency} {(item.quantity * item.price).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="space-y-2">
                  <h3 className="font-medium">Summary</h3>
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{selectedQuote.currency} {selectedQuote.items.reduce((sum, item) => sum + (item.quantity * item.price), 0).toFixed(2)}</span>
                  </div>
                  {selectedQuote.tax > 0 && (
                    <div className="flex justify-between">
                      <span>Tax ({selectedQuote.tax}%):</span>
                      <span>{selectedQuote.currency} {(selectedQuote.items.reduce((sum, item) => sum + (item.quantity * item.price), 0) * (selectedQuote.tax / 100)).toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold">
                    <span>Total:</span>
                    <span>{selectedQuote.currency} {selectedQuote.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete this quote? This action cannot be undone.</p>
          <div className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => {
                setDeleteOpen(false);
                setQuoteToDelete(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={confirmDelete}
              disabled={loading}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Quotes;