import React, { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { customerAPI } from '../services/customers';
import { saleApi } from '../services/sales';
import { paymentsAPI } from '../services/payments';
import { transactionsAPI } from '../services/transactions';
import { DollarSign, Users, TrendingUp, RefreshCw, PiggyBank, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Define data interfaces for type safety
interface SalesChartData {
    period: string;
    sales: number;
    target: number;
}

interface Stats {
    customers: number;
    revenue: number;
    expenses: number;
    totalSales: number;
    achievement: number;
    netProfit: number;
}

// Define props interface for allowedActions
interface ReportsSectionProps {
    allowedActions: string[];
}

const ReportsSection: React.FC<ReportsSectionProps> = ({ allowedActions }) => {
    const [salesData, setSalesData] = useState<SalesChartData[]>([]);
    const [stats, setStats] = useState<Stats>({
        customers: 0,
        revenue: 0,
        expenses: 0,
        totalSales: 0,
        achievement: 0,
        netProfit: 0,
    });
    const [filterDays, setFilterDays] = useState<string>('30');
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const { toast } = useToast();

    // Check if the user has read permissions
    const hasReadAccess = allowedActions.includes('read');

    const MONTHLY_TARGET = 5000000;
    // Calculate a daily target for dynamic aggregation
    const DAILY_TARGET = MONTHLY_TARGET / 30;

    const fetchData = async () => {
        // Only fetch data if the user has read access
        if (!hasReadAccess) {
            setError('You do not have permission to view this report.');
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);
        try {
            const [customersRes, salesRes, paymentsRes, transactionsRes, balanceRes] = await Promise.all([
                customerAPI.getCustomers().catch(() => ({ data: [] })),
                saleApi.getSales().catch(() => ({ data: [] })),
                paymentsAPI.getPayments().catch(() => ({ data: [] })),
                transactionsAPI.getTransactions().catch(() => ({ data: [] })),
                transactionsAPI.getBalance().catch(() => ({ data: { balance: 0 } })),
            ]);

            const now = new Date();
            const startDate = new Date();
            if (filterDays !== 'all') {
                startDate.setDate(now.getDate() - parseInt(filterDays));
            } else {
                startDate.setTime(0); // Epoch time for 'all time'
            }

            const customersArray = Array.isArray(customersRes.data) ? customersRes.data : customersRes.data?.data || [];
            const totalCustomers = customersArray.length;

            const salesArray = Array.isArray(salesRes.data) ? salesRes.data : salesRes.data?.data || [];
            const paymentsArray = Array.isArray(paymentsRes.data) ? paymentsRes.data : paymentsRes.data?.data || [];
            const transactionsArray = Array.isArray(transactionsRes.data) ? transactionsRes.data : transactionsRes.data?.data || [];

            // Filter data dynamically based on the date range
            const filteredSales = salesArray.filter((sale: any) => {
                const dateStr = sale.Date || sale.createdAt || sale.date;
                const saleDate = new Date(dateStr);
                return !isNaN(saleDate.getTime()) && saleDate >= startDate && saleDate <= now;
            });

            const filteredPayments = paymentsArray.filter((p: any) => {
                const dateStr = p.Date || p.createdAt || p.date;
                const paymentDate = new Date(dateStr);
                return !isNaN(paymentDate.getTime()) && paymentDate >= startDate && paymentDate <= now;
            });

            const filteredTransactions = transactionsArray.filter((t: any) => {
                const dateStr = t.Date || t.createdAt || t.date;
                const transactionDate = new Date(dateStr);
                return !isNaN(transactionDate.getTime()) && transactionDate >= startDate && transactionDate <= now && (t.status || '').toLowerCase() === 'completed';
            });

            // Dynamically aggregate data for the sales chart
            const salesByPeriod: Record<string, number> = {};
            filteredSales.forEach((sale: any) => {
                const dateStr = sale.Date || sale.createdAt || sale.date;
                const saleDate = new Date(dateStr);
                if (!isNaN(saleDate.getTime())) {
                    let periodKey;
                    // Determine the aggregation period based on filterDays
                    if (parseInt(filterDays) <= 30) {
                        // Aggregate by day for 7, 14, and 30-day filters
                        periodKey = saleDate.toLocaleString('default', { day: '2-digit', month: 'short' });
                    } else {
                        // Aggregate by month for 90, 365, and 'all time' filters
                        periodKey = saleDate.toLocaleString('default', { month: 'short', year: '2-digit' });
                    }
                    salesByPeriod[periodKey] = (salesByPeriod[periodKey] || 0) + (parseFloat(String(sale.Amount || sale.amount || '0').replace(/[^0-9.-]+/g, '')) || 0);
                }
            });

            const salesChartData = Object.entries(salesByPeriod)
                .map(([period, sales]) => ({
                    period,
                    sales,
                    target: parseInt(filterDays) <= 30 ? DAILY_TARGET : MONTHLY_TARGET,
                }));

            // Sort the data based on the period key
            const sortedSalesChartData = salesChartData.sort((a, b) => {
                const dateA = new Date(a.period.length > 5 ? `01 ${a.period}` : `${a.period}, ${new Date().getFullYear()}`);
                const dateB = new Date(b.period.length > 5 ? `01 ${b.period}` : `${b.period}, ${new Date().getFullYear()}`);
                return dateA.getTime() - dateB.getTime();
            });

            setSalesData(sortedSalesChartData);

            // Calculate stats for the cards
            const totalSales = filteredSales.reduce((sum: number, sale: any) => sum + (parseFloat(String(sale.Amount || sale.amount || '0').replace(/[^0-9.-]+/g, '')) || 0), 0);
            const totalTarget = salesChartData.length > 0 ? salesChartData.length * (parseInt(filterDays) <= 30 ? DAILY_TARGET : MONTHLY_TARGET) : (parseInt(filterDays) <= 30 ? DAILY_TARGET : MONTHLY_TARGET);
            const totalAchievement = totalTarget > 0 ? (totalSales / totalTarget) * 100 : 0;

            const totalRevenue = filteredPayments.reduce((sum: number, p: any) => sum + (parseFloat(p.amount || p.Amount || '0') || 0), 0);
            const totalExpenses = filteredTransactions
                .filter((t: any) => (t.type || '').toLowerCase() === 'expense')
                .reduce((sum: number, t: any) => sum + (parseFloat(t.amount || t.Amount || '0') || 0), 0);

            // Extract balance from balanceRes.data, assuming it returns { balance: number }
            const netProfit = balanceRes.data?.balance || 0;

            setStats({
                customers: totalCustomers,
                revenue: totalRevenue,
                expenses: totalExpenses,
                totalSales: totalSales,
                achievement: totalAchievement,
                netProfit: netProfit,
            });

            setError(null);
        } catch (err: any) {
            const errorMessage = err.message || 'Failed to fetch report data';
            setError(errorMessage);
            toast({
                title: 'Error',
                description: errorMessage,
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [filterDays, hasReadAccess]); // Depend on filterDays and hasReadAccess to re-fetch when it changes

    // Loading and Error states
    if (loading) {
        return (
            <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
                <div className="text-xl font-semibold text-gray-600 flex items-center">
                    <RefreshCw className="w-6 h-6 mr-2 animate-spin" />
                    Loading...
                </div>
            </div>
        );
    }
    
    // Check for read access and display an error if not available
    if (!hasReadAccess) {
        return (
            <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center text-center">
                <div className="text-xl font-semibold text-red-600 flex items-center">
                    <Lock className="w-6 h-6 mr-2" />
                    You do not have permission to view this report.
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-6 bg-gray-50 min-h-screen flex items-center justify-center">
                <div className="text-xl font-semibold text-red-600">{error}</div>
            </div>
        );
    }

    const formatYAxisTick = (value: number) => {
        if (value >= 1000000) {
            return `Rs ${(value / 1000000).toFixed(1)}M`;
        }
        if (value >= 1000) {
            return `Rs ${(value / 1000).toFixed(1)}K`;
        }
        return `Rs ${value}`;
    };

    return (
        <div className="p-6 bg-gray-50 min-h-screen space-y-8">
            <div className="flex justify-between items-center">
                <h1 className="text-3xl font-bold text-gray-800">Reports Dashboard</h1>
                <div className="flex gap-3">
                    {['7', '14', '30', '90', '365', 'all'].map((days) => (
                        <button
                            key={days}
                            onClick={() => setFilterDays(days)}
                            className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${filterDays === days
                                ? 'bg-indigo-600 text-white shadow-md'
                                : 'bg-white border border-gray-300 text-gray-600 hover:bg-gray-100'
                            }`}
                        >
                            {days === '30' ? 'Month' : days === '90' ? 'Quarter' : days === '365' ? 'Year' : days === 'all' ? 'All Time' : `${days} Days`}
                        </button>
                    ))}
                    <button
                        onClick={fetchData}
                        className="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
                        disabled={loading}
                    >
                        <RefreshCw className="w-5 h-5 mr-2" />
                        Refresh
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* Total Customers Card */}
                <Card className="bg-white shadow-lg rounded-lg hover:shadow-xl transition-shadow">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
                            <Users className="w-5 h-5 mr-2 text-indigo-600" />
                            Total Customers
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold text-gray-800">{stats.customers}</div>
                        <p className="text-sm text-gray-500 mt-1">Customers in the database</p>
                    </CardContent>
                </Card>

                {/* Total Sales Card */}
                <Card className="bg-white shadow-lg rounded-lg hover:shadow-xl transition-shadow">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
                            <DollarSign className="w-5 h-5 mr-2 text-indigo-600" />
                            Total Sales
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold text-indigo-600">
                            Rs {stats.totalSales.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <p className="text-sm text-gray-500 mt-1">Total sales for the period</p>
                    </CardContent>
                </Card>

                {/* Sales Achievement Card */}
                <Card className="bg-white shadow-lg rounded-lg hover:shadow-xl transition-shadow">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
                            <TrendingUp className="w-5 h-5 mr-2 text-indigo-600" />
                            Sales Achievement
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className={`text-4xl font-bold ${stats.achievement >= 100 ? 'text-green-600' : 'text-yellow-600'}`}>
                            {stats.achievement.toFixed(1)}%
                        </div>
                        <p className="text-sm text-gray-500 mt-1">Target achievement for the period</p>
                    </CardContent>
                </Card>

                {/* Net Profit Card */}
                <Card className="bg-white shadow-lg rounded-lg hover:shadow-xl transition-shadow">
                    <CardHeader className="pb-4">
                        <CardTitle className="text-xl font-semibold text-gray-800 flex items-center">
                            <PiggyBank className="w-5 h-5 mr-2 text-indigo-600" />
                            Net Profit
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className={`text-4xl font-bold ${stats.netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            Rs {stats.netProfit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </div>
                        <p className="text-sm text-gray-500 mt-1">Revenue minus expenses</p>
                    </CardContent>
                </Card>
            </div>

            {/* Sales "Wave Chart" */}
            <Card className="bg-white shadow-lg rounded-lg">
                <CardHeader className="pb-4 flex flex-row items-center justify-between">
                    <CardTitle className="text-2xl font-bold text-gray-800 flex items-center">
                        <DollarSign className="w-6 h-6 mr-2 text-indigo-600" />
                        Sales Report
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {salesData.length > 0 ? (
                        <div className="h-96">
                            <ResponsiveContainer width="100%" height="100%">
                                <AreaChart data={salesData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                                    <CartesianGrid strokeDasharray="3 3" className="opacity-50" stroke="#e5e7eb" />
                                    <XAxis dataKey="period" tick={{ fill: '#4b5563', fontSize: 12 }} />
                                    <YAxis tick={{ fill: '#4b5563', fontSize: 12 }} tickFormatter={formatYAxisTick} />
                                    <Tooltip
                                        formatter={(value: number, name: string) => {
                                            if (name === 'Achievement') {
                                                return `${value.toFixed(1)}%`;
                                            }
                                            return `Rs ${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                                        }}
                                        labelFormatter={(label) => `Period: ${label}`}
                                        contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                                    />
                                    <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '14px', color: '#4b5563' }} />
                                    <Area type="monotone" dataKey="sales" stroke="#4f46e5" fillOpacity={0.5} fill="#4f46e5" name="Sales" />
                                    <Area type="monotone" dataKey="target" stroke="#22c55e" fillOpacity={0.2} fill="#22c55e" strokeDasharray="5 5" name="Target" />
                                </AreaChart>
                            </ResponsiveContainer>
                        </div>
                    ) : (
                        <div className="h-96 flex items-center justify-center text-gray-500">
                            No sales data available for the selected period.
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
};

export default ReportsSection;
