
import React, { useState, useEffect } from 'react';
import { customerAPI } from '../services/customers';
import { orderAPI } from '../services/orders';
import { quoteAPI } from '../services/quotes';
import { invoiceAPI } from '../services/invoices';
import { saleApi } from '../services/sales';
import { productAPI } from '../services/products';
import { employeesAPI } from '../services/employees';
import { companiesAPI } from '../services/companies';
import { transactionsAPI } from '../services/transactions';
import { paymentsAPI } from '../services/payments';
import { inventoryAPI } from '../services/inventories';
import { useToast } from '@/hooks/use-toast';
import { RefreshCw, Filter, Users, ShoppingCart, FileText, Sheet, DollarSign, Package, Briefcase, Building, CreditCard, Wallet, Boxes, TrendingUp, BarChart3 } from 'lucide-react';
import axios from 'axios';

interface AnalyticsData {
    customers: number;
    orders: number;
    quotes: number;
    invoices: number;
    sales: number;
    products: number;
    employees: number;
    companies: number;
    transactions: number;
    payments: number;
    inventory: number;
    invoiceStatuses: { [key: string]: number };
    quoteStatuses: { [key: string]: number };
    productQuantity: number;
    salesQuantity: number;
}

const DashboardSection: React.FC = () => {
    const [analytics, setAnalytics] = useState<AnalyticsData>({
        customers: 0,
        orders: 0,
        quotes: 0,
        invoices: 0,
        sales: 0,
        products: 0,
        employees: 0,
        companies: 0,
        transactions: 0,
        payments: 0,
        inventory: 0,
        invoiceStatuses: {},
        quoteStatuses: {},
        productQuantity: 0,
        salesQuantity: 0,
    });
    const [loading, setLoading] = useState<boolean>(true);
    const [apiError, setApiError] = useState<string | null>(null);
    const [dateRange, setDateRange] = useState<string>('7d');
    const { toast } = useToast();

    const fetchAnalytics = async () => {
        setLoading(true);
        try {
            const endpoints = [
                { key: 'customers', api: customerAPI.getCustomers },
                { key: 'orders', api: orderAPI.getOrders },
                { key: 'quotes', api: quoteAPI.getQuotes },
                { key: 'invoices', api: invoiceAPI.getInvoices },
                { key: 'sales', api: saleApi.getSales },
                { key: 'products', api: productAPI.getProducts },
                { key: 'companies', api: companiesAPI.getCompanies },
                { key: 'transactions', api: transactionsAPI.getTransactions },
                { key: 'payments', api: paymentsAPI.getPayments },
            ];

            const responses = await Promise.all(
                endpoints.map(async ({ key, api }) => {
                    try {
                        const response = await api({ params: { dateRange } });
                        const data = Array.isArray(response.data) ? response.data : response.data?.data || [];
                        return { key, data };
                    } catch (err: any) {
                        console.error(`Error fetching ${key}: ${err.message}`);
                        return { key, data: [] };
                    }
                })
            );

            const invoiceResponse = await invoiceAPI.getInvoices().catch((err: any) => {
                console.error('Error fetching invoices:', err.message);
                return { data: [] };
            });
            const quoteResponse = await quoteAPI.getQuotes().catch((err: any) => {
                console.error('Error fetching quotes:', err.message);
                return { data: [] };
            });
            const productResponse = await productAPI.getProducts().catch((err: any) => {
                console.error('Error fetching products:', err.message);
                return { data: [] };
            });
            const salesResponse = await saleApi.getSales().catch((err: any) => {
                console.error('Error fetching sales:', err.message);
                return { data: [] };
            });

            const invoices = Array.isArray(invoiceResponse.data) ? invoiceResponse.data : invoiceResponse.data?.data || [];
            const quotes = Array.isArray(quoteResponse.data) ? quoteResponse.data : quoteResponse.data?.data || [];
            const products = Array.isArray(productResponse.data) ? productResponse.data : productResponse.data?.data || [];
            const sales = Array.isArray(salesResponse.data) ? salesResponse.data : salesResponse.data?.data || [];

            const invoiceStatuses = invoices.reduce((acc: { [key: string]: number }, invoice: any) => {
                acc[invoice.status] = (acc[invoice.status] || 0) + 1;
                return acc;
            }, {});

            const quoteStatuses = quotes.reduce((acc: { [key: string]: number }, quote: any) => {
                acc[quote.status] = (acc[quote.status] || 0) + 1;
                return acc;
            }, {});

            const productQuantity = products.reduce((sum: number, product: any) => sum + (Number(product.quantity) || 0), 0);
            const salesQuantity = sales.reduce((sum: number, sale: any) => sum + (Number(sale.quantity) || 0), 0);

            const newAnalytics = responses.reduce((acc, { key, data }) => {
                acc[key] = data.length;
                return acc;
            }, {} as AnalyticsData);

            setAnalytics({
                ...newAnalytics,
                invoiceStatuses,
                quoteStatuses,
                productQuantity,
                salesQuantity,
            });
            setApiError(null);
        } catch (err: any) {
            const errorMessage = axios.isAxiosError(err)
                ? err.response?.data?.error || err.message || 'Failed to fetch analytics data'
                : err.message || 'Failed to fetch analytics data';
            setApiError(errorMessage);
            toast({
                title: 'Error',
                description: errorMessage,
                variant: 'destructive',
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAnalytics();
    }, [dateRange]);

    const StatusProgressBar: React.FC<{ status: string; count: number; total: number }> = ({ status, count, total }) => {
        const percentage = total ? ((count / total) * 100).toFixed(1) : 0;
        
        const getStatusColor = (status: string) => {
            switch (status.toLowerCase()) {
                case 'paid':
                case 'accepted':
                    return 'from-emerald-400 to-emerald-600';
                case 'pending':
                case 'sent':
                    return 'from-blue-400 to-blue-600';
                case 'partially paid':
                    return 'from-amber-400 to-amber-600';
                case 'draft':
                    return 'from-slate-400 to-slate-600';
                case 'declined':
                case 'overdue':
                case 'unpaid':
                case 'expired':
                    return 'from-red-400 to-red-600';
                default:
                    return 'from-gray-400 to-gray-600';
            }
        };
        
        const gradientClass = getStatusColor(status);
        const formattedStatus = status.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
        
        return (
            <div className="mb-6">
                <div className="flex justify-between mb-2">
                    <span className="text-sm font-semibold text-gray-700 capitalize">{formattedStatus}</span>
                    <div className="flex items-center space-x-2">
                        <span className="text-sm font-bold text-gray-800">{percentage}%</span>
                        <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">({count})</span>
                    </div>
                </div>
                <div className="relative w-full bg-gray-200 rounded-full h-3 overflow-hidden shadow-inner">
                    <div
                        className={`h-full bg-gradient-to-r ${gradientClass} rounded-full transition-all duration-700 ease-out shadow-sm`}
                        style={{ width: `${percentage}%` }}
                    >
                        <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full"></div>
                    </div>
                </div>
            </div>
        );
    };

    const CircularProgressBar: React.FC<{ value: number; max: number; label: string }> = ({ value, max, label }) => {
        const totalQuantity = value + max;
        const percentage = totalQuantity ? (value / totalQuantity) * 100 : 0;
        const radius = 45;
        const circumference = 2 * Math.PI * radius;
        const offset = circumference - (percentage / 100) * circumference;
        const size = 140;
        const center = size / 2;

        return (
            <div className="flex flex-col items-center group">
                <div className="relative">
                    <svg className="w-36 h-36 transform transition-transform group-hover:scale-105" viewBox={`0 0 ${size} ${size}`}>
                        <defs>
                            <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#3b82f6" />
                                <stop offset="100%" stopColor="#1d4ed8" />
                            </linearGradient>
                            <filter id="glow">
                                <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                                <feMerge> 
                                    <feMergeNode in="coloredBlur"/>
                                    <feMergeNode in="SourceGraphic"/>
                                </feMerge>
                            </filter>
                        </defs>
                        <circle
                            className="text-gray-200"
                            strokeWidth="10"
                            stroke="currentColor"
                            fill="transparent"
                            r={radius}
                            cx={center}
                            cy={center}
                        />
                        <circle
                            strokeWidth="10"
                            strokeDasharray={circumference}
                            strokeDashoffset={offset}
                            stroke="url(#progressGradient)"
                            fill="transparent"
                            r={radius}
                            cx={center}
                            cy={center}
                            transform={`rotate(-90 ${center} ${center})`}
                            className="transition-all duration-1000 ease-out filter drop-shadow-md"
                            strokeLinecap="round"
                            filter="url(#glow)"
                        />
                        <text x={center} y={center - 5} textAnchor="middle" className="text-2xl font-bold fill-gray-800">
                            {percentage.toFixed(1)}%
                        </text>
                        <text x={center} y={center + 15} textAnchor="middle" className="text-xs fill-gray-500">
                            {value}/{totalQuantity}
                        </text>
                    </svg>
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 to-transparent rounded-full animate-pulse"></div>
                </div>
                <span className="mt-3 text-sm font-semibold text-gray-700 text-center">{label}</span>
            </div>
        );
    };

    const totalInvoices = Object.values(analytics.invoiceStatuses).reduce((sum, count) => sum + count, 0);
    const totalQuotes = Object.values(analytics.quoteStatuses).reduce((sum, count) => sum + count, 0);
    const maxProductQuantity = analytics.salesQuantity + analytics.productQuantity || 1;

    if (loading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 flex items-center justify-center">
                <div className="text-center">
                    <div className="relative">
                        <RefreshCw className="w-16 h-16 text-blue-500 animate-spin mx-auto mb-4" />
                        <div className="absolute inset-0 bg-blue-200 rounded-full animate-ping opacity-20"></div>
                    </div>
                    <p className="text-xl font-semibold text-gray-700">Loading Analytics...</p>
                    <p className="text-sm text-gray-500 mt-2">Fetching your business insights</p>
                </div>
            </div>
        );
    }

    if (apiError) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center">
                <div className="bg-white p-8 rounded-2xl shadow-xl border border-red-100 max-w-md text-center">
                    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <TrendingUp className="w-8 h-8 text-red-500" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">Oops! Something went wrong</h3>
                    <p className="text-red-600 mb-4">{apiError}</p>
                    <button 
                        onClick={fetchAnalytics}
                        className="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-colors"
                    >
                        Try Again
                    </button>
                </div>
            </div>
        );
    }

    const cardData = [
        { label: 'Customers', value: analytics.customers, Icon: Users, color: 'from-blue-500 to-cyan-500', bgColor: 'bg-blue-50' },
        { label: 'Purchased Orders', value: analytics.orders, Icon: ShoppingCart, color: 'from-green-500 to-emerald-500', bgColor: 'bg-green-50' },
      //  { label: 'Quotes', value: analytics.quotes, Icon: FileText, color: 'from-purple-500 to-violet-500', bgColor: 'bg-purple-50' },
        { label: 'Invoices', value: analytics.invoices, Icon: Sheet, color: 'from-orange-500 to-amber-500', bgColor: 'bg-orange-50' },
        { label: 'Sales', value: analytics.sales, Icon: DollarSign, color: 'from-pink-500 to-rose-500', bgColor: 'bg-pink-50' },
        { label: 'Products', value: analytics.products, Icon: Package, color: 'from-indigo-500 to-blue-500', bgColor: 'bg-indigo-50' },
        { label: 'Companies', value: analytics.companies, Icon: Building, color: 'from-slate-500 to-gray-500', bgColor: 'bg-slate-50' },
        { label: 'Transactions', value: analytics.transactions, Icon: CreditCard, color: 'from-red-500 to-pink-500', bgColor: 'bg-red-50' },
        { label: 'Payments', value: analytics.payments, Icon: Wallet, color: 'from-yellow-500 to-orange-500', bgColor: 'bg-yellow-50' },
        ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
            {/* Header */}
            <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200 shadow-sm sticky top-0 z-10">
                <div className="p-6">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
                        <div>
                            <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                                Business Analytics Dashboard
                            </h1>
                            <p className="text-gray-600 mt-1">Real-time insights into your business performance</p>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="relative">
                                <select
                                    value={dateRange}
                                    onChange={(e) => setDateRange(e.target.value)}
                                    className="appearance-none bg-white/80 backdrop-blur border border-gray-300 rounded-xl py-3 pl-12 pr-8 text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm hover:shadow-md transition-all"
                                >
                                    <option value="7d">Past 7 Days</option>
                                    <option value="14d">Past 14 Days</option>
                                    <option value="30d">Past 1 Month</option>
                                </select>
                                <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                            </div>
                            <button
                                onClick={fetchAnalytics}
                                className="flex items-center bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all shadow-md hover:shadow-lg transform hover:scale-105"
                            >
                                <RefreshCw className="w-5 h-5 mr-2" />
                                Refresh
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="p-6">
                {/* Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
                    {cardData.map(({ label, value, Icon, color, bgColor }) => (
                        <div key={label} className={`${bgColor} p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-white/50 backdrop-blur-sm group`}>
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-sm font-medium text-gray-600 mb-1">{label}</p>
                                    <p className="text-3xl font-bold text-gray-800">{value.toLocaleString()}</p>
                                </div>
                                <div className={`w-14 h-14 bg-gradient-to-br ${color} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                                    <Icon className="w-7 h-7 text-white" />
                                </div>
                            </div>
                            <div className="mt-4 flex items-center text-xs text-gray-500">
                                <TrendingUp className="w-3 h-3 mr-1" />
                                <span>Updated now</span>
                            </div>
                        </div>
                    ))}
                </div>

                {/* Status Charts */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
                    <div className="bg-white/70 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-white/50">
                        <div className="flex items-center mb-6">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg flex items-center justify-center mr-3">
                                <Sheet className="w-5 h-5 text-white" />
                            </div>
                            <h2 className="text-2xl font-bold text-gray-800">Invoice Status Overview</h2>
                        </div>
                        {Object.keys(analytics.invoiceStatuses).length > 0 ? (
                            <div className="space-y-2">
                                {Object.entries(analytics.invoiceStatuses).map(([status, count]) => (
                                    <StatusProgressBar key={status} status={status} count={count} total={totalInvoices} />
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-12">
                                <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                                <p className="text-gray-500">No invoice data available</p>
                            </div>
                        )}
                    </div>

               {/*     <div className="bg-white/70 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-white/50">
                        <div className="flex items-center mb-6">
                            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-500 rounded-lg flex items-center justify-center mr-3">
                                <FileText className="w-5 h-5 text-white" />
                            </div>
                            <h2 className="text-2xl font-bold text-gray-800">Quote Status Overview</h2>
                        </div>
                        {Object.keys(analytics.quoteStatuses).length > 0 ? (
                            <div className="space-y-2">
                                {Object.entries(analytics.quoteStatuses).map(([status, count]) => (
                                    <StatusProgressBar key={status} status={status} count={count} total={totalQuotes} />
                                ))}
                            </div>
                        ) : (
                            <div className="text-center py-12">
                                <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                                <p className="text-gray-500">No quote data available</p>
                            </div>
                        )}
                    </div>
                </div> 
                 Sales Performance 
                <div className="bg-white/70 backdrop-blur-sm p-8 rounded-2xl shadow-xl border border-white/50">
                    <div className="flex items-center mb-8">
                        <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center mr-4">
                            <TrendingUp className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800">Products Sold Percentage</h2>
                            <p className="text-gray-600">Products sold vs total inventory</p>
                        </div>
                    </div>
                    {maxProductQuantity > 0 ? (
                        <div className="flex justify-center items-center py-8">
                            <CircularProgressBar
                                value={analytics.salesQuantity}
                                max={analytics.productQuantity}
                                label="Products Sold"
                            />
                        </div>
                    ) : (
                        <div className="text-center py-16">
                            <Package className="w-20 h-20 text-gray-300 mx-auto mb-4" />
                            <p className="text-gray-500 text-lg">No product data available</p>
                        </div>
                    )}
                </div>*/}
                </div>
            </div>
        </div>
    );
};

export default DashboardSection;
