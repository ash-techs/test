import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import Invoices from "../components/Invoices";
import Quotes from "../components/Quotes";
import ManagementForm from "../components/ManagementForm";
import OrdersForm from "../components/OrdersForm";
import FinanceForm from "../components/FinanceForm";
import PaymentsForm from '../components/PaymentsForm';
import ProductForm from "../components/ProductForm";
import CustomerForm from './CustomerForm';
import SaleForm from "../components/SaleForm";
import Companies from '../components/Companies';
import ReportsSection from "../components/ReportsSection";
import DashboardSection from "../components/DashboardSection";
import UserManagementForm from "../components/UserManagementForm";
import InventoryForm from "../components/InventoryForm";
import { jwtDecode } from 'jwt-decode';
import {
  Users,
  DollarSign,
  ShoppingCart,
  Banknote,
  Home,
  Receipt,
  Building2,
  Package,
  TrendingUp,
  UserCircle,
  BarChart,
  ShoppingBag,
  Sheet,
  Save,
  X,
  Menu,
  User,
  Lock,
  Fingerprint,
  Briefcase,
  UserCog,
  LogOut,
  Edit,
  ArrowRight,
  Clock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import ERPHomepage from '@/pages/ERPHomepage';
import { useToast } from '@/hooks/use-toast';
import { userApi } from '@/services/users';
import { loginAPI } from '@/services/login';
import { startRegistration } from '@simplewebauthn/browser';
import { AuthContext } from './AuthProvider';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'Admin' | 'HR' | 'Finance' | 'Sales' | 'Employee';
  status: 'Active' | 'Inactive'
}

export const getUserIdFromToken = () => {
  const token = localStorage.getItem('authToken');
  if (!token) {
    return null;
  }
  try {
    const decodedToken: any = jwtDecode(token);
    return decodedToken.sub;
  } catch (error) {
    console.error("Failed to decode token:", error);
    return null;
  }
};

const ERPDashboard: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('30');
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profileData, setProfileData] = useState({
    name: '',
    email: ''
  });
  const [passwordData, setPasswordData] = useState({
    newPassword: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { logout } = useContext(AuthContext);

  const allMenuItems = [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: Home, 
      permissions: {
        'Admin': ['read'],  // Dashboard is typically read-only
        'HR': ['read'],
        'Finance': ['read'],
        'Sales': ['read'],
        'Employee': ['read']
      } 
    },
    { 
      id: 'invoices', 
      label: 'Invoices', 
      icon: Receipt, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete'],
        'Finance': ['create', 'read', 'update'],  // No delete for Finance
        'Sales': ['read'],
        'Employee':['create','read']
      } 
    },
    { 
      id: 'orders', 
      label: 'Shipments', 
      icon: ShoppingCart, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete'],
        'Sales': ['create', 'read', 'update']  // No delete
      } 
    },
    { 
      id: 'finance', 
      label: 'Daybook', 
      icon: DollarSign, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete'],
        'Finance': ['create', 'read', 'update']  // No delete
      } 
    },
    { 
      id: 'sales', 
      label: 'Sales', 
      icon: TrendingUp, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete'],
        'Sales': ['create', 'read', 'update']
      } 
    },
    { 
      id: 'products', 
      label: 'Stock', 
      icon: Package, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete']
      } 
    },
    { 
      id: 'payments', 
      label: 'Payments', 
      icon: Banknote, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete'],
        'Finance': ['create', 'read', 'update'],
        'Sales': ['read']
      } 
    },
    { 
      id: 'customers', 
      label: 'Customers', 
      icon: Users, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete']
      } 
    },
    { 
      id: 'companies', 
      label: 'Companies', 
      icon: Building2, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete']
      } 
    },
    { 
      id: 'reports', 
      label: 'Reports', 
      icon: BarChart, 
      permissions: {
        'Admin': ['read'],  // Reports are typically read-only
        'HR': ['read'],
        'Finance': ['read'],
        'Sales': ['read'],
        'Employee': ['read']
      } 
    },
    { 
      id: 'user-management', 
      label: 'User Management', 
      icon: UserCog, 
      permissions: {
        'Admin': ['create', 'read', 'update', 'delete']
      } 
    }
  ];

  const getTimeGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const getRoleBasedMessage = (role: string) => {
    const messages = {
      'Admin': 'You have full system access. Manage users, monitor all operations, and oversee business performance.',
      'HR': 'Manage employee data, track HR metrics, and oversee human resources operations.',
      'Finance': 'Monitor financial data, manage invoices, payments, and track financial performance.',
      'Sales': 'Track sales performance, manage quotes, and monitor customer interactions.',
      'Employee': 'Access invoices, quotes, reports and view relevant business information assigned to your role.'
    };
    return messages[role] || 'Welcome to your ERP dashboard. Explore the available features.';
  };

  useEffect(() => {
    const fetchUser = async () => {
      setLoading(true);
      const userId = getUserIdFromToken();
      if (!userId) {
        setError("User not authenticated. Please log in.");
        setLoading(false);
        navigate('/login');
        return;
      }
      try {
        const response = await userApi.getUser(userId);
        setCurrentUser(response.data);
        setProfileData({
          name: response.data.name,
          email: response.data.email
        });
        setShowWelcomeModal(true); 
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch user data. Please log in again.");
        setLoading(false);
        console.error("Error fetching user:", err);
        navigate('/login');
      }
    };
    fetchUser();
  }, [navigate]);

  // Updated: Filter menu items where the current role has at least one permission (e.g., 'read' minimum to show)
  const menuItems = currentUser 
    ? allMenuItems.filter(item => {
        const rolePermissions = item.permissions[currentUser.role] || [];
        return rolePermissions.length > 0;
      }) 
    : [];

  const handleProfileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setProfileData({
      ...profileData,
      [e.target.name]: e.target.value
    });
  };

  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasswordData({
      ...passwordData,
      [e.target.name]: e.target.value
    });
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setLoading(true);
    try {
      await userApi.updateUser(currentUser.id, profileData);
      setCurrentUser(prevUser => (prevUser ? { ...prevUser, ...profileData } : null));
      setShowProfileModal(false);
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
    } catch (err) {
      setError("Failed to update profile.");
      console.error("Error updating profile:", err);
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setLoading(true);
    try {
      await userApi.updateUser(currentUser!.id, { password: passwordData.newPassword });
      setShowPasswordModal(false);
      toast({
        title: "Password Updated",
        description: "Your password has been changed successfully.",
      });
    } catch (err) {
      setError("Failed to update password.");
      console.error("Error updating password:", err);
      toast({
        title: "Error",
        description: "Failed to update password.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFingerprintSignup = async () => {
    if (!currentUser) return;
    setLoading(true);
    try {
      const options = await loginAPI.registerFingerprint({ userId: currentUser.id });
     const attResp = await startRegistration({ optionsJSON: options.data.options });
     const filteredAttResp = {
        id: attResp.id,
        rawId: attResp.rawId,
        response: {
          attestationObject: attResp.response.attestationObject,
          clientDataJSON: attResp.response.clientDataJSON,
          transports: attResp.response.transports || [],
        },
        type: attResp.type,
        clientExtensionResults: attResp.clientExtensionResults,
        authenticatorAttachment: attResp.authenticatorAttachment,
      };
     const verificationResponse = await loginAPI.verifyRegistration({
        userId: currentUser.id,
        registrationResponse: filteredAttResp
      });
      if (verificationResponse.data.verified) {
        toast({
          title: "Fingerprint Registered",
          description: "Your fingerprint has been successfully registered.",
        });
      } else {
        throw new Error("Fingerprint verification failed.");
      }
    } catch (err: any) {
      setError(err.response?.data?.message || "Failed to initiate fingerprint registration.");
      console.error("Error initiating fingerprint registration:", err);
      toast({
        title: "Error",
        description: err.response?.data?.message || "Failed to initiate fingerprint registration.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = (): void => {
    logout();
  };

  const handleWelcomeClose = () => {
    setShowWelcomeModal(false);
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-full">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
        </div>
      );
    }
    
    // Updated: Find the permissions for the active section and current role
    const sectionItem = allMenuItems.find(item => item.id === activeSection);
    const allowedActions = currentUser && sectionItem 
      ? (sectionItem.permissions[currentUser.role] || []) 
      : [];

    const hasAccess = allowedActions.length > 0;
    if (!hasAccess) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
          <Lock className="h-16 w-16 mb-4" />
          <h3 className="text-xl font-semibold">Permission Denied</h3>
          <p>You do not have access to this section. Please contact an administrator.</p>
        </div>
      );
    }

    // Updated: Pass allowedActions as a prop to each component that supports CRUD
    // Components like DashboardSection or ReportsSection may ignore it if they're read-only
    switch (activeSection) {
      case 'dashboard':
        return <DashboardSection  />;
      case 'invoices':
        return <Invoices allowedActions={allowedActions} />;
      case 'orders':
        return <OrdersForm allowedActions={allowedActions} />;
      case 'finance':
        return <FinanceForm allowedActions={allowedActions} />;
      case 'sales':
        return <SaleForm allowedActions={allowedActions} />;
      case 'products':
        return <ProductForm allowedActions={allowedActions} />;
      case 'payments':
        return <PaymentsForm  />;
      case 'customers':
        return <CustomerForm />;
      case 'companies':
        return <Companies />;
      case 'reports':
        return <ReportsSection allowedActions={allowedActions} />;
      case 'user-management':
        return <UserManagementForm />;
      default:
        return <ERPHomepage />;
    }
  };

  return (
    <div className="min-h-screen bg-background flex w-full">
      {error && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded z-50">
          {error}
        </div>
      )}
      
      {/* Welcome Modal */}
      {showWelcomeModal && currentUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-in fade-in duration-300">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-2xl w-full max-w-lg mx-4 shadow-2xl border border-white/20 relative overflow-hidden">
            {/* Decorative background elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full -mr-16 -mt-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-indigo-400/20 to-blue-400/20 rounded-full -ml-12 -mb-12"></div>
            
            <div className="relative">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
                    <User className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-800">
                      {getTimeGreeting()}!
                    </h3>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <Clock className="h-3 w-3 mr-1" />
                      {new Date().toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </div>
                  </div>
                </div>
                <button 
                  onClick={handleWelcomeClose}
                  className="p-2 hover:bg-gray-200/50 rounded-full transition-colors"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              <div className="mb-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center border-4 border-white shadow-lg">
                    <User className="h-8 w-8 text-gray-600" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold text-gray-800">
                      Welcome back, {currentUser.name}!
                    </h4>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        currentUser.role === 'Admin' ? 'bg-red-100 text-red-700' :
                        currentUser.role === 'HR' ? 'bg-green-100 text-green-700' :
                        currentUser.role === 'Finance' ? 'bg-blue-100 text-blue-700' :
                        currentUser.role === 'Sales' ? 'bg-purple-100 text-purple-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {currentUser.role}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white/70 backdrop-blur-sm rounded-lg p-4 border border-white/50">
                  <p className="text-gray-700 text-sm leading-relaxed">
                    {getRoleBasedMessage(currentUser.role)}
                  </p>
                </div>
              </div>

              <div className="flex justify-between items-center">
                <div className="text-xs text-gray-500">
                  You can always access your profile settings from the user menu.
                </div>
                <button
                  onClick={handleWelcomeClose}
                  className="text-black px-6  rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all  hover:shadow-lg transform hover:scale-105 flex items-center space-x-2"
                >
                  <span>Get Started</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className={`${sidebarCollapsed ? 'w-16' : 'w-64'} bg-slate-900 text-white transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center justify-between">
            {!sidebarCollapsed && (
              <h1 className="text-xl font-bold text-white">ERP Dashboard</h1>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="text-white hover:bg-slate-800"
              disabled={loading}
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors ${activeSection === item.id
                      ? 'bg-primary text-white'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    disabled={loading}
                  >
                    <Icon className="h-5 w-5" />
                    {!sidebarCollapsed && <span className="text-sm font-medium">{item.label}</span>}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-card border-b border-border p-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground capitalize">
                {activeSection === 'management' ? 'HR Management' : activeSection}
              </h2>
              <p className="text-muted-foreground">
                {activeSection === 'dashboard'
                  ? 'Overview of your business metrics'
                  : `Manage your ${activeSection === 'management' ? 'employees and HR data' : activeSection}`}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="px-2" aria-label="User settings" disabled={loading}>
                    <UserCircle className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <User className="h-4 w-4 mr-2" />
                    <span>Logged in as: {currentUser?.name || 'Loading...'}</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setShowProfileModal(true)}>
                    <Edit className="h-4 w-4 mr-2" />
                    <span>Update Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleFingerprintSignup()}>
                    <Fingerprint className="h-4 w-4 mr-2" />
                    <span>Add Fingerprint</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleLogout()}>
                    <LogOut className="h-4 w-4 mr-3" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-auto p-6">
          {renderContent()}
        </main>
      </div>
      {showProfileModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-background p-6 rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Update Profile</h3>
              <button onClick={() => setShowProfileModal(false)} disabled={loading}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handleProfileSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input
                  type="text"
                  name="name"
                  value={profileData.name}
                  onChange={handleProfileChange}
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input
                  type="email"
                  name="email"
                  value={profileData.email}
                  onChange={handleProfileChange}
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                  disabled={loading}
                />
              </div>
              <div className="flex justify-between pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowProfileModal(false);
                    setShowPasswordModal(true);
                  }}
                  disabled={loading}
                >
                  <Lock className="h-4 w-4 mr-2" />
                  Update Password
                </Button>
                <Button type="submit" disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Profile
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-background p-6 rounded-lg w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Update Password</h3>
              <button onClick={() => setShowPasswordModal(false)} disabled={loading}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">New Password</label>
                <input
                  type="password"
                  name="newPassword"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Confirm Password</label>
                <input
                  type="password"
                  name="confirmPassword"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-3 py-2 border rounded-lg"
                  required
                  disabled={loading}
                />
              </div>
              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={loading}>
                  <Save className="h-4 w-4 mr-2" />
                  Save Password
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ERPDashboard;