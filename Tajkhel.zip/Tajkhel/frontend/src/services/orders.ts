import api from './api';

export const orderAPI = {
  getOrders: () => api.get('/api/orders'),
  getOrder: (id: number) => api.get(`/api/orders/${id}`),
  createOrder: (orderData: any) => api.post('/api/orders', orderData),
  updateOrder: (id: number, orderData: any) => {
    
    return api.put(`/api/orders/${id}`, orderData);
  },
  deleteOrder: (id: number) => {
    return api.delete(`/api/orders/${id}`);
  },
  getOrdersByStatus: (status: string) => api.get(`/api/orders/status/${status}`),
  updateOrderStatus: (id: number, status: string) => api.put(`/api/orders/${id}/status`, { status }),
  
  downloadPDFById: (id: number) => api.get(`api/orders/download/pdf/${id}`, { responseType: 'blob' }),
  downloadOrdersPDF: () => api.get('/api/orders/download/pdf', {
    responseType: 'blob',
  }),
  
};