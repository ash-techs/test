import api from './api';
import {
  PublicKeyCredentialCreationOptionsJSON,
  PublicKeyCredentialRequestOptionsJSON,
  AuthenticationResponseJSON,
  RegistrationResponseJSON,
} from '@simplewebauthn/types';

interface LoginUserData {
  email: string;
  password: string;
}

interface FingerprintData {
  userId: string;
}

interface FingerprintLoginData {
  email: string;
}

interface VerifyAuthData {
  userId: string;
  authenticationResponse: AuthenticationResponseJSON;
}

interface VerifyRegistrationData {
  userId: string;
  registrationResponse: RegistrationResponseJSON;
}

interface ApiResponse<T = any> {
  data: {
    success: boolean;
    message: string;
    token?: string;
    options?: T;
    userId?: string;
    verified?: boolean;
  } & T;
}

export const loginAPI = {
  loginUser: (userData: LoginUserData): Promise<ApiResponse<{ token: string }>> =>
    api.post(`api/auth/login`, userData),

  registerFingerprint: (userData: FingerprintData): Promise<ApiResponse<{ options: PublicKeyCredentialCreationOptionsJSON }>> =>
    api.post(`api/auth/register-fingerprint`, userData),

  verifyRegistration: (verificationData: VerifyRegistrationData): Promise<ApiResponse<{ verified: boolean }>> =>
    api.post(`api/auth/verify-registration`, verificationData),

  loginFingerprint: (userData: FingerprintLoginData): Promise<ApiResponse<{ options: PublicKeyCredentialRequestOptionsJSON; userId: string }>> =>
    api.post(`api/auth/login-fingerprint`, userData),

  verifyAuthentication: (authenticationData: VerifyAuthData): Promise<ApiResponse<{ token: string }>> =>
    api.post(`api/auth/verify-authentication`, authenticationData),
};