import api from './api';

export const paymentsAPI = {
  getPayments: async (params: { dateRange?: string } = {}) => {
    try {
      const response = await api.get('api/payments', { params });
      return response;
    } catch (error) {
      console.error('Error in getPayments:', error);
      throw error;
    }
  },

  getPayment: async (id: string) => {
    try {
      const response = await api.get(`api/payments/${id}`);
      return response;
    } catch (error) {
      console.error(`Error in getPayment(${id}):`, error);
      throw error;
    }
  },

  createPayment: async (paymentData: any) => {
    if (!paymentData || typeof paymentData !== 'object') {
      throw new Error('Invalid payment data provided');
    }
    const { customerId, customerName, amount, date, transactionDate, paymentMode, paymentTransaction, status, notes, createdBy, companyId } = paymentData;

    if (!customerId || !customerName || !amount || !date || !transactionDate || !paymentMode) {
      throw new Error('Missing required fields');
    }
    if (isNaN(Number(amount)) || Number(amount) <= 0) {
      throw new Error('Amount must be a valid number greater than 0');
    }

    try {
      const response = await api.post('api/payments', {
        customerId,
        customerName,
        amount: Number(amount),
        date,
        transactionDate,
        paymentMode,
        paymentTransaction,
        status,
        notes,
        createdBy,
        companyId,
      });
      return response;
    } catch (error) {
      console.error('Error in createPayment:', error);
      throw error;
    }
  },

  updatePayment: async (id: string, paymentData: any) => {
    if (!paymentData || typeof paymentData !== 'object') {
      throw new Error('Invalid payment data provided');
    }
    const { customerId, customerName, amount, date, transactionDate, paymentMode, paymentTransaction, status, notes, createdBy, companyId } = paymentData;

    if (!customerId || !customerName || !amount || !date || !transactionDate || !paymentMode) {
      throw new Error('Missing required fields');
    }
    if (isNaN(Number(amount)) || Number(amount) <= 0) {
      throw new Error('Amount must be a valid number greater than 0');
    }

    try {
      const response = await api.put(`api/payments/${id}`, {
        customerId,
        customerName,
        amount: Number(amount),
        date,
        transactionDate,
        paymentMode,
        paymentTransaction,
        status,
        notes,
        createdBy,
        companyId,
      });
      return response;
    } catch (error) {
      console.error(`Error in updatePayment(${id}):`, error);
      throw error;
    }
  },

  deletePayment: async (id: string) => {
    try {
      const response = await api.delete(`api/payments/${id}`);
      return response;
    } catch (error) {
      console.error(`Error in deletePayment(${id}):`, error);
      throw error;
    }
  },

  downloadPaymentsPDF: async () => {
    try {
      const response = await api.get('api/payments/pdf', { responseType: 'blob' });
      return response;
    } catch (error) {
      console.error('Error in downloadPaymentsPDF:', error);
      throw error;
    }
  },
};