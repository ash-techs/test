import api from './api';

export const inventoryAPI = {
  getInventories: () => api.get('api/inventory'),
  getInventory: (id: number) => api.get(`api/inventory/${id}`),
  createInventory: (data: any) => api.post('api/inventory/', data),
  updateInventory: (id: number, data: any) => api.put(`api/inventory/${id}`, data),
  deleteInventory: (id: number) => api.delete(`api/inventory/${id}`),
  downloadInventoryPDF: () => api.get('api/inventory/download/pdf', { responseType: 'blob' }),
};
