import api from './api';
export interface Sale {
  id: string;
  saleId: string;
  customerId: number;
  customerName: string;
  productId: number;
  productLot: string;
  productFileno: string;
  weight: number;
  balanceUnits: number;
  balanceWeight: number;
  unitPrice: number;
  discount: string;
  amount: number;
  paymentMethod: string;
  status: string;
  notes?: string;
  createdBy: string;
  companyId: string | null;
  createdAt: string;
  updatedAt: string;
}
export interface CreateSaleData {
  saleId: string;
  customerId: number;
  customerName: string;
  productId: number;
  balanceUnits: number;
  weight: number;
  unitPrice: number;
  date: string;
  discount: string;
  paymentMethod: string;
  status: string;
  notes?: string;
  createdBy: string;
  companyId: string | null;
}

export const saleApi = {
  downloadSalesPDF: () => api.get<Blob>('/api/sales/download/pdf', { responseType: 'blob' }),
  getSales: () => api.get<{ data: Sale[] }>('/api/sales'),
  getSaleById: (id: string) => api.get<Sale>(`/api/sales/${id}`),
  createSale: (data: CreateSaleData) => api.post<Sale>('/api/sales', data),
  updateSale: (id: string, data:Partial<CreateSaleData>) => api.put<Sale>(`/api/sales/${id}`, data),
  deleteSale: (id: string) => api.delete<{ message: string }>(`/api/sales/${id}`),
};