import api from './api';


// Quotes API functions
export const quoteAPI = {
  
  downloadQuotePDFById: (id: string) => api.get(`api/quotes/download/pdf/${id}`, { responseType: 'blob' }),
  getQuotes: () => api.get('api/quotes'),
  getQuote: (id:string) => api.get(`api/quotes/${id}`),
  createQuote: (quoteData) => api.post('api/quotes/', quoteData),
  updateQuote: (id:string, quoteData) => api.put(`api/quotes/${id}`, quoteData),
  deleteQuote: (id:string) => api.delete(`api/quotes/${id}`),
  getQuotesByStatus: (status) => api.get(`api/quotes/status/${status}`),
  updateQuoteStatus: (id:string, status) => api.put(`api/quotes/${id}/status`, { status }),
  downloadQuotesPDF: () => api.get('api/quotes/download/pdf', {
    responseType: 'blob',
  }),
  
};
