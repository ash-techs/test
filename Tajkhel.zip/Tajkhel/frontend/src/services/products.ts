import api from './api';

export const productAPI = {
  getProducts: () => api.get('api/products'),
  getProduct: (id: number) => api.get(`api/products/${id}`),
  createProduct: (data: any) => api.post('api/products/', data),
  updateProduct: (id: number, data: any) => api.put(`api/products/${id}`, data),
  deleteProduct: (id: number) => api.delete(`api/products/${id}`),
  downloadProductsPdf: () => api.get('api/products/download/pdf', { responseType: 'blob' }),
};
