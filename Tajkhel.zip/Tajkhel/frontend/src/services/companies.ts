import axios from 'axios';

const API_URL = '/api/companies';

export const companiesAPI = {
  getCompanies: () => axios.get(API_URL),
  getCompany: (id: string) => axios.get(`${API_URL}/${id}`),
  createCompany: (companyData: any) => axios.post(API_URL, companyData),
  updateCompany: (id: string, companyData: any) => axios.put(`${API_URL}/${id}`, companyData),
  adjustCompanyAmount: (id: string, amount: number, action: 'add' | 'subtract') =>
    axios.put(`${API_URL}/${id}/amount`, { amount, action }),
  deleteCompany: (id: string) => axios.delete(`${API_URL}/${id}`),
  downloadCompaniesPDF: (searchTerm: string = '') =>
    axios.get(`${API_URL}/pdf`, {
      params: { search: searchTerm },
      responseType: 'blob',
    }),
};