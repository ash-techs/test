import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { TooltipProvider } from '@radix-ui/react-tooltip';
import { Toaster } from 'react-hot-toast';
import { Toaster as Sonner } from 'sonner';

// Import all the components that are now in separate files
import ERPHomepage from './pages/ERPHomepage';
import Login from './pages/Login';
import ERPDashboard from './components/ERPDashboard';
import NotFound from './pages/NotFound';
import Footer from './components/Footer';
import { AuthProvider } from './components/AuthProvider';
import ProtectedRoute from './components/ProtectedRoute';

// Initialize React Query client
const queryClient = new QueryClient();

// The main App component with corrected routing
const App = () => (
  <QueryClientProvider client={queryClient}>
    
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <div className="flex flex-col min-h-screen">
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<ERPHomepage />} />

                <Route path="/login" element={<Login />} />

                <Route path="/ERPDashboard" element={<ProtectedRoute><ERPDashboard /></ProtectedRoute>} />

                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  
);

export default App;
