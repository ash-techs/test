--
-- PostgreSQL database dump
--

\restrict r7AQgeyWdNsqc42dYuqxWs8znyZ2C8IRMK6kXytMiTZBGF8r2IeSwYtImmqr88j

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: discount_per; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.discount_per AS ENUM (
    'NO_DISCOUNT',
    'FIVE_PERCENT',
    'TEN_PERCENT',
    'FIFTEEN_PERCENT'
);


ALTER TYPE public.discount_per OWNER TO postgres;

--
-- Name: invoice_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.invoice_status AS ENUM (
    'DRAFT',
    'PENDING',
    'UNPAID',
    'OVERDUE',
    'PARTIALLY_PAID',
    'PAID'
);


ALTER TYPE public.invoice_status OWNER TO postgres;

--
-- Name: payment_mode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.payment_mode AS ENUM (
    'CASH',
    'CREDIT_CARD',
    'BANK_TRANSFER',
    'DIGITAL_WALLET',
    'CHEQUE'
);


ALTER TYPE public.payment_mode OWNER TO postgres;

--
-- Name: payment_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.payment_status AS ENUM (
    'RECEIVED',
    'PENDING',
    'PROCESSING',
    'COMPLETED',
    'FAILED',
    'REFUNDED'
);


ALTER TYPE public.payment_status OWNER TO postgres;

--
-- Name: quote_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.quote_status AS ENUM (
    'DRAFT',
    'PENDING',
    'SENT',
    'ACCEPTED',
    'DECLINED',
    'EXPIRED'
);


ALTER TYPE public.quote_status OWNER TO postgres;

--
-- Name: transaction_category; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_category AS ENUM (
    'OFFICE_SUPPLIES',
    'MARKETING',
    'TRAVEL',
    'UTILITIES',
    'SALARIES',
    'EQUIPMENT',
    'SOFTWARE',
    'PROFESSIONAL_SERVICES',
    'SALES',
    'RENT',
    'PAYROLL',
    'OTHER'
);


ALTER TYPE public.transaction_category OWNER TO postgres;

--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_status AS ENUM (
    'PENDING',
    'COMPLETED',
    'CANCELLED'
);


ALTER TYPE public.transaction_status OWNER TO postgres;

--
-- Name: transaction_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transaction_type AS ENUM (
    'INCOME',
    'EXPENSE',
    'TRANSFER'
);


ALTER TYPE public.transaction_type OWNER TO postgres;

--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_timestamp() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    number text NOT NULL,
    quantity integer NOT NULL,
    price double precision NOT NULL,
    discount double precision NOT NULL,
    total double precision NOT NULL,
    status text NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone NOT NULL,
    "companyId" text,
    tax numeric,
    "fairCharges" numeric,
    "customDuties" numeric,
    "localFair" numeric,
    "salesTax" numeric,
    "officeExpense" numeric,
    misc numeric,
    "totalAmount" numeric,
    note text,
    rate numeric(10,2),
    "priceInPKR" numeric(12,2),
    phone text,
    state text,
    city text
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: Order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Order_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Order_id_seq" OWNER TO postgres;

--
-- Name: Order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Order_id_seq" OWNED BY public.orders.id;


--
-- Name: authenticators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authenticators (
    id integer NOT NULL,
    user_id integer NOT NULL,
    credential_id text NOT NULL,
    credential_public_key text NOT NULL,
    sign_count integer DEFAULT 0,
    aaguid text,
    created_at timestamp without time zone DEFAULT now(),
    transports jsonb
);


ALTER TABLE public.authenticators OWNER TO postgres;

--
-- Name: authenticators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.authenticators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.authenticators_id_seq OWNER TO postgres;

--
-- Name: authenticators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.authenticators_id_seq OWNED BY public.authenticators.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.companies (
    id text NOT NULL,
    name text NOT NULL,
    contact text NOT NULL,
    country text NOT NULL,
    phone text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone NOT NULL,
    amount numeric(15,2) DEFAULT 0
);


ALTER TABLE public.companies OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name text NOT NULL,
    phone text,
    address text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone NOT NULL,
    amount numeric(10,2) DEFAULT 0.00 NOT NULL,
    CONSTRAINT customers_amount_check CHECK ((amount >= (0)::numeric))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    name text NOT NULL,
    employee_id text NOT NULL,
    department text NOT NULL,
    "position" text NOT NULL,
    salary double precision NOT NULL,
    hire_date text NOT NULL,
    email text NOT NULL,
    website text,
    status text DEFAULT 'Active'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO postgres;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    id integer NOT NULL,
    item text NOT NULL,
    type text NOT NULL,
    unitprice double precision NOT NULL,
    quantity integer NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone NOT NULL,
    vendor text
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_id_seq OWNED BY public.inventory.id;


--
-- Name: invoice_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_items (
    id integer NOT NULL,
    "invoiceId" integer NOT NULL,
    product_id integer NOT NULL,
    product_name character varying(255) NOT NULL,
    product_lot character varying(50),
    product_fileno character varying(50),
    weight numeric(10,2) NOT NULL,
    balance_units integer NOT NULL,
    balance_weight numeric(10,2) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    discount character varying(20) DEFAULT 'NO_DISCOUNT'::character varying NOT NULL,
    amount numeric(12,2) NOT NULL,
    CONSTRAINT invoice_items_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT invoice_items_balance_units_check CHECK ((balance_units > 0)),
    CONSTRAINT invoice_items_balance_weight_check CHECK ((balance_weight >= (0)::numeric)),
    CONSTRAINT invoice_items_discount_check CHECK (((discount)::text = ANY (ARRAY[('NO_DISCOUNT'::character varying)::text, ('FIVE_PERCENT'::character varying)::text, ('TEN_PERCENT'::character varying)::text, ('FIFTEEN_PERCENT'::character varying)::text]))),
    CONSTRAINT invoice_items_unit_price_check CHECK ((unit_price > (0)::numeric)),
    CONSTRAINT invoice_items_weight_check CHECK ((weight > (0)::numeric))
);


ALTER TABLE public.invoice_items OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoice_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoice_items_id_seq OWNER TO postgres;

--
-- Name: invoice_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoice_items_id_seq OWNED BY public.invoice_items.id;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    number character varying(50) NOT NULL,
    customer character varying(255) NOT NULL,
    email character varying(255),
    address character varying(255) NOT NULL,
    phone character varying(50) NOT NULL,
    date date NOT NULL,
    expiredate date NOT NULL,
    year integer NOT NULL,
    currency character varying(3) DEFAULT 'PKR'::character varying,
    status character varying(20) DEFAULT 'DRAFT'::character varying NOT NULL,
    paid numeric(12,2) DEFAULT 0.00,
    note text,
    tax numeric(5,2) DEFAULT 0.00,
    "createdBy" character varying(100) DEFAULT 'Admin'::character varying,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_expire_date CHECK ((expiredate > date)),
    CONSTRAINT check_paid CHECK ((paid >= (0)::numeric)),
    CONSTRAINT check_tax CHECK (((tax >= (0)::numeric) AND (tax <= (100)::numeric))),
    CONSTRAINT check_year CHECK (((year >= 2000) AND (year <= 2100))),
    CONSTRAINT invoices_status_check CHECK (((status)::text = ANY (ARRAY[('DRAFT'::character varying)::text, ('PENDING'::character varying)::text, ('UNPAID'::character varying)::text, ('OVERDUE'::character varying)::text, ('PARTIALLY_PAID'::character varying)::text, ('PAID'::character varying)::text])))
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invoices_id_seq OWNER TO postgres;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id character varying(255) NOT NULL,
    customer_id integer NOT NULL,
    amount numeric NOT NULL,
    date date NOT NULL,
    transaction_date date NOT NULL,
    payment_method character varying(50) NOT NULL,
    payment_transaction character varying(255),
    status character varying(50) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT payments_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT payments_payment_method_check CHECK (((payment_method)::text = ANY (ARRAY[('CASH'::character varying)::text, ('CREDIT_CARD'::character varying)::text, ('BANK_TRANSFER'::character varying)::text, ('DIGITAL_WALLET'::character varying)::text, ('CHEQUE'::character varying)::text, ('WIRE_TRANSFER'::character varying)::text]))),
    CONSTRAINT payments_status_check CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('PROCESSING'::character varying)::text, ('COMPLETED'::character varying)::text, ('FAILED'::character varying)::text, ('RECEIVED'::character varying)::text, ('REFUNDED'::character varying)::text])))
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id integer NOT NULL,
    lot character varying(255) NOT NULL,
    fileno character varying(255) NOT NULL,
    color character varying(255),
    kind character varying(255),
    mix character varying(255),
    balance_unit integer DEFAULT 0 NOT NULL,
    balance_weight integer DEFAULT 0 NOT NULL,
    price numeric(10,2) NOT NULL,
    total integer DEFAULT 0,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    issue integer DEFAULT 0 NOT NULL,
    weight integer,
    CONSTRAINT products_price_check CHECK ((price > (0)::numeric))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: quote_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quote_items (
    id text NOT NULL,
    item text NOT NULL,
    description text DEFAULT ''::text,
    quantity double precision NOT NULL,
    price double precision NOT NULL,
    "quoteId" text NOT NULL,
    "createdAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.quote_items OWNER TO postgres;

--
-- Name: quotes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quotes (
    id text NOT NULL,
    number text NOT NULL,
    companyname text,
    representative text NOT NULL,
    email text NOT NULL,
    address text NOT NULL,
    phone text NOT NULL,
    date timestamp without time zone NOT NULL,
    "expireDate" timestamp without time zone NOT NULL,
    year text NOT NULL,
    currency text DEFAULT 'PKR'::text,
    status public.quote_status DEFAULT 'DRAFT'::public.quote_status,
    paid double precision DEFAULT 0,
    note text,
    tax double precision DEFAULT 0,
    "createdBy" text DEFAULT 'Admin'::text,
    "createdAt" timestamp without time zone DEFAULT now(),
    "updatedAt" timestamp without time zone NOT NULL
);


ALTER TABLE public.quotes OWNER TO postgres;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sale_id character varying(50) NOT NULL,
    customer_id integer NOT NULL,
    customer_name character varying(255) NOT NULL,
    product_id integer NOT NULL,
    product_lot character varying(100) NOT NULL,
    product_fileno character varying(100) NOT NULL,
    weight numeric(10,2) NOT NULL,
    balance_units integer NOT NULL,
    balance_weight numeric(10,2) NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    discount character varying(20) DEFAULT 'NO_DISCOUNT'::character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    notes text,
    created_by character varying(100) NOT NULL,
    company_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id text NOT NULL,
    type public.transaction_type NOT NULL,
    amount double precision NOT NULL,
    bank text NOT NULL,
    checknumber text,
    status public.transaction_status DEFAULT 'PENDING'::public.transaction_status,
    category public.transaction_category NOT NULL,
    date timestamp without time zone NOT NULL,
    receivedpayment double precision DEFAULT 0,
    description text,
    createdby text DEFAULT 'Admin'::text,
    createdat timestamp without time zone DEFAULT now(),
    updatedat timestamp without time zone NOT NULL,
    customerid integer,
    customername text DEFAULT ''::text,
    fromcustomerid integer,
    tocustomerid integer
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    email text NOT NULL,
    role text DEFAULT 'User'::text,
    status text DEFAULT 'Active'::text,
    user_id text NOT NULL,
    current_challenge text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: authenticators id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticators ALTER COLUMN id SET DEFAULT nextval('public.authenticators_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: inventory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN id SET DEFAULT nextval('public.inventory_id_seq'::regclass);


--
-- Name: invoice_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items ALTER COLUMN id SET DEFAULT nextval('public.invoice_items_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public."Order_id_seq"'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: authenticators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authenticators (id, user_id, credential_id, credential_public_key, sign_count, aaguid, created_at, transports) FROM stdin;
1	1	UVp5SE85QmJJVDVwTFZQcEFESThMUQ==	pQECAyYgASFYIP7bc6dVtdUbDd8TaJZ5FtJAZFHgdTGOKCTAiBx7woU1IlggEwvQLnn4ePTQL2uw5bbu0yH/Kf6DpnMkyvrtcdAYGjM=	0	ea9b8d66-4d01-1d21-3ce4-b6b48cb575d4	2025-08-18 13:31:58.845775	["hybrid", "internal"]
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.companies (id, name, contact, country, phone, email, "createdAt", "updatedAt", amount) FROM stdin;
65ad5800-61a3-44ee-ad08-d5b83483a808	China Traders	Chan	Pakistan	+92428738912	WingZi@gmail.com	2025-09-05 11:02:27.283	2025-10-08 12:34:59.312	400000.00
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, phone, address, created_at, updated_at, amount) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, name, employee_id, department, "position", salary, hire_date, email, website, status, created_at, updated_at) FROM stdin;
3	Yasir Khan	EMP-001	IT	IT Support	100000	2025-08-01T05:00:00.000+05:00	yasir@ahs-technologies.com	\N	Active	2025-08-17 00:17:02.961	2025-08-17 00:17:12.403
\.


--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (id, item, type, unitprice, quantity, description, created_at, updated_at, vendor) FROM stdin;
1	Firewall	Hardware	124000	14	Checking	2025-08-17 00:28:05.358	2025-08-17 00:28:05.358	Fortinet
\.


--
-- Data for Name: invoice_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_items (id, "invoiceId", product_id, product_name, product_lot, product_fileno, weight, balance_units, balance_weight, unit_price, discount, amount) FROM stdin;
4	5	4	Product #4	1236153	FNO-12387123	25.00	3	75.00	40000.00	NO_DISCOUNT	66666.67
5	6	4	Product #4	1236153	FNO-12387123	25.00	1	25.00	40000.00	FIVE_PERCENT	21111.11
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (id, number, customer, email, address, phone, date, expiredate, year, currency, status, paid, note, tax, "createdBy", "createdAt", "updatedAt") FROM stdin;
5	PN-001	ALi	\N	House No 413 Sector B	03029488281	2025-09-03	2025-10-03	2025	USD	PARTIALLY_PAID	1000.00	Laptop#123	0.00	Admin	2025-09-06 12:04:23.823	2025-09-06 12:28:43.959566
6	Inv-001	ALi	\N	Jdhdhhej	030294882312	2025-09-06	2025-10-06	2025	PKR	DRAFT	0.00	\N	0.00	Admin	2025-09-06 12:30:36.025	2025-09-06 12:30:36.025
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, number, quantity, price, discount, total, status, "createdAt", "updatedAt", "companyId", tax, "fairCharges", "customDuties", "localFair", "salesTax", "officeExpense", misc, "totalAmount", note, rate, "priceInPKR", phone, state, city) FROM stdin;
17	con-01	1	400000	0	400000	DELIVERED	2025-09-06 14:00:06.763	2025-10-08 12:31:13.038	65ad5800-61a3-44ee-ad08-d5b83483a808	NaN	1	1	1	1	1	1	400006		280.00	112001680.00			
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, customer_id, amount, date, transaction_date, payment_method, payment_transaction, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, lot, fileno, color, kind, mix, balance_unit, balance_weight, price, total, description, created_at, updated_at, issue, weight) FROM stdin;
4	1236153	FNO-12387123	White	M/1	T210	31	775	250.00	\N	no	2025-09-04 17:44:19.129	2025-10-08 02:00:16.725681	0	25
\.


--
-- Data for Name: quote_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quote_items (id, item, description, quantity, price, "quoteId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: quotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quotes (id, number, companyname, representative, email, address, phone, date, "expireDate", year, currency, status, paid, note, tax, "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (id, sale_id, customer_id, customer_name, product_id, product_lot, product_fileno, weight, balance_units, balance_weight, unit_price, discount, amount, payment_method, status, notes, created_by, company_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, type, amount, bank, checknumber, status, category, date, receivedpayment, description, createdby, createdat, updatedat, customerid, customername, fromcustomerid, tocustomerid) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, username, password, email, role, status, user_id, current_challenge, created_at, updated_at) FROM stdin;
1	Alamgir Khan	akhan@ahs-technologies.com	$2b$10$k9l6Vw9jK8BCSk3E5M3cae8jvFzYza5KBAiTS9KMCRFvV3cIHqpNe	akhan@ahs-technologies.com	Admin	Active	admin-uuid-001	\N	2025-08-16 23:41:10.55515	2025-08-17 00:34:15.767
2	Rauf Khan	rkhan@ahs-technologies.com	$2b$10$zt0vA8b6XxkKJqriNotTUuQbzHqakJRQ2FeUZCJhtwCwqZAbz4OMO	rkhan@ahs-technologies.com	Employee	Active	employee-uuid-001	\N	2025-08-16 23:41:10.55515	2025-08-17 00:42:29.99
3	Haseeb Khan	hkhan@ahs-technologies.com	$2b$10$qqoShQExXkAl2CwNUdXrYOV.B.MxjxA7TDhARE4edbpw6r7/.xRs.	hkhan@ahs-technologies.com	Admin	Active	efa65155-72f5-4801-b5f2-178a6ad62125	\N	2025-08-17 00:43:03.9	2025-08-25 19:16:50.334
4	Sahal Obaid	sahal@ahs-technologies.com	$2b$10$vjcPt7s8KPgIGO63XrtyP.t41U5AxM.a5Q4lUcmnOdBA1p03Diera	sahal@ahs-technologies.com	Finance	Inactive	ab6a0e94-8fa4-43e1-af9b-d077645b273a	\N	2025-08-18 13:20:22.593	2025-08-25 19:50:07.302
\.


--
-- Name: Order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Order_id_seq"', 17, true);


--
-- Name: authenticators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.authenticators_id_seq', 1, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 5, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_id_seq', 3, true);


--
-- Name: inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_id_seq', 1, true);


--
-- Name: invoice_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoice_items_id_seq', 5, true);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_id_seq', 6, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: orders Order_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "Order_number_key" UNIQUE (number);


--
-- Name: orders Order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT "Order_pkey" PRIMARY KEY (id);


--
-- Name: authenticators authenticators_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticators
    ADD CONSTRAINT authenticators_credential_id_key UNIQUE (credential_id);


--
-- Name: authenticators authenticators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticators
    ADD CONSTRAINT authenticators_pkey PRIMARY KEY (id);


--
-- Name: companies companies_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_email_key UNIQUE (email);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employees employees_employee_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_employee_id_key UNIQUE (employee_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (id);


--
-- Name: invoice_items invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_number_key UNIQUE (number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: quote_items quote_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_pkey PRIMARY KEY (id);


--
-- Name: quotes quotes_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_number_key UNIQUE (number);


--
-- Name: quotes quotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quotes
    ADD CONSTRAINT quotes_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sales sales_sale_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_sale_id_key UNIQUE (sale_id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_user_id_key UNIQUE (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: sales set_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp BEFORE UPDATE ON public.sales FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: customers update_customers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices update_invoices_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_invoices_timestamp BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: products update_products_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_products_timestamp BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: authenticators authenticators_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticators
    ADD CONSTRAINT authenticators_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: transactions fk_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_customer FOREIGN KEY (customerid) REFERENCES public.customers(id) ON DELETE SET NULL;


--
-- Name: transactions fk_fromcustomer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_fromcustomer FOREIGN KEY (fromcustomerid) REFERENCES public.customers(id);


--
-- Name: transactions fk_tocustomer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_tocustomer FOREIGN KEY (tocustomerid) REFERENCES public.customers(id);


--
-- Name: invoice_items invoice_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT "invoice_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_items invoice_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_items
    ADD CONSTRAINT invoice_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: quote_items quote_items_quoteid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quote_items
    ADD CONSTRAINT quote_items_quoteid_fkey FOREIGN KEY ("quoteId") REFERENCES public.quotes(id) ON DELETE CASCADE;


--
-- Name: sales sales_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON DELETE RESTRICT;


--
-- Name: sales sales_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict r7AQgeyWdNsqc42dYuqxWs8znyZ2C8IRMK6kXytMiTZBGF8r2IeSwYtImmqr88j

