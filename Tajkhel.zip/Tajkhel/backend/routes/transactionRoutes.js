const express = require("express");
const controller=require("../controllers/transactionsController");


const router = express.Router();
router.get("/",controller.getAllTransactions);
router.get("/balance", controller.getBalance);
router.get("/status/:status", controller.getTransactionsByStatus);
router.get("/:id", controller.getTransactionById);
router.post("/", controller.createTransaction);
router.put("/:id", controller.updateTransaction);
router.delete("/:id", controller.deleteTransaction);
router.delete("/:id", controller.deleteTransaction);
router.get('/download/pdf', controller.downloadFinancePDF);
router.post("/", controller.getEnumOptions);


module.exports = router;