const express = require("express");
const {
  getAllCompanies,
  getCompanyById,
  createCompany,
  updateCompany,
  adjustCompanyAmount,
  deleteCompany,
  generateCompaniesPDF,
} = require("../controllers/companyController");

const router = express.Router();

router.get("/", getAllCompanies);
router.get("/pdf", generateCompaniesPDF);
router.get("/:id", getCompanyById);
router.post("/", createCompany);
router.put("/:id", updateCompany);
router.put("/:id/amount", adjustCompanyAmount);
router.delete("/:id", deleteCompany);

module.exports = router;