const express = require("express");
const {
  getAllSales,
  getSaleById,
  createSale,
  deleteSale,
  downloadSalesPDF,
  updateSale
} = require("../controllers/saleController");

const router = express.Router();
router.get("/download/pdf", downloadSalesPDF);
router.get("/", getAllSales);
router.get("/:id", getSaleById);
router.post("/", createSale);
router.delete("/:id", deleteSale);
router.put("/:id", updateSale);

module.exports = router;