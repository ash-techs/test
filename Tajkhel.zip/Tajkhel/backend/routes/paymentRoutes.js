const express = require("express");
const controller=require("../controllers/paymentsController");

const router = express.Router();

router.get("/", controller.getAllPayments);
router.get("/total-received", controller.getTotalReceived);
router.get("/:id", controller.getPayment);
router.post("/", controller.createPayment);
router.put("/:id", controller.updatePayment);
router.delete("/:id", controller.deletePayment);
router.get("/download/pdf", controller.downloadPaymentsPDF);

module.exports = router;
