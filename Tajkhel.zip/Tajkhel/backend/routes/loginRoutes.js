
const express = require('express');
const router = express.Router();
const loginController = require('../controllers/loginController');

router.post('/login', loginController.loginUser);

router.post('/register-fingerprint', loginController.registerFingerprint);
router.post('/verify-registration', loginController.verifyRegistration);

router.post('/login-fingerprint', loginController.loginFingerprint);
router.post('/verify-authentication', loginController.verifyAuthentication);

module.exports = router;
