const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const PDFDocument = require('pdfkit');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const validRoles = ['Admin', 'HR', 'Finance', 'Sales', 'Employee'];
const validStatuses = ['Active', 'Inactive'];

// Get all users
const getAllUsers = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = 'SELECT id, name, username, email, role, status, user_id, current_challenge, "created_at", "updated_at" FROM users';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY "created_at" DESC';

    const result = await pool.query(query, values);
    res.json(
      result.rows.map((user) => ({
        id: user.id,
        name: user.name,
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status,
        userId: user.user_id,
        currentChallenge: user.current_challenge || '',
        created_at: user.created_at ? user.created_at.toISOString() : null,
        updated_at: user.updated_at ? user.updated_at.toISOString() : null,
      }))
    );
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
};

// Search users
const searchUsers = async (req, res) => {
  try {
    const { search, dateRange } = req.query;
    let query = 'SELECT id, name, username, email, role, status, user_id, current_challenge, "created_at", "updated_at" FROM users';
    let params = [];

    if (search || dateRange) {
      query += ' WHERE';
      let conditions = [];

      if (search) {
        conditions.push('name ILIKE $1 OR username ILIKE $1 OR email ILIKE $1');
        params.push(`%${search}%`);
      }

      if (dateRange) {
        let days;
        switch (dateRange) {
          case '7d':
            days = 7;
            break;
          case '14d':
            days = 14;
            break;
          case '30d':
            days = 30;
            break;
          default:
            days = 7;
        }
        const index = params.length + 1;
        conditions.push(`COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $${index}`);
        params.push(`${days} days`);
      }

      query += ' ' + conditions.join(' AND ');
    }
    query += ' ORDER BY "created_at" DESC';

    const result = await pool.query(query, params);
    res.json(
      result.rows.map((user) => ({
        id: user.id,
        name: user.name,
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status,
        userId: user.user_id,
        currentChallenge: user.current_challenge || '',
        created_at: user.created_at ? user.created_at.toISOString() : null,
        updated_at: user.updated_at ? user.updated_at.toISOString() : null,
      }))
    );
  } catch (error) {
    console.error('Error searching users:', error);
    res.status(500).json({ error: 'Failed to search users' });
  }
};

// Get user by ID
const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT id, name, username, email, role, status, user_id, current_challenge, "created_at", "updated_at" FROM users WHERE id = $1',
      [parseInt(id)]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = result.rows[0];
    res.json({
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status,
      userId: user.user_id,
      currentChallenge: user.current_challenge || '',
      created_at: user.created_at ? user.created_at.toISOString() : null,
      updated_at: user.updated_at ? user.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ error: 'Failed to fetch user' });
  }
};

// Create user
const createUser = async (req, res) => {
  try {
    const { name, username, email, password, role, status, userId, currentChallenge } = req.body;

    if (!name || !username || !email || !password || !role) {
      return res.status(400).json({ error: 'Name, username, email, password, and role are required' });
    }

    if (!validRoles.includes(role)) {
      return res.status(400).json({ error: `Invalid role. Valid options: ${validRoles.join(', ')}` });
    }

    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid options: ${validStatuses.join(', ')}` });
    }

    if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    const existing = await pool.query('SELECT * FROM users WHERE username = $1', [username]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Username, email, or user ID already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const now = new Date();
    const result = await pool.query(
      `INSERT INTO users (name, username, email, password, role, status,user_id, current_challenge, "created_at", "updated_at")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9,$10) RETURNING *`,
      [
        name,
        username,
        email,
        hashedPassword,
        role,
        status || 'Active', 
        crypto.randomUUID(),
        currentChallenge || null,
        now,
        now,
      ]
    );

    const user = result.rows[0];
    res.status(201).json({
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status,
      userId: user.user_id,
      currentChallenge: user.current_challenge || '',
      created_at: user.created_at ? user.created_at.toISOString() : null,
      updated_at: user.updated_at ? user.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
};

// Update user
const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, username, email, password, role, status, userId, currentChallenge } = req.body;

    const existing = await pool.query('SELECT * FROM users WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (username && username !== existing.rows[0].username) {
      const usernameCheck = await pool.query('SELECT * FROM users WHERE username = $1 AND id != $2', [username, parseInt(id)]);
      if (usernameCheck.rows.length > 0) {
        return res.status(400).json({ error: 'Username already exists' });
      }
    }

    if (email && email !== existing.rows[0].email) {
      const emailCheck = await pool.query('SELECT * FROM users WHERE email = $1 AND id != $2', [email, parseInt(id)]);
      if (emailCheck.rows.length > 0) {
        return res.status(400).json({ error: 'Email already exists' });
      }
    }

    if (userId && userId !== existing.rows[0].user_id) {
      const userIdCheck = await pool.query('SELECT * FROM users WHERE user_id = $1 AND id != $2', [userId, parseInt(id)]);
      if (userIdCheck.rows.length > 0) {
        return res.status(400).json({ error: 'User ID already exists' });
      }
    }

    if (role && !validRoles.includes(role)) {
      return res.status(400).json({ error: `Invalid role. Valid options: ${validRoles.join(', ')}` });
    }

    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid options: ${validStatuses.join(', ')}` });
    }

    if (email && !/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    const data = {
      ...(name && { name }),
      ...(username && { username }),
      ...(email && { email }),
      ...(password && { password: await bcrypt.hash(password, 10) }),
      ...(role && { role }),
      ...(status && { status }),
      ...(userId && { user_id: userId }),
      ...(currentChallenge !== undefined && { current_challenge: currentChallenge || null }),
      updated_at: new Date(),
    };

    const fields = Object.keys(data).map((key, index) => `"${key}" = $${index + 1}`);
    const values = Object.values(data);

    if (fields.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    const result = await pool.query(
      `UPDATE users SET ${fields.join(', ')} WHERE id = $${fields.length + 1} RETURNING *`,
      [...values, parseInt(id)]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = result.rows[0];
    res.json({
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.email,
      role: user.role,
      status: user.status,
      userId: user.user_id,
      currentChallenge: user.current_challenge || '',
      created_at: user.created_at ? user.created_at.toISOString() : null,
      updated_at: user.updated_at ? user.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
};

// Delete user
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query('DELETE FROM users WHERE id = $1 RETURNING *', [parseInt(id)]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(204).send();
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
};

// Download users PDF report
const downloadUsersPDF = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = 'SELECT id, name, username, email, role, status, "created_at", "updated_at" FROM users';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY "created_at" DESC';

    const result = await pool.query(query, values);

    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="users-report.pdf"');

    doc.pipe(res);

    doc.fontSize(20).text('Users Report', 50, 50);
    doc.moveDown();

    const totalUsers = result.rows.length;
    const activeUsers = result.rows.filter((u) => u.status === 'Active').length;
    const adminUsers = result.rows.filter((u) => u.role === 'Admin').length;

    doc.fontSize(12);
    doc.text(`Total Users: ${totalUsers}`, 50, 100);
    doc.text(`Active Users: ${activeUsers}`, 50, 120);
    doc.text(`Admin Users: ${adminUsers}`, 50, 140);
    doc.text(`Report Generated: ${new Date().toLocaleDateString()}`, 50, 160);
    doc.moveDown(2);

    let yPosition = 220;
    doc.text('ID', 50, yPosition);
    doc.text('Name', 80, yPosition);
    doc.text('Username', 180, yPosition);
    doc.text('Email', 280, yPosition);
    doc.text('Role', 400, yPosition);
    doc.text('Status', 460, yPosition);

    yPosition += 15;
    doc.moveTo(50, yPosition).lineTo(550, yPosition).stroke();
    yPosition += 10;

    result.rows.forEach((user) => {
      if (yPosition > 750) {
        doc.addPage();
        yPosition = 50;
      }

      doc.text(user.id.toString(), 50, yPosition);
      doc.text(user.name.substring(0, 20), 80, yPosition);
      doc.text(user.username.substring(0, 20), 180, yPosition);
      doc.text(user.email.substring(0, 25), 280, yPosition);
      doc.text(user.role, 400, yPosition);
      doc.text(user.status, 460, yPosition);
      yPosition += 20;
    });

    doc.end();
  } catch (error) {
    console.error('Error generating users PDF:', error);
    res.status(500).json({ error: 'Failed to generate users PDF report' });
  }
};

module.exports = {
  getAllUsers,
  searchUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  downloadUsersPDF,
};