const { Pool } = require('pg');
const PDFDocument = require('pdfkit');

const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const mapDiscountToEnum = (discount) => {
  const discountMap = {
    'No Discount': 'NO_DISCOUNT',
    '5% Off': 'FIVE_PERCENT',
    '10% Off': 'TEN_PERCENT',
    '15% Off': 'FIFTEEN_PERCENT',
    'NO_DISCOUNT': 'NO_DISCOUNT',
    'FIVE_PERCENT': 'FIVE_PERCENT',
    'TEN_PERCENT': 'TEN_PERCENT',
    'FIFTEEN_PERCENT': 'FIFTEEN_PERCENT'
  };
  return discountMap[discount] || 'NO_DISCOUNT';
};

const mapDiscountFromEnum = (discount) => {
  const discountMap = {
    'NO_DISCOUNT': 'No Discount',
    'FIVE_PERCENT': '5% Off',
    'TEN_PERCENT': '10% Off',
    'FIFTEEN_PERCENT': '15% Off'
  };
  return discountMap[discount] || 'No Discount';
};

const mapSalesStatusToEnum = (status) => {
  const statusMap = {
    'Pending': 'PENDING',
    'Completed': 'COMPLETED',
    'Cancelled': 'CANCELLED',
    'Refunded': 'REFUNDED',
    'PENDING': 'PENDING',
    'COMPLETED': 'COMPLETED',
    'CANCELLED': 'CANCELLED',
    'REFUNDED': 'REFUNDED'
  };
  return statusMap[status] || 'PENDING';
};

const mapSalesStatusFromEnum = (status) => {
  const statusMap = {
    'PENDING': 'Pending',
    'COMPLETED': 'Completed',
    'CANCELLED': 'Cancelled',
    'REFUNDED': 'Refunded'
  };
  return statusMap[status] || 'Pending';
};

const mapPaymentMethodToEnum = (paymentMethod) => {
  const paymentMap = {
    'Cash': 'CASH',
    'Credit Card': 'CREDIT_CARD',
    'Bank Transfer': 'BANK_TRANSFER',
    'Digital Wallet': 'DIGITAL_WALLET',
    'CASH': 'CASH',
    'CREDIT_CARD': 'CREDIT_CARD',
    'BANK_TRANSFER': 'BANK_TRANSFER',
    'DIGITAL_WALLET': 'DIGITAL_WALLET'
  };
  return paymentMap[paymentMethod] || 'CASH';
};

const mapPaymentMethodFromEnum = (paymentMethod) => {
  const paymentMap = {
    'CASH': 'Cash',
    'CREDIT_CARD': 'Credit Card',
    'BANK_TRANSFER': 'Bank Transfer',
    'DIGITAL_WALLET': 'Digital Wallet'
  };
  return paymentMap[paymentMethod] || 'Cash';
};

const getDiscountPercentage = (discount) => {
  switch (discount) {
    case 'FIVE_PERCENT': return 0.05;
    case 'TEN_PERCENT': return 0.10;
    case 'FIFTEEN_PERCENT': return 0.15;
    default: return 0;
  }
};

const getAllSales = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        s.id, s.sale_id, s.customer_id, s.customer_name, s.product_id, s.product_lot, s.product_fileno, 
        s.weight, s.balance_units, s.balance_weight, s.unit_price, s.discount, s.amount, 
        s.payment_method, s.status, s.notes, s.created_by, s.company_id, 
        s.created_at, s.updated_at
      FROM sales s
      ORDER BY s.created_at DESC
    `);
    const sales = result.rows.map(row => ({
      id: row.id,
      saleId: row.sale_id,
      customerId: parseInt(row.customer_id),
      customerName: row.customer_name,
      productId: parseInt(row.product_id),
      productLot: row.product_lot,
      productFileno: row.product_fileno,
      weight: parseFloat(row.weight),
      balanceUnits: parseInt(row.balance_units),
      balanceWeight: parseFloat(row.balance_weight),
      unitPrice: parseFloat(row.unit_price),
      discount: mapDiscountFromEnum(row.discount),
      amount: parseFloat(row.amount),
      paymentMethod: mapPaymentMethodFromEnum(row.payment_method),
      status: mapSalesStatusFromEnum(row.status),
      notes: row.notes,
      createdBy: row.created_by,
      companyId: row.company_id,
      createdAt: row.created_at.toISOString(),
      updatedAt: row.updated_at.toISOString()
    }));
    res.status(200).json({ data: sales });
  } catch (error) {
    console.error('Error fetching sales:', error);
    res.status(500).json({ error: 'Failed to fetch sales.' });
  }
};

const getSaleById = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(`
      SELECT 
        s.id, s.sale_id, s.customer_id, s.customer_name, s.product_id, s.product_lot, s.product_fileno, 
        s.weight, s.balance_units, s.balance_weight, s.unit_price, s.discount, s.amount, 
        s.payment_method, s.status, s.notes, s.created_by, s.company_id, 
        s.created_at, s.updated_at
      FROM sales s
      WHERE s.id = $1
    `, [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Sale not found.' });
    }
    const row = result.rows[0];
    const sale = {
      id: row.id,
      saleId: row.sale_id,
      customerId: parseInt(row.customer_id),
      customerName: row.customer_name,
      productId: parseInt(row.product_id),
      productLot: row.product_lot || '',
      productFileno: row.product_fileno || '',
      weight: parseFloat(row.weight),
      balanceUnits: parseInt(row.balance_units),
      balanceWeight: parseFloat(row.balance_weight),
      unitPrice: parseFloat(row.unit_price),
      discount: mapDiscountFromEnum(row.discount),
      amount: parseFloat(row.amount),
      paymentMethod: mapPaymentMethodFromEnum(row.payment_method),
      status: mapSalesStatusFromEnum(row.status),
      notes: row.notes || '',
      createdBy: row.created_by,
      companyId: row.company_id,
      createdAt: row.created_at.toISOString(),
      updatedAt: row.updated_at.toISOString()
    };
    res.status(200).json(sale);
  } catch (error) {
    console.error('Error fetching sale:', error);
    res.status(500).json({ error: 'Failed to fetch sale.' });
  }
};

const createSale = async (req, res) => {
  const {
    saleId, customerId, customerName, productId, balanceUnits, weight, unitPrice, date,
    discount, paymentMethod, status, notes, createdBy, companyId
  } = req.body;

  if (!saleId || !customerId || !customerName || !productId || balanceUnits == null || weight == null || unitPrice == null || !date || !paymentMethod || !status || !createdBy) {
    return res.status(400).json({ error: 'All required fields must be provided.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Validate customer
    const customerResult = await client.query('SELECT id, name, amount FROM customers WHERE id = $1', [customerId]);
    if (customerResult.rows.length === 0) {
      throw new Error('Customer not found.');
    }
    const customer = customerResult.rows[0];
    if (customer.name !== customerName) {
      throw new Error('Customer name does not match.');
    }

    // Validate product
    const productResult = await client.query(
      'SELECT id, lot, fileno, balance_unit, balance_weight FROM products WHERE id = $1',
      [productId]
    );
    if (productResult.rows.length === 0) {
      throw new Error('Product not found.');
    }
    const product = productResult.rows[0];
    if (balanceUnits > product.balance_unit) {
      throw new Error(`Balance units (${balanceUnits}) exceed available units (${product.balance_unit}).`);
    }

    // Calculate balance_weight and amount with discount
    const balanceWeight = weight * balanceUnits;
    const baseAmount = (weight * balanceUnits / 45) * unitPrice;
    const discountPercentage = getDiscountPercentage(mapDiscountToEnum(discount));
    const amount = baseAmount * (1 - discountPercentage);

    // Insert sale
    const insertSaleQuery = `
      INSERT INTO sales (
        sale_id, customer_id, customer_name, product_id, product_lot, product_fileno, 
        weight, balance_units, balance_weight, unit_price, discount, amount, 
        payment_method, status, notes, created_by, company_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
      RETURNING *
    `;
    const saleResult = await client.query(insertSaleQuery, [
      saleId, customerId, customerName, productId, product.lot, product.fileno,
      weight, balanceUnits, balanceWeight, unitPrice, mapDiscountToEnum(discount),
      amount, mapPaymentMethodToEnum(paymentMethod), mapSalesStatusToEnum(status),
      notes, createdBy, companyId
    ]);

    // Update product balances if status is COMPLETED
    if (mapSalesStatusToEnum(status) === 'COMPLETED') {
      const newBalanceUnit = product.balance_unit - balanceUnits;
      const newBalanceWeight = product.balance_weight - balanceWeight;
      await client.query(
        'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        [newBalanceUnit, newBalanceWeight, productId]
      );

      // Update customer balance
      const newCustomerAmount = parseFloat(customer.amount) + amount;
      await client.query(
        'UPDATE customers SET amount = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [newCustomerAmount, customerId]
      );
    }

    await client.query('COMMIT');
    const sale = saleResult.rows[0];
    res.status(201).json({
      id: sale.id,
      saleId: sale.sale_id,
      customerId: parseInt(sale.customer_id),
      customerName: sale.customer_name,
      productId: parseInt(sale.product_id),
      productLot: sale.product_lot,
      productFileno: sale.product_fileno,
      weight: parseFloat(sale.weight),
      balanceUnits: parseInt(sale.balance_units),
      balanceWeight: parseFloat(sale.balance_weight),
      unitPrice: parseFloat(sale.unit_price),
      discount: mapDiscountFromEnum(sale.discount),
      amount: parseFloat(sale.amount),
      paymentMethod: mapPaymentMethodFromEnum(sale.payment_method),
      status: mapSalesStatusFromEnum(sale.status),
      notes: sale.notes,
      createdBy: sale.created_by,
      companyId: sale.company_id,
      createdAt: sale.created_at.toISOString(),
      updatedAt: sale.updated_at.toISOString()
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating sale:', error);
    res.status(400).json({ error: error.message || 'Failed to create sale.' });
  } finally {
    client.release();
  }
};

const updateSale = async (req, res) => {
  const { id } = req.params;
  const {
    saleId, customerId, customerName, productId, balanceUnits, weight, unitPrice, date,
    discount, paymentMethod, status, notes, createdBy, companyId
  } = req.body;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Fetch existing sale
    const existingSaleResult = await client.query('SELECT * FROM sales WHERE id = $1', [id]);
    if (existingSaleResult.rows.length === 0) {
      throw new Error('Sale not found.');
    }
    const existingSale = existingSaleResult.rows[0];

    // Validate customer
    const customerResult = await client.query('SELECT id, name, amount FROM customers WHERE id = $1', [customerId]);
    if (customerResult.rows.length === 0) {
      throw new Error('Customer not found.');
    }
    const customer = customerResult.rows[0];
    if (customer.name !== customerName) {
      throw new Error('Customer name does not match.');
    }

    // Validate product
    const productResult = await client.query(
      'SELECT id, lot, fileno, balance_unit, balance_weight FROM products WHERE id = $1',
      [productId]
    );
    if (productResult.rows.length === 0) {
      throw new Error('Product not found.');
    }
    const product = productResult.rows[0];

    // Validate balance units
    const unitsAdjustment = parseInt(existingSale.balance_units) - balanceUnits;
    const newBalanceUnit = product.balance_unit + unitsAdjustment;
    if (newBalanceUnit < 0) {
      throw new Error(`Balance units (${balanceUnits}) exceed available units (${product.balance_unit + parseInt(existingSale.balance_units)}).`);
    }

    // Calculate balance_weight and amount with discount
    const balanceWeight = weight * balanceUnits;
    const baseAmount = (weight * balanceUnits / 45) * unitPrice;
    const discountPercentage = getDiscountPercentage(mapDiscountToEnum(discount));
    const amount = baseAmount * (1 - discountPercentage);

    // Reverse previous product and customer balances if status was COMPLETED
    if (existingSale.status === 'COMPLETED') {
      const productRevertResult = await client.query(
        'SELECT balance_unit, balance_weight FROM products WHERE id = $1',
        [existingSale.product_id]
      );
      if (productRevertResult.rows.length === 0) {
        throw new Error('Previous product not found.');
      }
      const prevProduct = productRevertResult.rows[0];
      const revertBalanceUnit = prevProduct.balance_unit + parseInt(existingSale.balance_units);
      const revertBalanceWeight = prevProduct.balance_weight + parseFloat(existingSale.balance_weight);
      await client.query(
        'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        [revertBalanceUnit, revertBalanceWeight, existingSale.product_id]
      );

      const customerRevertResult = await client.query('SELECT amount FROM customers WHERE id = $1', [existingSale.customer_id]);
      if (customerRevertResult.rows.length === 0) {
        throw new Error('Previous customer not found.');
      }
      const prevCustomer = customerRevertResult.rows[0];
      const revertedAmount = parseFloat(prevCustomer.amount) - parseFloat(existingSale.amount);
      await client.query(
        'UPDATE customers SET amount = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [revertedAmount, existingSale.customer_id]
      );
    }

    // Update product balances if new status is COMPLETED
    if (mapSalesStatusToEnum(status) === 'COMPLETED') {
      const newBalanceUnit = product.balance_unit - balanceUnits;
      const newBalanceWeight = product.balance_weight - balanceWeight;
      await client.query(
        'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        [newBalanceUnit, newBalanceWeight, productId]
      );

      // Update customer balance
      const newCustomerAmount = parseFloat(customer.amount) + amount;
      await client.query(
        'UPDATE customers SET amount = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [newCustomerAmount, customerId]
      );
    }

    // Update sale
    const updateSaleQuery = `
      UPDATE sales SET
        sale_id = $1, customer_id = $2, customer_name = $3, product_id = $4, product_lot = $5, product_fileno = $6,
        weight = $7, balance_units = $8, balance_weight = $9, unit_price = $10, discount = $11, amount = $12,
        payment_method = $13, status = $14, notes = $15, created_by = $16, company_id = $17, updated_at = CURRENT_TIMESTAMP
      WHERE id = $18
      RETURNING *
    `;
    const saleResult = await client.query(updateSaleQuery, [
      saleId, customerId, customerName, productId, product.lot, product.fileno,
      weight, balanceUnits, balanceWeight, unitPrice, mapDiscountToEnum(discount),
      amount, mapPaymentMethodToEnum(paymentMethod), mapSalesStatusToEnum(status),
      notes, createdBy, companyId, id
    ]);

    await client.query('COMMIT');
    const sale = saleResult.rows[0];
    res.status(200).json({
      id: sale.id,
      saleId: sale.sale_id,
      customerId: parseInt(sale.customer_id),
      customerName: sale.customer_name,
      productId: parseInt(sale.product_id),
      productLot: sale.product_lot || '',
      productFileno: sale.product_fileno || '',
      weight: parseFloat(sale.weight),
      balanceUnits: parseInt(sale.balance_units),
      balanceWeight: parseFloat(sale.balance_weight),
      unitPrice: parseFloat(sale.unit_price),
      discount: mapDiscountFromEnum(sale.discount),
      amount: parseFloat(sale.amount),
      paymentMethod: mapPaymentMethodFromEnum(sale.payment_method),
      status: mapSalesStatusFromEnum(sale.status),
      notes: sale.notes || '',
      createdBy: sale.created_by,
      companyId: sale.company_id,
      createdAt: sale.created_at.toISOString(),
      updatedAt: sale.updated_at.toISOString()
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error updating sale:', error);
    res.status(400).json({ error: error.message || 'Failed to update sale.' });
  } finally {
    client.release();
  }
};

const deleteSale = async (req, res) => {
  const { id } = req.params;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Fetch sale
    const saleResult = await pool.query('SELECT * FROM sales WHERE id = $1', [id]);
    if (saleResult.rows.length === 0) {
      throw new Error('Sale not found.');
    }
    const sale = saleResult.rows[0];

    // Restore product balances if status was COMPLETED
    if (sale.status === 'COMPLETED') {
      const productResult = await client.query(
        'SELECT balance_unit, balance_weight FROM products WHERE id = $1',
        [sale.product_id]
      );
      if (productResult.rows.length === 0) {
        throw new Error('Product not found.');
      }
      const product = productResult.rows[0];
      const newBalanceUnit = product.balance_unit + parseInt(sale.balance_units);
      const newBalanceWeight = product.balance_weight + parseFloat(sale.balance_weight);
      await client.query(
        'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
        [newBalanceUnit, newBalanceWeight, sale.product_id]
      );

      // Reverse customer balance
      const customerResult = await client.query('SELECT amount FROM customers WHERE id = $1', [sale.customer_id]);
      if (customerResult.rows.length === 0) {
        throw new Error('Customer not found.');
      }
      const customer = customerResult.rows[0];
      const newCustomerAmount = parseFloat(customer.amount) - parseFloat(sale.amount);
      await client.query(
        'UPDATE customers SET amount = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [newCustomerAmount, sale.customer_id]
      );
    }

    // Delete sale
    await client.query('DELETE FROM sales WHERE id = $1', [id]);
    await client.query('COMMIT');
    res.status(200).json({ message: 'Sale deleted successfully.' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error deleting sale:', error);
    res.status(400).json({ error: error.message || 'Failed to delete sale.' });
  } finally {
    client.release();
  }
};

const downloadSalesPDF = async (req, res) => {
  let doc;

  try {
    const result = await pool.query(`
      SELECT 
        s.sale_id, s.customer_name, s.product_lot, s.product_fileno, s.weight, s.balance_units, 
        s.balance_weight, s.unit_price, s.amount, s.created_at, s.discount, s.payment_method, s.status
      FROM sales s
      ORDER BY s.created_at DESC
    `);
    const sales = result.rows;

    doc = new PDFDocument({ 
      margin: 40,
      size: 'A4',
      layout: 'landscape',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="sales-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === HEADER SECTION ===
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Sales Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`, 120, 90);

      doc
        .moveTo(40, 120)
        .lineTo(800, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalSales = sales.length;
    const totalAmount = sales.reduce(
      (sum, sale) => sum + (parseFloat(sale.amount) || 0),
      0
    );
    const totalDiscount = sales.reduce(
      (sum, sale) => sum + (parseFloat(sale.discount) || 0),
      0
    );
    const statusCounts = sales.reduce((acc, sale) => {
      const status = (sale.status || 'unknown').toLowerCase();
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    let yPos = 140;
    
    doc
      .rect(40, yPos, 760, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Sales: ${totalSales}`, 50, yPos + 30)
      .text(`Total Amount: RS ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 50, yPos + 45)
      .text(`Total Discount: RS ${totalDiscount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 250, yPos + 30)
      .text(`Average Amount: RS ${totalSales > 0 ? (totalAmount / totalSales).toFixed(2) : '0.00'}`, 250, yPos + 45)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 500, yPos + 30);

    yPos += 80;

    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Status Breakdown:', 40, yPos);
    
    yPos += 25;
    let statusX = 50;
    let statusY = yPos;
    
    Object.keys(statusCounts).forEach((status, index) => {
      const count = statusCounts[status] || 0;
      const percentage = totalSales > 0 ? ((count / totalSales) * 100).toFixed(1) : '0.0';
      
      const statusText = `${status}: ${count} (${percentage}%)`;
      const statusHeight = doc
        .fontSize(10)
        .font('Helvetica')
        .heightOfString(statusText, { width: 110 });
      
      if (statusY + statusHeight > 500) {
        doc.addPage();
        statusY = 60;
        statusX = 50;
      }

      doc
        .fontSize(10)
        .fillColor('#34495e')
        .font('Helvetica')
        .text(statusText, statusX, statusY);
      
      statusX += 120;
      if ((index + 1) % 5 === 0) {
        statusX = 50;
        statusY += statusHeight + 8;
      }
    });

    yPos = statusY + 40;

    // === TABLE HEADER ===
    const drawTableHeader = () => {
      if (yPos + 25 > 500) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 760, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');
      
      doc.text('Sale ID', 50, yPos + 8, { width: 60 });
      doc.text('Customer', 110, yPos + 8, { width: 80 });
      doc.text('Lot', 190, yPos + 8, { width: 60 });
      doc.text('File No', 250, yPos + 8, { width: 60 });
      doc.text('Weight', 320, yPos + 8, { width: 50 });
      doc.text('Bal Units', 370, yPos + 8, { width: 50 });
      doc.text('Total Bal', 420, yPos + 8, { width: 50 });
      doc.text('Unit Price', 470, yPos + 8, { width: 50 });
      doc.text('Discount', 540, yPos + 8, { width: 50 });
      doc.text('Status', 620, yPos + 8, { width: 60 });
      doc.text('Date', 680, yPos + 8, { width: 40 });
      doc.text('Amount', 730, yPos + 8, { width: 60, align: 'left' });
      
      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS ===
    sales.forEach((sale, index) => {
      const customerName = sale.customer_name || 'N/A';
      const productLot = sale.product_lot || `Product #${sale.sale_id}`;
      const fileNo = sale.product_fileno || 'N/A';
      
      const customerHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(customerName, { width: 80 });
      const rowHeight = Math.max(20, customerHeight + 10);

      if (yPos + rowHeight > 500) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 760, rowHeight)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(9)
        .font('Helvetica');

      doc.text(sale.sale_id.substring(0, 15), 50, yPos + 6, { width: 60 });
      doc.text(customerName.substring(0, 20), 110, yPos + 6, { width: 80 });
      doc.text(productLot.substring(0, 15), 190, yPos + 6, { width: 60 });
      doc.text(fileNo.substring(0, 15), 250, yPos + 6, { width: 60 });
      doc.text(Number(sale.weight) || 0, 320, yPos + 6, { width: 50 });
      doc.text(Number(sale.balance_units) || 0, 370, yPos + 6, { width: 50 });
      doc.text(Number(sale.balance_weight) || 0, 420, yPos + 6, { width: 50 });
      doc.text(
        `RS ${(Number(sale.unit_price) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        470, yPos + 6, 
        { width: 50, align: 'right' }
      );
      doc.text(
        `RS ${(Number(sale.discount) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        540, yPos + 6, 
        { width: 50, align: 'right' }
      );
      
      const status = (sale.status || 'unknown').toLowerCase();
      let statusColor = '#2c3e50';
      if (status === 'completed' || status === 'received') statusColor = '#27ae60';
      else if (status === 'failed' || status === 'refunded') statusColor = '#e74c3c';
      else if (status === 'pending' || status === 'processing') statusColor = '#f39c12';
      
      doc.fillColor(statusColor).text(status, 620, yPos + 6, { width: 60 });
      
      doc.fillColor('#2c3e50').text(
        sale.created_at ?
          new Date(sale.created_at).toLocaleDateString('en-US', { 
            month: 'short', 
            day: '2-digit', 
            year: '2-digit' 
          }) :
          'N/A',
        680, yPos + 6, 
        { width: 40 }
      );
      doc.text(
        `RS ${(parseFloat(sale.amount) || 0).toLocaleString('en-US', { 
          minimumFractionDigits: 2, 
          maximumFractionDigits: 2 
        })}`,
        730, yPos + 6, 
        { width: 60, align: 'left' }
      );

      yPos += rowHeight;
    });

    if (yPos + 110 > 500) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;
    
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating sales PDF:', { error: error.message, stack: error.stack });
    
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate sales PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

module.exports = {
  getAllSales,
  getSaleById,
  createSale,
  updateSale,
  deleteSale,
  downloadSalesPDF,
};