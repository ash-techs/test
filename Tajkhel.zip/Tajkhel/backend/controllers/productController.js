const { Pool } = require('pg');

const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// GET all products
const getAllProducts = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = 'SELECT * FROM products';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE(updated_at, created_at) >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY lot ASC';

    const result = await pool.query(query, values);
    const products = result.rows.map(product => ({
      id: product.id,
      lot: product.lot || '',
      fileno: product.fileno || '',
      color: product.color || null,
      kind: product.kind || null,
      mix: product.mix || null,
      balance_unit: Number(product.balance_unit) || 0,
      weight: Number(product.weight) || 0,
      issue: Number(product.issue) || 0,
      balance_weight: Number(product.balance_weight) || 0,
      price: Number(product.price) || 0,
      description: product.description || null,
      created_at: product.created_at ? product.created_at.toISOString() : null,
      updated_at: product.updated_at ? product.updated_at.toISOString() : null,
    }));
    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
};

// GET single product
const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM products WHERE id = $1', [parseInt(id)]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const product = result.rows[0];
    const transformedProduct = {
      id: product.id,
      lot: product.lot || '',
      fileno: product.fileno || '',
      color: product.color || null,
      kind: product.kind || null,
      mix: product.mix || null,
      balance_unit: Number(product.balance_unit) || 0,
      weight: Number(product.weight) || 0,
      issue: Number(product.issue) || 0,
      balance_weight: Number(product.balance_weight) || 0,
      price: Number(product.price) || 0,
      description: product.description || null,
      created_at: product.created_at ? product.created_at.toISOString() : null,
      updated_at: product.updated_at ? product.updated_at.toISOString() : null,
    };
    res.json(transformedProduct);
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
};

// CREATE new product
const createProduct = async (req, res) => {
  try {
    const { lot, fileno, color, kind, mix, balance_unit, weight, issue, price, description } = req.body;

    if (!lot || !fileno || balance_unit === undefined) {
      return res.status(400).json({ error: 'Lot, fileno, and balance_unit are required' });
    }

    const parsedBalanceUnit = parseInt(balance_unit, 10);
    const parsedWeight = parseFloat(weight);
    const parsedIssue = parseInt(issue, 10) || 0;
    const parsedPrice = parseFloat(price);
    const calculatedBalanceWeight = (parsedBalanceUnit * parsedWeight) + parsedIssue;

    if (isNaN(parsedBalanceUnit) || parsedBalanceUnit < 0) {
      return res.status(400).json({ error: 'Balance unit must be a valid non-negative number' });
    }
    if (isNaN(parsedIssue)) {
      return res.status(400).json({ error: 'Issue must be a valid number' });
    }
    if (calculatedBalanceWeight < 0) {
      return res.status(400).json({ error: 'Balance weight cannot be negative' });
    }
    if (description && description.length > 500) {
      return res.status(400).json({ error: 'Description cannot exceed 500 characters' });
    }

    const conflict = await pool.query('SELECT * FROM products WHERE lot = $1', [lot]);
    if (conflict.rows.length > 0) {
      return res.status(400).json({ error: 'Lot already in use' });
    }

    const now = new Date();
    const result = await pool.query(
      'INSERT INTO products (lot, fileno, color, kind, mix, balance_unit, weight, issue, balance_weight, price, description, created_at, updated_at, total) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, NULL) RETURNING *',
      [lot, fileno, color || null, kind || null, mix || null, parsedBalanceUnit, parsedWeight, parsedIssue, calculatedBalanceWeight, parsedPrice, description || null, now, now]
    );

    const product = result.rows[0];
    const transformedProduct = {
      id: product.id,
      lot: product.lot || '',
      fileno: product.fileno || '',
      color: product.color || null,
      kind: product.kind || null,
      mix: product.mix || null,
      balance_unit: Number(product.balance_unit) || 0,
      weight: Number(product.weight) || 0,
      issue: Number(product.issue) || 0,
      balance_weight: Number(product.balance_weight) || 0,
      price: Number(product.price) || 0,
      description: product.description || null,
      created_at: product.created_at ? product.created_at.toISOString() : null,
      updated_at: product.updated_at ? product.updated_at.toISOString() : null,
    };
    res.status(201).json(transformedProduct);
  } catch (error) {
    console.error('Error creating product:', error);
    res.status(500).json({ error: 'Failed to create product' });
  }
};

// UPDATE product
const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const { lot, fileno, color, kind, mix, balance_unit, weight, issue, price, description } = req.body;

    const existing = await pool.query('SELECT * FROM products WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (lot) {
      const conflict = await pool.query('SELECT * FROM products WHERE lot = $1 AND id != $2', [lot, parseInt(id)]);
      if (conflict.rows.length > 0) {
        return res.status(400).json({ error: 'Lot already in use' });
      }
    }

    const parsedBalanceUnit = balance_unit !== undefined ? parseInt(balance_unit, 10) : existing.rows[0].balance_unit;
    const parsedWeight = weight !== undefined ? parseFloat(weight) : existing.rows[0].weight;
    const parsedIssue = issue !== undefined ? parseInt(issue, 10) : existing.rows[0].issue;
    const parsedPrice = price !== undefined ? parseFloat(price) : existing.rows[0].price;
    const calculatedBalanceWeight = (parsedBalanceUnit * parsedWeight) + parsedIssue;

    if (balance_unit !== undefined && (isNaN(parsedBalanceUnit) || parsedBalanceUnit < 0)) {
      return res.status(400).json({ error: 'Balance unit must be a valid non-negative number' });
    }
    if (issue !== undefined && isNaN(parsedIssue)) {
      return res.status(400).json({ error: 'Issue must be a valid number' });
    }
    if (calculatedBalanceWeight < 0) {
      return res.status(400).json({ error: 'Balance weight cannot be negative' });
    }
    if (description && description.length > 500) {
      return res.status(400).json({ error: 'Description cannot exceed 500 characters' });
    }

    const updated = {
      lot: lot || existing.rows[0].lot,
      fileno: fileno || existing.rows[0].fileno,
      color: color !== undefined ? (color || null) : existing.rows[0].color,
      kind: kind !== undefined ? (kind || null) : existing.rows[0].kind,
      mix: mix !== undefined ? (mix || null) : existing.rows[0].mix,
      balance_unit: parsedBalanceUnit,
      weight: parsedWeight,
      issue: parsedIssue,
      balance_weight: calculatedBalanceWeight,
      price: parsedPrice,
      description: description !== undefined ? (description || null) : existing.rows[0].description,
    };

    const now = new Date();
    const result = await pool.query(
      'UPDATE products SET lot = $1, fileno = $2, color = $3, kind = $4, mix = $5, balance_unit = $6, weight = $7, issue = $8, balance_weight = $9, price = $10, description = $11, updated_at = $12, total = NULL WHERE id = $13 RETURNING *',
      [updated.lot, updated.fileno, updated.color, updated.kind, updated.mix, updated.balance_unit, updated.weight, updated.issue, updated.balance_weight, updated.price, updated.description, now, parseInt(id)]
    );

    const product = result.rows[0];
    const transformedProduct = {
      id: product.id,
      lot: product.lot || '',
      fileno: product.fileno || '',
      color: product.color || null,
      kind: product.kind || null,
      mix: product.mix || null,
      balance_unit: Number(product.balance_unit) || 0,
      weight: Number(product.weight) || 0,
      issue: Number(product.issue) || 0,
      balance_weight: Number(product.balance_weight) || 0,
      price: Number(product.price) || 0,
      description: product.description || null,
      created_at: product.created_at ? product.created_at.toISOString() : null,
      updated_at: product.updated_at ? product.updated_at.toISOString() : null,
    };
    res.json(transformedProduct);
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ error: 'Failed to update product' });
  }
};

// DELETE product
const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = await pool.query('SELECT * FROM products WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Product not found' });
    }

    await pool.query('DELETE FROM products WHERE id = $1', [parseInt(id)]);
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: 'Failed to delete product' });
  }
};

// GET /api/download/pdf - Download products PDF
const downloadProductsPDF = async (req, res) => {
  let doc;

  try {
    const result = await pool.query(`
      SELECT 
        id,
        lot,
        fileno,
        color,
        kind,
        mix,
        balance_unit,
        weight,
        issue,
        balance_weight,
        price,
        description,
        created_at,
        updated_at
      FROM products
      ORDER BY lot ASC
    `);

    doc = new PDFDocument({ 
      margin: 40,
      size: 'A4',
      layout: 'landscape',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="products-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === HEADER SECTION ===
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Products Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`, 120, 90);

      doc
        .moveTo(40, 120)
        .lineTo(800, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalProducts = result.rows.length;
    const totalBalanceUnits = result.rows.reduce(
      (sum, product) => sum + (Number(product.balance_unit) || 0),
      0
    );
    const totalBalanceWeight = result.rows.reduce(
      (sum, product) => sum + (Number(product.balance_weight) || 0),
      0
    );
    const totalPrice = result.rows.reduce(
      (sum, product) => sum + (Number(product.price) || 0),
      0
    );

    let yPos = 140;
    
    doc
      .rect(40, yPos, 760, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Products: ${totalProducts}`, 50, yPos + 30)
      .text(`Total Balance Units: ${totalBalanceUnits}`, 50, yPos + 45)
      .text(`Total Balance Weight: ${totalBalanceWeight.toFixed(2)}`, 250, yPos + 30)
      .text(`Total Price: RS ${totalPrice.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 250, yPos + 45)
      .text(`Average Price: RS ${totalProducts > 0 ? (totalPrice / totalProducts).toFixed(2) : '0.00'}`, 500, yPos + 30)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 500, yPos + 45);

    yPos += 80;

    // === TABLE HEADER ===
    const drawTableHeader = () => {
      if (yPos + 25 > 500) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 760, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');
      
      doc.text('Lot', 50, yPos + 8, { width: 60 });
      doc.text('File No', 110, yPos + 8, { width: 60 });
      doc.text('Color', 180, yPos + 8, { width: 60 });
      doc.text('Kind', 240, yPos + 8, { width: 60 });
      doc.text('Mix', 290, yPos + 8, { width: 60 });
      doc.text('Bal Units', 350, yPos + 8, { width: 60 });
      doc.text('Weight', 410, yPos + 8, { width: 60 });
      doc.text('Issue', 470, yPos + 8, { width: 60 });
      doc.text('Bal Weight', 530, yPos + 8, { width: 60 });
      doc.text('Price (RS)', 610, yPos + 8, { width: 100});
      doc.text('Created', 750, yPos + 8, { width: 60 });
      
      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS ===
    result.rows.forEach((product, index) => {
      const lot = product.lot || 'N/A';
      const fileno = product.fileno || 'N/A';
      const color = product.color || 'N/A';
      const kind = product.kind || 'N/A';
      const mix = product.mix || 'N/A';
      const description = product.description || 'N/A';
      
      const lotHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(lot, { width: 60 });
      const descriptionHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(description, { width: 100 });
      const rowHeight = Math.max(20, lotHeight + 10, descriptionHeight + 10);

      if (yPos + rowHeight > 500) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 760, rowHeight)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(9)
        .font('Helvetica');

      doc.text(lot, 50, yPos + 6, { width: 60 });
      doc.text(fileno, 110, yPos + 6, { width: 70 });
      doc.text(color, 180, yPos + 6, { width: 50 });
      doc.text(kind, 240, yPos + 6, { width: 50 });
      doc.text(mix, 290, yPos + 6, { width: 60 });
      doc.text(Number(product.balance_unit) || 0, 350, yPos + 6, { width: 60 });
      doc.text(Number(product.weight) || 0, 410, yPos + 6, { width: 60 });
      doc.text(Number(product.issue) || 0, 470, yPos + 6, { width: 60 });
      doc.text(Number(product.balance_weight) || 0, 530, yPos + 6, { width: 60 });
      doc.text(
        `RS ${(Number(product.price) || 0).toLocaleString('en-US', { 
          minimumFractionDigits: 2, 
          maximumFractionDigits: 2 
        })}`, 
        610, yPos + 6, 
        { width: 90, align: 'left' }
      );
      doc.text(
        product.created_at ? 
        new Date(product.created_at).toLocaleDateString('en-US', { 
          month: 'short', 
          day: '2-digit', 
          year: '2-digit' 
        }) : 'N/A', 
        750, yPos + 6, 
        { width: 60 }
      );

      yPos += rowHeight;
    });

    if (yPos + 110 > 500) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;
    
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
       .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating products PDF:', { error: error.message, stack: error.stack });
    
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate products PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  downloadProductsPDF,
};