const { Pool } = require('pg');
const crypto = require('crypto');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// GET all companies
const getAllCompanies = async (req, res) => {
  try {
    const { search, dateRange } = req.query;
    let query = 'SELECT * FROM companies';
    const values = [];

    if (search || dateRange) {
      query += ' WHERE';
      let conditions = [];

      if (search) {
        conditions.push('name ILIKE $1 OR email ILIKE $1');
        values.push(`%${search}%`);
      }

      if (dateRange) {
        let days;
        switch (dateRange) {
          case '7d':
            days = 7;
            break;
          case '14d':
            days = 14;
            break;
          case '30d':
            days = 30;
            break;
          default:
            days = 7;
        }
        const index = values.length + 1;
        conditions.push(`COALESCE("updatedAt", "createdAt") >= CURRENT_DATE - INTERVAL $${index}`);
        values.push(`${days} days`);
      }

      query += ' ' + conditions.join(' AND ');
    }
    query += ' ORDER BY name ASC';

    const result = await pool.query(query, values);

    const transformedCompanies = result.rows.map(company => ({
      id: company.id,
      name: company.name,
      contact: company.contact || '',
      country: company.country || '',
      phone: company.phone || '',
      email: company.email,
      amount: Number(company.amount) || 0,
      createdAt: company.createdAt ? company.createdAt.toISOString() : null,
      updatedAt: company.updatedAt ? company.updatedAt.toISOString() : null,
    }));

    res.json(transformedCompanies);
  } catch (error) {
    console.error('Error fetching companies:', error);
    res.status(500).json({ error: 'Failed to fetch companies' });
  }
};

// GET single company by ID
const getCompanyById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM companies WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    const company = result.rows[0];
    res.json({
      id: company.id,
      name: company.name,
      contact: company.contact || '',
      country: company.country || '',
      phone: company.phone || '',
      email: company.email,
      amount: Number(company.amount) || 0,
      createdAt: company.createdAt ? company.createdAt.toISOString() : null,
      updatedAt: company.updatedAt ? company.updatedAt.toISOString() : null,
    });
  } catch (error) {
    console.error('Error fetching company:', error);
    res.status(500).json({ error: 'Failed to fetch company' });
  }
};

// CREATE new company
const createCompany = async (req, res) => {
  try {
    const { name, contact, country, phone, email, amount } = req.body;

    if (!name || !email) {
      return res.status(400).json({ error: 'Name and email are required' });
    }

    const existing = await pool.query('SELECT * FROM companies WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Company with this email already exists' });
    }

    const amountNum = amount !== undefined ? Number(amount) : 0;
    if (isNaN(amountNum) || amountNum < 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    const id = crypto.randomUUID();
    const now = new Date();
    const result = await pool.query(
      'INSERT INTO companies (id, name, contact, country, phone, email, amount, "createdAt", "updatedAt") VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
      [id, name, contact || '', country || '', phone || '', email, amountNum, now, now]
    );

    res.status(201).json({
      id: result.rows[0].id,
      name: result.rows[0].name,
      contact: result.rows[0].contact || '',
      country: result.rows[0].country || '',
      phone: result.rows[0].phone || '',
      email: result.rows[0].email,
      amount: Number(result.rows[0].amount) || 0,
      createdAt: result.rows[0].createdAt ? result.rows[0].createdAt.toISOString() : null,
      updatedAt: result.rows[0].updatedAt ? result.rows[0].updatedAt.toISOString() : null,
    });
  } catch (error) {
    console.error('Error creating company:', error);
    res.status(500).json({ error: 'Failed to create company' });
  }
};

// UPDATE company
const updateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, contact, country, phone, email, amount } = req.body;

    const existing = await pool.query('SELECT * FROM companies WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    if (email && email !== existing.rows[0].email) {
      const conflict = await pool.query('SELECT * FROM companies WHERE email = $1', [email]);
      if (conflict.rows.length > 0) {
        return res.status(400).json({ error: 'Company with this email already exists' });
      }
    }

    const amountNum = amount !== undefined ? Number(amount) : existing.rows[0].amount;
    if (isNaN(amountNum) || amountNum < 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    const now = new Date();
    const result = await pool.query(
      'UPDATE companies SET name = $1, contact = $2, country = $3, phone = $4, email = $5, amount = $6, "updatedAt" = $7 WHERE id = $8 RETURNING *',
      [name || existing.rows[0].name, contact || '', country || '', phone || '', email || existing.rows[0].email, amountNum, now, id]
    );

    res.json({
      id: result.rows[0].id,
      name: result.rows[0].name,
      contact: result.rows[0].contact || '',
      country: result.rows[0].country || '',
      phone: result.rows[0].phone || '',
      email: result.rows[0].email,
      amount: Number(result.rows[0].amount) || 0,
      createdAt: result.rows[0].createdAt ? result.rows[0].createdAt.toISOString() : null,
      updatedAt: result.rows[0].updatedAt ? result.rows[0].updatedAt.toISOString() : null,
    });
  } catch (error) {
    console.error('Error updating company:', error);
    res.status(500).json({ error: 'Failed to update company' });
  }
};

// ADJUST company amount
const adjustCompanyAmount = async (req, res) => {
  try {
    const { id } = req.params;
    const { amount, action } = req.body;

    if (amount === undefined || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: 'Valid positive amount is required' });
    }

    if (!['add', 'subtract'].includes(action)) {
      return res.status(400).json({ error: 'Action must be "add" or "subtract"' });
    }

    const existing = await pool.query('SELECT * FROM companies WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    const currentAmount = Number(existing.rows[0].amount) || 0;
    const amountToAdjust = Number(amount);
    const newAmount = action === 'add' ? currentAmount + amountToAdjust : currentAmount - amountToAdjust;

    if (newAmount < 0) {
      return res.status(400).json({ error: 'Resulting amount cannot be negative' });
    }

    const now = new Date();
    const result = await pool.query('UPDATE companies SET amount = $1, "updatedAt" = $2 WHERE id = $3 RETURNING *', [
      newAmount,
      now,
      id,
    ]);

    res.json({
      id: result.rows[0].id,
      name: result.rows[0].name,
      contact: result.rows[0].contact || '',
      country: result.rows[0].country || '',
      phone: result.rows[0].phone || '',
      email: result.rows[0].email,
      amount: Number(result.rows[0].amount) || 0,
      createdAt: result.rows[0].createdAt ? result.rows[0].createdAt.toISOString() : null,
      updatedAt: result.rows[0].updatedAt ? result.rows[0].updatedAt.toISOString() : null,
    });
  } catch (error) {
    console.error('Error adjusting company amount:', error);
    res.status(500).json({ error: 'Failed to adjust company amount' });
  }
};

// DELETE company
const deleteCompany = async (req, res) => {
  try {
    const { id } = req.params;

    const existing = await pool.query('SELECT * FROM companies WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    await pool.query('DELETE FROM companies WHERE id = $1', [id]);
    res.json({ message: 'Company deleted successfully' });
  } catch (error) {
    console.error('Error deleting company:', error);
    res.status(500).json({ error: 'Failed to delete company' });
  }
};

// GENERATE PDF of companies
const generateCompaniesPDF = async (req, res) => {
  let doc;
  try {
    const { search, dateRange } = req.query;
    let query = 'SELECT * FROM companies';
    const values = [];

    if (search || dateRange) {
      query += ' WHERE';
      let conditions = [];

      if (search) {
        conditions.push('name ILIKE $1 OR email ILIKE $1');
        values.push(`%${search}%`);
      }

      if (dateRange) {
        let days;
        switch (dateRange) {
          case '7d':
            days = 7;
            break;
          case '14d':
            days = 14;
            break;
          case '30d':
            days = 30;
            break;
          default:
            days = 7;
        }
        const index = values.length + 1;
        conditions.push(`COALESCE("updatedAt", "createdAt") >= CURRENT_DATE - INTERVAL $${index}`);
        values.push(`${days} days`);
      }

      query += ' ' + conditions.join(' AND ');
    }
    query += ' ORDER BY name ASC';

    const result = await pool.query(query, values);
    const companies = result.rows.map(company => ({
      id: company.id,
      name: company.name,
      contact: company.contact || 'N/A',
      country: company.country || 'N/A',
      phone: company.phone || 'N/A',
      email: company.email,
      amount: Number(company.amount) || 0,
      createdAt: company.createdAt,
    }));

    doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="companies-report.pdf"');

    doc.on('error', err => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === HEADER SECTION ===
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPNAY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Companies Summary Report', 120, 75)
        .text(
          `Generated on: ${new Date().toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })}`,
          120,
          90
        );

      doc.moveTo(40, 120).lineTo(555, 120).strokeColor('#3498db').lineWidth(2).stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalCompanies = companies.length;
    const totalAmount = companies.reduce((sum, company) => sum + (company.amount || 0), 0);
    let yPos = 140;

    doc
      .rect(40, yPos, 515, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Companies: ${totalCompanies}`, 50, yPos + 30)
      .text(
        `Total Amount: RS ${totalAmount.toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`,
        50,
        yPos + 45
      )
      .text(
        `Average Amount: RS ${totalCompanies > 0 ? (totalAmount / totalCompanies).toFixed(2) : '0.00'}`,
        300,
        yPos + 30
      )
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 300, yPos + 45);

    yPos += 80;

    // === TABLE HEADER ===
    const drawTableHeader = () => {
      if (yPos + 25 > 680) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 515, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');

      doc.text('Company Name', 50, yPos + 8, { width: 100 });
      doc.text('Contact', 150, yPos + 8, { width: 80 });
      doc.text('Country', 230, yPos + 8, { width: 80 });
      doc.text('Phone', 310, yPos + 8, { width: 80 });
      doc.text('Email', 390, yPos + 8, { width: 100 });
      doc.text('Amount', 490, yPos + 8, { width: 60 });

      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS ===
    companies.forEach((company, index) => {
      const companyName = company.name || 'N/A';
      const contact = company.contact || 'N/A';
      const country = company.country || 'N/A';
      const phone = company.phone || 'N/A';
      const email = company.email || 'N/A';
      const nameHeight = doc.fontSize(9).font('Helvetica').heightOfString(companyName, { width: 100 });
      const emailHeight = doc.fontSize(9).font('Helvetica').heightOfString(email, { width: 100 });
      const rowHeight = Math.max(20, nameHeight + 10, emailHeight + 10);

      if (yPos + rowHeight > 680) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc.rect(40, yPos, 515, rowHeight).fill(rowColor).fillColor('#2c3e50').fontSize(9).font('Helvetica');

      doc.text(companyName, 50, yPos + 6, { width: 100 });
      doc.text(contact, 150, yPos + 6, { width: 80 });
      doc.text(country, 230, yPos + 6, { width: 80 });
      doc.text(phone, 310, yPos + 6, { width: 80 });
      doc.text(email, 390, yPos + 6, { width: 100 });
      doc.text(
        `RS ${(company.amount || 0).toLocaleString('en-US', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2,
        })}`,
        490,
        yPos + 6,
        { width: 60, align: 'left' }
      );

      yPos += rowHeight;
    });

    if (yPos + 110 > 680) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;

    // === FOOTER ===
    const addFooter = pageIndex => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating companies PDF:', { error: error.message, stack: error.stack });
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate companies PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

module.exports = {
  getAllCompanies,
  getCompanyById,
  createCompany,
  updateCompany,
  adjustCompanyAmount,
  deleteCompany,
  generateCompaniesPDF,
};