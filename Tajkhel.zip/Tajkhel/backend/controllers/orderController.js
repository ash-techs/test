const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Map order status from database enum to string
const mapOrderStatusFromEnum = (statusEnum) => {
  const map = {
    PENDING: "Pending",
    CONFIRMED: "Confirmed",
    SHIPPED: "Shipped",
    DELIVERED: "Delivered",
    CANCELLED: "Cancelled",
  };
  return map[statusEnum] || statusEnum;
};

// Map order status from string to database enum
const mapOrderStatusToEnum = (statusString) => {
  const map = {
    Pending: "PENDING",
    Confirmed: "CONFIRMED",
    Shipped: "SHIPPED",
    Delivered: "DELIVERED",
    Cancelled: "CANCELLED",
  };
  return map[statusString] || statusString;
};

// Calculate total amount including all fields
const calculateTotalAmount = (order) => {
  const baseTotal = (order.quantity || 0) * (order.price || 0) - (order.discount || 0);
  const taxAmount = baseTotal * ((order.tax || 0) / 100);
  return (
    baseTotal +
    taxAmount +
    (Number(order.fairCharges) || 0) +
    (Number(order.customDuties) || 0) +
    (Number(order.localFair) || 0) +
    (Number(order.salesTax) || 0) +
    (Number(order.officeExpense) || 0) +
    (Number(order.misc) || 0)
  );
};

// Helper function to update company amount
async function updateCompanyAmount(companyId, amountChange) {
  if (!companyId) return;
  try {
    const companyResult = await pool.query('SELECT amount FROM companies WHERE id = $1', [companyId]);
    if (companyResult.rows.length === 0) {
      throw new Error('Company not found');
    }
    const currentAmount = parseFloat(companyResult.rows[0].amount) || 0;
    const newAmount = Math.max(0, currentAmount + amountChange); // Prevent negative amounts
    await pool.query('UPDATE companies SET amount = $1 WHERE id = $2', [newAmount, companyId]);
  } catch (error) {
    console.error('Error updating company amount:', error.message);
    throw error;
  }
}

// Update company
async function updateCompany(req, res) {
  try {
    const { id } = req.params;
    const { amount } = req.body;

    if (amount === undefined || isNaN(amount) || amount < 0) {
      return res.status(400).json({ error: 'Invalid amount' });
    }

    const result = await pool.query('UPDATE companies SET amount = $1 WHERE id = $2 RETURNING id, name, amount', [
      parseFloat(amount),
      id,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Company not found' });
    }

    const company = result.rows[0];
    res.json({
      id: company.id,
      name: company.name,
      amount: parseFloat(company.amount) || 0,
    });
  } catch (error) {
    console.error('Error updating company:', error.message);
    res.status(500).json({ error: 'Failed to update company' });
  }
}

// GET all orders
async function getAllOrders(req, res) {
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT o.*, c.name AS companyName
      FROM orders o
      LEFT JOIN companies c ON o."companyId" = c.id
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE(o."updatedAt", o."createdAt") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY o."createdAt" DESC';

    const result = await pool.query(query, values);
    res.json(result.rows.map((order) => ({
      id: order.id,
      number: order.number,
      price: order.price ? parseFloat(order.price) : 0,
      discount: order.discount ? parseFloat(order.discount) : 0,
      total: order.total ? parseFloat(order.total) : 0,
      tax: order.tax ? parseFloat(order.tax) : null,
      fairCharges: order.fairCharges ? parseFloat(order.fairCharges) : null,
      customDuties: order.customDuties ? parseFloat(order.customDuties) : null,
      localFair: order.localFair ? parseFloat(order.localFair) : null,
      salesTax: order.salesTax ? parseFloat(order.salesTax) : null,
      officeExpense: order.officeExpense ? parseFloat(order.officeExpense) : null,
      misc: order.misc ? parseFloat(order.misc) : null,
      totalAmount: order.totalAmount ? parseFloat(order.totalAmount) : 0,
      rate: order.rate ? parseFloat(order.rate) : null,
      priceInPKR: order.priceInPKR ? parseFloat(order.priceInPKR) : null,
      status: mapOrderStatusFromEnum(order.status),
      phone: order.phone || '',
      state: order.state || '',
      city: order.city || '',
      note: order.note || '',
      quantity: order.quantity ? parseInt(order.quantity) : 0,
      companyId: order.companyId || null,
      createdAt: order.createdAt ? order.createdAt.toISOString() : null,
      updatedAt: order.updatedAt ? order.updatedAt.toISOString() : null,
      companyName: order.companyName || '',
    })));
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
}

// GET single order
async function getOrderById(req, res) {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT o.*, c.name AS companyName
       FROM orders o
       LEFT JOIN companies c ON o."companyId" = c.id
       WHERE o.id = $1`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Order not found' });
    const order = result.rows[0];
    res.json({
      id: order.id,
      number: order.number,
      price: order.price ? parseFloat(order.price) : 0,
      discount: order.discount ? parseFloat(order.discount) : 0,
      total: order.total ? parseFloat(order.total) : 0,
      tax: order.tax ? parseFloat(order.tax) : null,
      fairCharges: order.fairCharges ? parseFloat(order.fairCharges) : null,
      customDuties: order.customDuties ? parseFloat(order.customDuties) : null,
      localFair: order.localFair ? parseFloat(order.localFair) : null,
      salesTax: order.salesTax ? parseFloat(order.salesTax) : null,
      officeExpense: order.officeExpense ? parseFloat(order.officeExpense) : null,
      misc: order.misc ? parseFloat(order.misc) : null,
      totalAmount: order.totalAmount ? parseFloat(order.totalAmount) : 0,
      rate: order.rate ? parseFloat(order.rate) : null,
      priceInPKR: order.priceInPKR ? parseFloat(order.priceInPKR) : null,
      status: mapOrderStatusFromEnum(order.status),
      phone: order.phone || '',
      state: order.state || '',
      city: order.city || '',
      note: order.note || '',
      quantity: order.quantity ? parseInt(order.quantity) : 0,
      companyId: order.companyId || null,
      createdAt: order.createdAt ? order.createdAt.toISOString() : null,
      updatedAt: order.updatedAt ? order.updatedAt.toISOString() : null,
      companyName: order.companyName || '',
    });
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ error: 'Failed to fetch order' });
  }
}

// CREATE order
async function createOrder(req, res) {
  try {
    const { number, price, discount, tax, fairCharges, customDuties, localFair, salesTax, officeExpense, misc, status, phone, state, quantity, city, note, companyId, rate } = req.body;

    if (!number || !quantity) {
      return res.status(400).json({ error: 'Number and quantity are required' });
    }

    if (companyId) {
      const companyResult = await pool.query('SELECT id FROM companies WHERE id = $1', [companyId]);
      if (companyResult.rows.length === 0) {
        return res.status(400).json({ error: 'Company not found' });
      }
    }

    const total = (quantity * price) - (discount || 0);
    const totalAmount = calculateTotalAmount({ quantity, price, discount, tax, fairCharges, customDuties, localFair, salesTax, officeExpense, misc });
    const priceInPKR = rate ? totalAmount * parseFloat(rate) : null;

    const now = new Date();
    const result = await pool.query(
      `INSERT INTO orders (number, price, discount, total, tax, "fairCharges", "customDuties", "localFair", "salesTax", "officeExpense", misc, "totalAmount", status, phone, state, city, quantity, note, "companyId", "createdAt", "updatedAt", rate, "priceInPKR")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23) RETURNING *`,
      [
        number,
        parseFloat(price),
        parseFloat(discount) || 0,
        total,
        parseFloat(tax) || null,
        parseFloat(fairCharges) || null,
        parseFloat(customDuties) || null,
        parseFloat(localFair) || null,
        parseFloat(salesTax) || null,
        parseFloat(officeExpense) || null,
        parseFloat(misc) || null,
        totalAmount,
        mapOrderStatusToEnum(status || 'Pending'),
        phone || null,
        state || null,
        city || null,
        parseInt(quantity),
        note || null,
        companyId ? companyId : null,
        now,
        now,
        parseFloat(rate) || null,
        priceInPKR,
      ]
    );

    const order = result.rows[0];

    // Update company amount if status is Delivered
    if (mapOrderStatusFromEnum(order.status) === 'Delivered' && order.companyId) {
      await updateCompanyAmount(order.companyId, parseFloat(order.totalAmount));
    }

    res.status(201).json({
      id: order.id,
      number: order.number,
      price: parseFloat(order.price) || 0,
      discount: parseFloat(order.discount) || 0,
      total: parseFloat(order.total) || 0,
      tax: order.tax ? parseFloat(order.tax) : null,
      fairCharges: order.fairCharges ? parseFloat(order.fairCharges) : null,
      customDuties: order.customDuties ? parseFloat(order.customDuties) : null,
      localFair: order.localFair ? parseFloat(order.localFair) : null,
      salesTax: order.salesTax ? parseFloat(order.salesTax) : null,
      officeExpense: order.officeExpense ? parseFloat(order.officeExpense) : null,
      misc: order.misc ? parseFloat(order.misc) : null,
      totalAmount: parseFloat(order.totalAmount) || 0,
      rate: order.rate ? parseFloat(order.rate) : null,
      priceInPKR: order.priceInPKR ? parseFloat(order.priceInPKR) : null,
      status: mapOrderStatusFromEnum(order.status),
      phone: order.phone || '',
      state: order.state || '',
      city: order.city || '',
      note: order.note || '',
      quantity: parseInt(order.quantity) || 0,
      companyId: order.companyId || null,
      createdAt: order.createdAt ? order.createdAt.toISOString() : null,
      updatedAt: order.updatedAt ? order.updatedAt.toISOString() : null,
      companyName: order.companyName || '',
    });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to create order' });
  }
}

// UPDATE order
async function updateOrder(req, res) {
  try {
    const { id } = req.params;
    const { number, price, discount, tax, fairCharges, customDuties, localFair, salesTax, officeExpense, misc, status, phone, state, city, quantity, note, companyId, rate } = req.body;

    const existing = await pool.query('SELECT * FROM orders WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (companyId && companyId !== existing.rows[0].companyId) {
      const companyResult = await pool.query('SELECT id FROM companies WHERE id = $1', [companyId]);
      if (companyResult.rows.length === 0) {
        return res.status(400).json({ error: 'Company not found' });
      }
    }

    const total = (quantity || existing.rows[0].quantity) * (price || existing.rows[0].price) - (discount !== undefined ? discount : existing.rows[0].discount || 0);
    const totalAmount = calculateTotalAmount({
      quantity: quantity || existing.rows[0].quantity,
      price: price || existing.rows[0].price,
      discount: discount !== undefined ? discount : existing.rows[0].discount,
      tax: tax !== undefined ? tax : existing.rows[0].tax,
      fairCharges: fairCharges !== undefined ? fairCharges : existing.rows[0].fairCharges,
      customDuties: customDuties !== undefined ? customDuties : existing.rows[0].customDuties,
      localFair: localFair !== undefined ? localFair : existing.rows[0].localFair,
      salesTax: salesTax !== undefined ? salesTax : existing.rows[0].salesTax,
      officeExpense: officeExpense !== undefined ? officeExpense : existing.rows[0].officeExpense,
      misc: misc !== undefined ? misc : existing.rows[0].misc,
    });
    const priceInPKR = rate !== undefined ? totalAmount * parseFloat(rate) : existing.rows[0].priceInPKR;

    // Handle company amount update based on status change
    const wasDelivered = mapOrderStatusFromEnum(existing.rows[0].status) === 'Delivered';
    const isDelivered = status ? mapOrderStatusFromEnum(mapOrderStatusToEnum(status)) === 'Delivered' : wasDelivered;
    if (existing.rows[0].companyId) {
      if (!wasDelivered && isDelivered) {
        // Status changed to Delivered: add totalAmount
        await updateCompanyAmount(existing.rows[0].companyId, totalAmount);
      } else if (wasDelivered && !isDelivered) {
        // Status changed from Delivered: subtract old totalAmount
        await updateCompanyAmount(existing.rows[0].companyId, -parseFloat(existing.rows[0].totalAmount));
      } else if (wasDelivered && isDelivered && parseFloat(existing.rows[0].totalAmount) !== totalAmount) {
        // Status remains Delivered but totalAmount changed: adjust by difference
        const amountChange = totalAmount - parseFloat(existing.rows[0].totalAmount);
        await updateCompanyAmount(existing.rows[0].companyId, amountChange);
      }
    }

    const now = new Date();
    const result = await pool.query(
      `UPDATE orders SET number = $1, price = $2, discount = $3, total = $4, tax = $5, "fairCharges" = $6, "customDuties" = $7, "localFair" = $8, "salesTax" = $9, "officeExpense" = $10, misc = $11, "totalAmount" = $12, status = $13, phone = $14, state = $15, city = $16, quantity = $17, note = $18, "companyId" = $19, "updatedAt" = $20, rate = $21, "priceInPKR" = $22 WHERE id = $23 RETURNING *`,
      [
        number || existing.rows[0].number,
        price ? parseFloat(price) : existing.rows[0].price,
        discount !== undefined ? parseFloat(discount) : existing.rows[0].discount,
        total,
        tax !== undefined ? parseFloat(tax) : existing.rows[0].tax,
        fairCharges !== undefined ? parseFloat(fairCharges) : existing.rows[0].fairCharges,
        customDuties !== undefined ? parseFloat(customDuties) : existing.rows[0].customDuties,
        localFair !== undefined ? parseFloat(localFair) : existing.rows[0].localFair,
        salesTax !== undefined ? parseFloat(salesTax) : existing.rows[0].salesTax,
        officeExpense !== undefined ? parseFloat(officeExpense) : existing.rows[0].officeExpense,
        misc !== undefined ? parseFloat(misc) : existing.rows[0].misc,
        totalAmount,
        status ? mapOrderStatusToEnum(status) : existing.rows[0].status,
        phone !== undefined ? phone : existing.rows[0].phone,
        state !== undefined ? state : existing.rows[0].state,
        city !== undefined ? city : existing.rows[0].city,
        quantity ? parseInt(quantity) : existing.rows[0].quantity,
        note !== undefined ? note : existing.rows[0].note,
        companyId ? companyId : existing.rows[0].companyId,
        now,
        rate !== undefined ? parseFloat(rate) : existing.rows[0].rate,
        priceInPKR,
        parseInt(id),
      ]
    );

    const order = result.rows[0];
    res.json({
      id: order.id,
      number: order.number,
      price: parseFloat(order.price) || 0,
      discount: parseFloat(order.discount) || 0,
      total: parseFloat(order.total) || 0,
      tax: order.tax ? parseFloat(order.tax) : null,
      fairCharges: order.fairCharges ? parseFloat(order.fairCharges) : null,
      customDuties: order.customDuties ? parseFloat(order.customDuties) : null,
      localFair: order.localFair ? parseFloat(order.localFair) : null,
      salesTax: order.salesTax ? parseFloat(order.salesTax) : null,
      officeExpense: order.officeExpense ? parseFloat(order.officeExpense) : null,
      misc: order.misc ? parseFloat(order.misc) : null,
      totalAmount: parseFloat(order.totalAmount) || 0,
      rate: order.rate ? parseFloat(order.rate) : null,
      priceInPKR: order.priceInPKR ? parseFloat(order.priceInPKR) : null,
      status: mapOrderStatusFromEnum(order.status),
      phone: order.phone || '',
      state: order.state || '',
      city: order.city || '',
      note: order.note || '',
      quantity: parseInt(order.quantity) || 0,
      companyId: order.companyId || null,
      createdAt: order.createdAt ? order.createdAt.toISOString() : null,
      updatedAt: order.updatedAt ? order.updatedAt.toISOString() : null,
      companyName: order.companyName || '',
    });
  } catch (error) {
    console.error('Error updating order:', error);
    res.status(500).json({ error: 'Failed to update order' });
  }
}

// DELETE order
async function deleteOrder(req, res) {
  try {
    const { id } = req.params;

    const existing = await pool.query('SELECT * FROM orders WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }

    // Subtract totalAmount if order status is Delivered
    if (mapOrderStatusFromEnum(existing.rows[0].status) === 'Delivered' && existing.rows[0].companyId) {
      await updateCompanyAmount(existing.rows[0].companyId, -parseFloat(existing.rows[0].totalAmount));
    }

    await pool.query('DELETE FROM orders WHERE id = $1', [parseInt(id)]);
    res.json({ message: 'Order deleted successfully' });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ error: 'Failed to delete order' });
  }
}

// Download orders PDF report
async function downloadOrdersPDF(req, res) {
  let doc;

  try {
    const { dateRange } = req.query;
    let query = `
      SELECT o.*, c.name AS "companyName"
      FROM orders o
      LEFT JOIN companies c ON o."companyId" = c.id
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE(o."updatedAt", o."createdAt") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY o."createdAt" DESC';

    const result = await pool.query(query, values);
    const orders = result.rows;

    doc = new PDFDocument({
      margin: 30,
      size: 'A4',
      layout: 'landscape',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="orders-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    const pageWidth = doc.page.width - 60;
    const pageHeight = doc.page.height - 60;

    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 30, 30, { width: 50 });
      }

      doc
        .fontSize(20)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 100, 35)
        .fontSize(11)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Orders Summary Report', 100, 60)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`, 100, 75);

      doc
        .moveTo(30, 100)
        .lineTo(pageWidth + 30, 100)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    const totalOrders = orders.length;
    const totalValue = orders.reduce((sum, order) => sum + (order.total || 0), 0);
    const totalAmount = orders.reduce((sum, order) => sum + (order.totalAmount || 0), 0);
    const totalTax = orders.reduce((sum, order) => sum + ((order.total || 0) * ((order.tax || 0) / 100)), 0);
    const totalFairCharges = orders.reduce((sum, order) => sum + (order.fairCharges || 0), 0);
    const totalCustomDuties = orders.reduce((sum, order) => sum + (order.customDuties || 0), 0);
    const totalLocalFair = orders.reduce((sum, order) => sum + (order.localFair || 0), 0);
    const totalSalesTax = orders.reduce((sum, order) => sum + (order.salesTax || 0), 0);
    const totalOfficeExpense = orders.reduce((sum, order) => sum + (order.officeExpense || 0), 0);
    const totalMisc = orders.reduce((sum, order) => sum + (order.misc || 0), 0);
    const totalPriceInPKR = orders.reduce((sum, order) => sum + (order.priceInPKR || 0), 0);

    let yPos = 120;

    doc
      .rect(30, yPos, pageWidth, 55)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(12)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 40, yPos + 8)
      .fontSize(10)
      .font('Helvetica')
      .text(`Total Orders: ${totalOrders}`, 40, yPos + 25)
      .text(`Total Base Value: $${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 40, yPos + 40)
      .text(`Total Amount (USD): $${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, yPos + 25)
      .text(`Total Amount (PKR): ${totalPriceInPKR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 280, yPos + 40)
      .text(`Average Amount (USD): $${totalOrders > 0 ? (totalAmount / totalOrders).toFixed(2) : '0.00'}`, 520, yPos + 25);

    yPos += 75;

    doc
      .fontSize(11)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Status Breakdown:', 30, yPos);

    yPos += 20;
    let statusX = 40;
    const statusCounts = orders.reduce((acc, order) => {
      const status = mapOrderStatusFromEnum(order.status).toLowerCase();
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});
    Object.keys(statusCounts).forEach((status, index) => {
      const count = statusCounts[status] || 0;
      const percentage = totalOrders > 0 ? ((count / totalOrders) * 100).toFixed(1) : '0.0';
      const statusText = `${status}: ${count} (${percentage}%)`;
      
      doc
        .fontSize(9)
        .fillColor('#34495e')
        .font('Helvetica')
        .text(statusText, statusX, yPos);

      statusX += 120;
      if ((index + 1) % 6 === 0) {
        statusX = 40;
        yPos += 15;
      }
    });

    yPos += 35;

    const columns = [
      { label: 'Order No', x: 30, width: 50, align: 'left' },
      { label: 'Company', x: 80, width: 70, align: 'left' },
      { label: 'Qty', x: 150, width: 30, align: 'center' },
      { label: 'Price', x: 180, width: 45, align: 'right' },
      { label: 'Disc.', x: 225, width: 40, align: 'right' },
      { label: 'Tax%', x: 265, width: 35, align: 'center' },
      { label: 'Fair', x: 300, width: 40, align: 'right' },
      { label: 'Custom', x: 340, width: 45, align: 'right' },
      { label: 'Local', x: 385, width: 40, align: 'right' },
      { label: 'S.Tax', x: 425, width: 45, align: 'right' },
      { label: 'Office', x: 470, width: 40, align: 'right' },
      { label: 'Misc', x: 510, width: 40, align: 'right' },
      { label: 'Total (USD)', x: 550, width: 50, align: 'right' },
      { label: 'Rate', x: 600, width: 40, align: 'right' },
      { label: 'Total (PKR)', x: 650, width: 100, align: 'left' },
      { label: 'Status', x: 740, width: 50, align: 'center' },
    ];

    const tableWidth = 790;

    const drawTableHeader = () => {
      if (yPos + 25 > pageHeight - 80) {
        doc.addPage();
        yPos = 50;
      }
      
      doc
        .rect(30, yPos, tableWidth, 22)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(9)
        .font('Helvetica-Bold');

      columns.forEach(col => {
        doc.text(col.label, col.x, yPos + 7, { 
          width: col.width, 
          align: col.align 
        });
      });

      yPos += 22;
      return yPos;
    };

    yPos = drawTableHeader();

    for (let i = 0; i < orders.length; i++) {
      const order = orders[i];
      const rowHeight = 18;

      if (yPos + rowHeight > pageHeight - 80) {
        doc.addPage();
        yPos = 50;
        yPos = drawTableHeader();
      }

      const rowColor = i % 2 === 0 ? '#ffffff' : '#f8f9fa';
      doc
        .rect(30, yPos, tableWidth, rowHeight)
        .fill(rowColor);

      doc
        .fillColor('#2c3e50')
        .fontSize(8)
        .font('Helvetica');

      const cellData = [
        order.number || 'N/A',
        order.companyName || 'N/A',
        (order.quantity || 0).toString(),
        `$${Number(order.price || 0).toFixed(2)}`,
        `$${Number(order.discount || 0).toFixed(2)}`,
        order.tax ? `${Number(order.tax).toFixed(1)}%` : 'N/A',
        order.fairCharges ? `$${Number(order.fairCharges).toFixed(2)}` : 'N/A',
        order.customDuties ? `$${Number(order.customDuties).toFixed(2)}` : 'N/A',
        order.localFair ? `$${Number(order.localFair).toFixed(2)}` : 'N/A',
        order.salesTax ? `$${Number(order.salesTax).toFixed(2)}` : 'N/A',
        order.officeExpense ? `$${Number(order.officeExpense).toFixed(2)}` : 'N/A',
        order.misc ? `$${Number(order.misc).toFixed(2)}` : 'N/A',
        `$${Number(order.totalAmount || 0).toFixed(2)}`,
        order.rate ? Number(order.rate).toFixed(2) : 'N/A',
        order.priceInPKR ? `${Number(order.priceInPKR).toFixed(2)}` : 'N/A',
        mapOrderStatusFromEnum(order.status).toLowerCase(),
      ];

      columns.forEach((col, index) => {
        if (index === columns.length - 1) {
          const status = cellData[index];
          let statusColor = '#2c3e50';
          if (status === 'delivered') statusColor = '#27ae60';
          else if (status === 'cancelled') statusColor = '#e74c3c';
          else if (status.includes('pending') || status.includes('confirmed') || status.includes('shipped')) statusColor = '#f39c12';
          doc.fillColor(statusColor);
        } else {
          doc.fillColor('#2c3e50');
        }

        doc.text(cellData[index], col.x, yPos + 6, { 
          width: col.width, 
          align: col.align,
          ellipsis: true
        });
      });

      yPos += rowHeight;
    }

    if (yPos + 120 > pageHeight - 80) {
      doc.addPage();
      yPos = 50;
    }

    yPos += 20;

    doc
      .rect(30, yPos, pageWidth, 90)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(12)
      .font('Helvetica-Bold')
      .text('Financial Summary', 40, yPos + 8);

    doc
      .fontSize(9)
      .font('Helvetica')
      .text(`Total Base Value: $${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 40, yPos + 25)
      .text(`Total Tax Amount: $${totalTax.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 40, yPos + 40)
      .text(`Total Fair Charges: $${totalFairCharges.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 40, yPos + 55)
      .text(`Total Custom Duties: $${totalCustomDuties.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 40, yPos + 70)
      .text(`Total Local Fair: $${totalLocalFair.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, yPos + 25)
      .text(`Total Sales Tax: $${totalSalesTax.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, yPos + 40)
      .text(`Total Office Expense: $${totalOfficeExpense.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, yPos + 55)
      .text(`Total Miscellaneous: $${totalMisc.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 280, yPos + 70)
      .text(`Total Amount (PKR): ${totalPriceInPKR.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 520, yPos + 25);

    doc
      .fontSize(11)
      .font('Helvetica-Bold')
      .fillColor('#e74c3c')
      .text(`GRAND TOTAL (USD): $${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2 })}`, 520, yPos + 45);

    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      const footerY = pageHeight + 20;
      
      doc
        .fontSize(8)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating orders PDF:', { error: error.message, stack: error.stack });

    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate orders PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
}

// Download single order PDF report
async function downloadOrdersPDFbyID(req, res) {
  let doc;

  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT o.*, c.name AS "companyName"
       FROM orders o
       LEFT JOIN companies c ON o."companyId" = c.id
       WHERE o.id = $1`,
      [parseInt(id)]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    const order = result.rows[0];

    doc = new PDFDocument({
      margin: 30,
      size: 'A4',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="order-${order.number}.pdf"`);

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    const pageWidth = doc.page.width - 60;

    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 30, 30, { width: 50 });
      }

      doc
        .fontSize(20)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 100, 35)
        .fontSize(11)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Order Details Report', 100, 60)
        .text(`Order Number: ${order.number}`, 100, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}`, 100, 90);

      doc
        .moveTo(30, 110)
        .lineTo(pageWidth + 30, 110)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    let yPos = 130;

    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Order Details', 30, yPos);

    yPos += 20;

    const fields = [
      { label: 'Order Number', value: order.number || 'N/A' },
      { label: 'Company', value: order.companyName || 'N/A' },
      { label: 'Quantity', value: (order.quantity || 0).toString() },
      { label: 'Price', value: `$${Number(order.price || 0).toFixed(2)}` },
      { label: 'Discount', value: `$${Number(order.discount || 0).toFixed(2)}` },
      { label: 'Tax (%)', value: order.tax ? `${Number(order.tax).toFixed(1)}%` : 'N/A' },
      { label: 'Fair Charges', value: order.fairCharges ? `$${Number(order.fairCharges).toFixed(2)}` : 'N/A' },
      { label: 'Custom Duties', value: order.customDuties ? `$${Number(order.customDuties).toFixed(2)}` : 'N/A' },
      { label: 'Local Fair', value: order.localFair ? `$${Number(order.localFair).toFixed(2)}` : 'N/A' },
      { label: 'Sales Tax', value: order.salesTax ? `$${Number(order.salesTax).toFixed(2)}` : 'N/A' },
      { label: 'Office Expense', value: order.officeExpense ? `$${Number(order.officeExpense).toFixed(2)}` : 'N/A' },
      { label: 'Miscellaneous', value: order.misc ? `$${Number(order.misc).toFixed(2)}` : 'N/A' },
      { label: 'Total (USD)', value: `$${Number(order.totalAmount || 0).toFixed(2)}` },
      { label: 'Rate (PKR/USD)', value: order.rate ? Number(order.rate).toFixed(2) : 'N/A' },
      { label: 'Total (PKR)', value: order.priceInPKR ? `${Number(order.priceInPKR).toFixed(2)}` : 'N/A' },
      { label: 'Status', value: mapOrderStatusFromEnum(order.status) },
      { label: 'Phone', value: order.phone || 'N/A' },
      { label: 'State', value: order.state || 'N/A' },
      { label: 'City', value: order.city || 'N/A' },
      { label: 'Note', value: order.note || 'N/A' },
      { label: 'Created At', value: order.createdAt ? new Date(order.createdAt).toLocaleString() : 'N/A' },
      { label: 'Updated At', value: order.updatedAt ? new Date(order.updatedAt).toLocaleString() : 'N/A' },
    ];

    fields.forEach((field, index) => {
      if (yPos + 20 > doc.page.height - 80) {
        doc.addPage();
        yPos = 50;
        drawHeader();
        yPos += 20;
      }

      doc
        .fontSize(10)
        .font('Helvetica-Bold')
        .fillColor('#2c3e50')
        .text(field.label, 30, yPos, { width: 150 })
        .font('Helvetica')
        .fillColor('#34495e')
        .text(field.value, 180, yPos, { width: pageWidth - 150 });

      yPos += 20;
    });

    const addFooter = () => {
      const footerY = doc.page.height - 40;
      doc
        .fontSize(8)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    addFooter();
    doc.end();
  } catch (error) {
    console.error('Error generating order PDF:', { error: error.message, stack: error.stack });

    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate order PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }

    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
}

module.exports = {
  getAllOrders,
  getOrderById,
  createOrder,
  updateOrder,
  deleteOrder,
  updateCompany,
  downloadOrdersPDF,
  downloadOrdersPDFbyID,
};