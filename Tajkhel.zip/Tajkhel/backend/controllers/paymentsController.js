const express = require('express');
const router = express.Router();
const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Payment Mode Mappers
const mapPaymentModeToEnum = (paymentMode) => {
  const paymentModeMap = {
    'Cash': 'CASH',
    'Credit Card': 'CREDIT_CARD',
    'Bank Transfer': 'BANK_TRANSFER',
    'Digital Wallet': 'DIGITAL_WALLET',
    'Cheque': 'CHEQUE',
    'Wire Transfer': 'WIRE_TRANSFER',
  };
  return paymentModeMap[paymentMode] || 'CASH';
};

const mapPaymentModeFromEnum = (paymentMode) => {
  const paymentModeMap = {
    'CASH': 'Cash',
    'CREDIT_CARD': 'Credit Card',
    'BANK_TRANSFER': 'Bank Transfer',
    'DIGITAL_WALLET': 'Digital Wallet',
    'CHEQUE': 'Cheque',
    'WIRE_TRANSFER': 'Wire Transfer',
  };
  return paymentModeMap[paymentMode] || 'Cash';
};

// Payment Status Mappers
const mapPaymentStatusToEnum = (status) => {
  const statusMap = {
    'Received': 'RECEIVED',
    'Pending': 'PENDING',
    'Processing': 'PROCESSING',
    'Completed': 'COMPLETED',
    'Failed': 'FAILED',
    'Refunded': 'REFUNDED',
  };
  return statusMap[status] || 'RECEIVED';
};

const mapPaymentStatusFromEnum = (status) => {
  const statusMap = {
    'RECEIVED': 'Received',
    'PENDING': 'Pending',
    'PROCESSING': 'Processing',
    'COMPLETED': 'Completed',
    'FAILED': 'Failed',
    'REFUNDED': 'Refunded',
  };
  return statusMap[status] || 'Received';
};

// GET /api/payments - Get all payments
const getAllPayments = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT p.*, c.name AS customer_name
      FROM payments p
      JOIN customers c ON p.customer_id = c.id
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE p.created_at >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY p.created_at DESC';

    const result = await pool.query(query, values);
    const transformedPayments = result.rows.map((payment) => ({
      id: payment.id,
      customerId: payment.customer_id,
      customerName: payment.customer_name || 'N/A',
      amount: parseFloat(payment.amount) || 0,
      date: payment.date ? new Date(payment.date).toISOString().split('T')[0] : null,
      transactionDate: payment.transaction_date ? new Date(payment.transaction_date).toISOString().split('T')[0] : null,
      paymentMode: mapPaymentModeFromEnum(payment.payment_method),
      paymentTransaction: payment.payment_transaction || '',
      status: mapPaymentStatusFromEnum(payment.status),
      notes: payment.notes || '',
      createdBy: 'Admin',
      companyId: null,
      createdAt: payment.created_at ? payment.created_at.toISOString() : null,
    }));

    res.json({ data: transformedPayments, pagination: { total: transformedPayments.length } });
  } catch (error) {
    console.error('Error fetching payments:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch payments', details: error.message });
  }
};

// GET /api/payments/:id - Get payment by ID
const getPayment = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT p.*, c.name AS customer_name
      FROM payments p
      JOIN customers c ON p.customer_id = c.id
      WHERE p.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    const payment = result.rows[0];
    const transformedPayment = {
      id: payment.id,
      customerId: payment.customer_id,
      customerName: payment.customer_name || 'N/A',
      amount: Number(payment.amount) || 0,
      date: payment.date ? payment.date.toISOString().split('T')[0] : '',
      transactionDate: payment.transaction_date ? payment.transaction_date.toISOString().split('T')[0] : '',
      paymentMode: mapPaymentModeFromEnum(payment.payment_method),
      paymentTransaction: payment.payment_transaction || '',
      status: mapPaymentStatusFromEnum(payment.status),
      notes: payment.notes || '',
      createdBy: 'Admin',
      companyId: null,
      createdAt: payment.created_at ? payment.created_at.toISOString() : '',
      updatedAt: payment.updated_at ? payment.updated_at.toISOString() : '',
    };

    res.json(transformedPayment);
  } catch (error) {
    console.error('Error fetching payment:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch payment', details: error.message });
  }
};

// POST /api/payments - Create a new payment
const createPayment = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const {
      customerId,
      customerName,
      amount,
      date,
      transactionDate,
      paymentMode,
      paymentTransaction,
      status,
      notes,
    } = req.body;

    // Backend validation: Ensure all required fields are present
    if (!customerId || !customerName || !amount || !date || !transactionDate || !paymentMode || !status) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'All required payment fields must be provided.' });
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Amount must be a valid number greater than 0.' });
    }

    const validStatuses = ['RECEIVED', 'PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED'];
    const validPaymentModes = ['CASH', 'CREDIT_CARD', 'BANK_TRANSFER', 'DIGITAL_WALLET', 'CHEQUE', 'WIRE_TRANSFER'];
    const mappedStatus = mapPaymentStatusToEnum(status);
    const mappedPaymentMode = mapPaymentModeToEnum(paymentMode);

    if (!validStatuses.includes(mappedStatus)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid status value.' });
    }
    if (!validPaymentModes.includes(mappedPaymentMode)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid payment mode value.' });
    }

    // Validate customerId and customerName
    const customerResult = await client.query('SELECT amount, name FROM customers WHERE id = $1', [customerId]);
    if (customerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid customer ID.' });
    }
    const storedCustomerName = customerResult.rows[0].name;
    if (customerName !== storedCustomerName) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Provided customer name does not match the stored customer name.' });
    }

    // Update customer balance and name if status is COMPLETED
    if (mappedStatus === 'COMPLETED') {
      const customer = customerResult.rows[0];
      const newCustomerAmount = parseFloat(customer.amount) - parsedAmount;
      if (newCustomerAmount < 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Insufficient customer balance.' });
      }
      await client.query('UPDATE customers SET amount = $1, name = $2, updated_at = $3 WHERE id = $4', [
        newCustomerAmount,
        customerName,
        new Date(),
        customerId,
      ]);
    }

    const parsedDate = new Date(date);
    const parsedTransactionDate = new Date(transactionDate);

    const result = await client.query(
      `INSERT INTO payments (
        id, customer_id, amount, date, transaction_date, payment_method, payment_transaction,
        status, notes, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [
        crypto.randomUUID(),
        customerId,
        parsedAmount,
        parsedDate,
        parsedTransactionDate,
        mappedPaymentMode,
        paymentTransaction || null,
        mappedStatus,
        notes || null,
        new Date(),
        new Date(),
      ]
    );

    await client.query('COMMIT');

    const payment = result.rows[0];
    res.status(201).json({
      id: payment.id,
      customerId: payment.customer_id,
      customerName: customerName,
      amount: parseFloat(payment.amount),
      date: payment.date.toISOString().split('T')[0],
      transactionDate: payment.transaction_date.toISOString().split('T')[0],
      paymentMode: mapPaymentModeFromEnum(payment.payment_method),
      paymentTransaction: payment.payment_transaction || '',
      status: mapPaymentStatusFromEnum(payment.status),
      notes: payment.notes || '',
      createdBy: 'Admin',
      companyId: null,
      createdAt: payment.created_at.toISOString(),
      updatedAt: payment.updated_at.toISOString(),
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating payment:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to create payment', details: error.message });
  } finally {
    client.release();
  }
};

// PUT /api/payments/:id - Update a payment
const updatePayment = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { id } = req.params;
    const {
      customerId,
      customerName,
      amount,
      date,
      transactionDate,
      paymentMode,
      paymentTransaction,
      status,
      notes,
    } = req.body;

    // Backend validation: Ensure all required fields are present
    if (!customerId || !customerName || !amount || !date || !transactionDate || !paymentMode || !status) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'All required payment fields, including customer name, must be provided.' });
    }

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Amount must be a valid number greater than 0.' });
    }

    const validStatuses = ['RECEIVED', 'PENDING', 'PROCESSING', 'COMPLETED', 'FAILED', 'REFUNDED'];
    const validPaymentModes = ['CASH', 'CREDIT_CARD', 'BANK_TRANSFER', 'DIGITAL_WALLET', 'CHEQUE', 'WIRE_TRANSFER'];
    const mappedStatus = mapPaymentStatusToEnum(status);
    const mappedPaymentMode = mapPaymentModeToEnum(paymentMode);

    if (!validStatuses.includes(mappedStatus)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid status value.' });
    }
    if (!validPaymentModes.includes(mappedPaymentMode)) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid payment mode value.' });
    }

    // Validate customerId and customerName
    const customerResult = await client.query('SELECT amount, name FROM customers WHERE id = $1', [customerId]);
    if (customerResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Invalid customer ID.' });
    }
    const storedCustomerName = customerResult.rows[0].name;
    if (customerName !== storedCustomerName) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Provided customer name does not match the stored customer name.' });
    }

    // Get original payment for balance adjustments
    const originalPaymentResult = await client.query('SELECT customer_id, amount, status FROM payments WHERE id = $1', [id]);
    if (originalPaymentResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Payment not found' });
    }
    const originalPayment = originalPaymentResult.rows[0];

    // Handle customer balance and name updates
    const customer = customerResult.rows[0];
    let newCustomerAmount = parseFloat(customer.amount);

    if (originalPayment.status === 'COMPLETED' && mappedStatus !== 'COMPLETED') {
      // Reverse deduction
      newCustomerAmount += parseFloat(originalPayment.amount);
      await client.query('UPDATE customers SET amount = $1, name = $2, updated_at = $3 WHERE id = $4', [
        newCustomerAmount,
        customerName,
        new Date(),
        originalPayment.customer_id,
      ]);
    } else if (originalPayment.status === 'COMPLETED' && mappedStatus === 'COMPLETED') {
      // Adjust for amount difference in Completed status
      const amountDifference = parseFloat(originalPayment.amount) - parsedAmount;
      newCustomerAmount += amountDifference;
      if (newCustomerAmount < 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Insufficient customer balance after amount adjustment.' });
      }
      await client.query('UPDATE customers SET amount = $1, name = $2, updated_at = $3 WHERE id = $4', [
        newCustomerAmount,
        customerName,
        new Date(),
        customerId,
      ]);
    } else if (mappedStatus === 'COMPLETED') {
      // Deduct new amount
      newCustomerAmount -= parsedAmount;
      if (newCustomerAmount < 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Insufficient customer balance.' });
      }
      await client.query('UPDATE customers SET amount = $1, name = $2, updated_at = $3 WHERE id = $4', [
        newCustomerAmount,
        customerName,
        new Date(),
        customerId,
      ]);
    }

    const parsedDate = new Date(date);
    const parsedTransactionDate = new Date(transactionDate);

    const result = await client.query(
      `UPDATE payments SET
        customer_id = $1,
        amount = $2,
        date = $3,
        transaction_date = $4,
        payment_method = $5,
        payment_transaction = $6,
        status = $7,
        notes = $8,
        updated_at = $9
      WHERE id = $10 RETURNING *`,
      [
        customerId,
        parsedAmount,
        parsedDate,
        parsedTransactionDate,
        mappedPaymentMode,
        paymentTransaction || null,
        mappedStatus,
        notes || null,
        new Date(),
        id,
      ]
    );

    await client.query('COMMIT');

    const payment = result.rows[0];
    res.json({
      id: payment.id,
      customerId: payment.customer_id,
      customerName: customerName,
      amount: parseFloat(payment.amount),
      date: payment.date.toISOString().split('T')[0],
      transactionDate: payment.transaction_date.toISOString().split('T')[0],
      paymentMode: mapPaymentModeFromEnum(payment.payment_method),
      paymentTransaction: payment.payment_transaction || '',
      status: mapPaymentStatusFromEnum(payment.status),
      notes: payment.notes || '',
      createdBy: 'Admin',
      companyId: null,
      createdAt: payment.created_at.toISOString(),
      updatedAt: payment.updated_at.toISOString(),
    });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error updating payment:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to update payment', details: error.message });
  } finally {
    client.release();
  }
};

// DELETE /api/payments/:id - Delete a payment
const deletePayment = async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const { id } = req.params;
    const paymentResult = await client.query('SELECT customer_id, amount, status FROM payments WHERE id = $1', [id]);
    if (paymentResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Payment not found' });
    }

    const payment = paymentResult.rows[0];
    if (payment.status === 'COMPLETED') {
      const customerResult = await client.query('SELECT amount, name FROM customers WHERE id = $1', [payment.customer_id]);
      if (customerResult.rows.length > 0) {
        const newCustomerAmount = parseFloat(customerResult.rows[0].amount) + parseFloat(payment.amount);
        await client.query('UPDATE customers SET amount = $1, name = $2, updated_at = $3 WHERE id = $4', [
          newCustomerAmount,
          customerResult.rows[0].name,
          new Date(),
          payment.customer_id,
        ]);
      }
    }

    await client.query('DELETE FROM payments WHERE id = $1', [id]);
    await client.query('COMMIT');

    res.json({ message: 'Payment deleted successfully' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error deleting payment:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to delete payment', details: error.message });
  } finally {
    client.release();
  }
};

// GET /api/payments/total - Get total received amount
const getTotalReceived = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT SUM(amount) as total_received
      FROM payments
      WHERE status IN ('RECEIVED', 'COMPLETED')
    `);
    
    const total = parseFloat(result.rows[0].total_received) || 0;
    res.json({ totalReceived: total });
  } catch (error) {
    console.error('Error fetching total received:', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch total received', details: error.message });
  }
};

// GET /api/payments/pdf - Download payments PDF
const downloadPaymentsPDF = async (req, res) => {
  let doc;

  try {
    const result = await pool.query(`
      SELECT 
        c.name AS customer_name,
        p.amount,
        p.date,
        p.created_at,
        p.payment_method,
        p.status
      FROM payments p
      JOIN customers c ON p.customer_id = c.id
      ORDER BY p.created_at DESC
    `);

    doc = new PDFDocument({ 
      margin: 40,
      size: 'A4',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="payments-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === HEADER SECTION ===
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Payments Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`, 120, 90);

      doc
        .moveTo(40, 120)
        .lineTo(555, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalPayments = result.rows.length;
    const totalAmount = result.rows.reduce(
      (sum, payment) => sum + (parseFloat(payment.amount) || 0),
      0
    );

    const statusCounts = result.rows.reduce((acc, payment) => {
      const status = mapPaymentStatusFromEnum(payment.status).toLowerCase();
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    let yPos = 140;
    
    doc
      .rect(40, yPos, 515, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Payments: ${totalPayments}`, 50, yPos + 30)
      .text(`Total Amount: RS ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 50, yPos + 45)
      .text(`Average Amount: RS ${totalPayments > 0 ? (totalAmount / totalPayments).toFixed(2) : '0.00'}`, 300, yPos + 30)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 300, yPos + 45);

    yPos += 80;

    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Status Breakdown:', 40, yPos);
    
    yPos += 25;
    let statusX = 50;
    let statusY = yPos;
    
    Object.keys(statusCounts).forEach((status, index) => {
      const count = statusCounts[status] || 0;
      const percentage = totalPayments > 0 ? ((count / totalPayments) * 100).toFixed(1) : '0.0';
      
      const statusText = `${status}: ${count} (${percentage}%)`;
      const statusHeight = doc
        .fontSize(10)
        .font('Helvetica')
        .heightOfString(statusText, { width: 110 });
      
      if (statusY + statusHeight > 680) {
        doc.addPage();
        statusY = 60;
        statusX = 50;
      }

      doc
        .fontSize(10)
        .fillColor('#34495e')
        .font('Helvetica')
        .text(statusText, statusX, statusY);
      
      statusX += 120;
      if ((index + 1) % 4 === 0) {
        statusX = 50;
        statusY += statusHeight + 8;
      }
    });

    yPos = statusY + 40;

    // === TABLE HEADER ===
    const drawTableHeader = () => {
      if (yPos + 25 > 680) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 515, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');
      
      doc.text('Customer', 50, yPos + 8);
      doc.text('Method', 170, yPos + 8);
      doc.text('Status', 250, yPos + 8);
      doc.text('Date', 330, yPos + 8);
      doc.text('Amount (RS)', 410, yPos + 8);
      
      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS ===
    result.rows.forEach((payment, index) => {
      const customerName = payment.customer_name || 'N/A';
      const paymentMethod = mapPaymentModeFromEnum(payment.payment_method) || 'N/A';
      const customerHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(customerName, { width: 110 });
      const methodHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(paymentMethod, { width: 70 });
      const rowHeight = Math.max(20, customerHeight + 10, methodHeight + 10);

      if (yPos + rowHeight > 680) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 515, rowHeight)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(9)
        .font('Helvetica');

      doc.text(customerName, 50, yPos + 6, { width: 110 });
      doc.text(paymentMethod, 170, yPos + 6, { width: 70 });
      
      const status = mapPaymentStatusFromEnum(payment.status).toLowerCase();
      let statusColor = '#2c3e50';
      if (status === 'completed' || status === 'received') statusColor = '#27ae60';
      else if (status === 'failed' || status === 'refunded') statusColor = '#e74c3c';
      else if (status === 'pending' || status === 'processing') statusColor = '#f39c12';
      
      doc.fillColor(statusColor).text(status, 250, yPos + 6);
      
      doc
        .fillColor('#2c3e50')
        .text(
          payment.date ? 
          new Date(payment.date).toLocaleDateString('en-US', { 
            month: 'short', 
            day: '2-digit', 
            year: '2-digit' 
          }) : 'N/A', 
          330, yPos + 6
        )
        .text(
          `RS ${(parseFloat(payment.amount) || 0).toLocaleString('en-US', { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
          })}`, 
          410, yPos + 6, 
          { width: 70, align: 'right' }
        );

      yPos += rowHeight;
    });

    if (yPos + 110 > 680) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;
    
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
       .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating payments PDF:', { error: error.message, stack: error.stack });
    
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate payments PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

module.exports = {
  getAllPayments,
  getPayment,
  createPayment,
  updatePayment,
  deletePayment,
  getTotalReceived,
  downloadPaymentsPDF,
};