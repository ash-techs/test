
const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// GET all customers
const getAllCustomers = async (req, res) => {
  try {
    const { search, dateRange } = req.query;
    let query = `
      SELECT c.*
      FROM customers c
    `;
    const values = [];

    if (search || dateRange) {
      query += ' WHERE';
      let conditions = [];

      if (search) {
        conditions.push('c.name ILIKE $1 OR c.phone ILIKE $1');
        values.push(`%${search}%`);
      }

      if (dateRange) {
        let days;
        switch (dateRange) {
          case '7d':
            days = 7;
            break;
          case '14d':
            days = 14;
            break;
          case '30d':
            days = 30;
            break;
          default:
            days = 7;
        }
        const index = values.length + 1;
        conditions.push(`COALESCE(c."updated_at", c."created_at") >= CURRENT_DATE - INTERVAL $${index}`);
        values.push(`${days} days`);
      }

      query += ' ' + conditions.join(' AND ');
    }
    query += ' ORDER BY c.name ASC';

    const result = await pool.query(query, values);

    const transformedCustomers = result.rows.map(customer => ({
      id: customer.id,
      name: customer.name,
      phone: customer.phone || '',
      address: customer.address || '',
      amount: parseFloat(customer.amount) || 0,
      created_at: customer.created_at ? customer.created_at.toISOString() : null,
      updated_at: customer.updated_at ? customer.updated_at.toISOString() : null,
    }));

    res.json(transformedCustomers);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
};

// GET customer by ID
const getCustomerById = async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid customer ID' });
    }

    const result = await pool.query(
      `SELECT c.* 
       FROM customers c 
       WHERE c.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const customer = result.rows[0];
    res.json({
      id: customer.id,
      name: customer.name,
      phone: customer.phone || '',
      address: customer.address || '',
      amount: parseFloat(customer.amount) || 0,
      created_at: customer.created_at ? customer.created_at.toISOString() : null,
      updated_at: customer.updated_at ? customer.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error fetching customer:', error);
    res.status(500).json({ error: 'Failed to fetch customer' });
  }
};

// CREATE new customer
const createCustomer = async (req, res) => {
  try {
    const { name, phone, address, amount } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    if (amount === undefined || amount < 0) {
      return res.status(400).json({ error: 'Initial amount must be a non-negative number' });
    }

    const now = new Date();
    const result = await pool.query(
      `INSERT INTO customers (name, phone, address, amount, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [name, phone || null, address || null, amount || 0, now, now]
    );

    const customer = result.rows[0];
    res.status(201).json({
      id: customer.id,
      name: customer.name,
      phone: customer.phone || '',
      address: customer.address || '',
      amount: parseFloat(customer.amount) || 0,
      created_at: customer.created_at ? customer.created_at.toISOString() : null,
      updated_at: customer.updated_at ? customer.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error creating customer:', error);
    res.status(500).json({ error: 'Failed to create customer' });
  }
};

// UPDATE customer
const updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, phone, address, amount } = req.body;

    const existing = await pool.query('SELECT * FROM customers WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    if (amount === undefined || amount < 0) {
      return res.status(400).json({ error: 'Amount must be a non-negative number' });
    }

    const updated_data = {
      name: name || existing.rows[0].name,
      phone: phone !== undefined ? phone : existing.rows[0].phone,
      address: address !== undefined ? address : existing.rows[0].address,
      amount: amount !== undefined ? amount : parseFloat(existing.rows[0].amount) || 0,
    };

    const now = new Date();
    const result = await pool.query(
      `UPDATE customers SET name = $1, phone = $2, address = $3, amount = $4, updated_at = $5 WHERE id = $6 RETURNING *`,
      [
        updated_data.name,
        updated_data.phone || null,
        updated_data.address || null,
        updated_data.amount,
        now,
        parseInt(id),
      ]
    );

    const customer = result.rows[0];
    res.json({
      id: customer.id,
      name: customer.name,
      phone: customer.phone || '',
      address: customer.address || '',
      amount: parseFloat(customer.amount) || 0,
      created_at: customer.created_at ? customer.created_at.toISOString() : null,
      updated_at: customer.updated_at ? customer.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error updating customer:', error);
    res.status(500).json({ error: 'Failed to update customer' });
  }
};

// DELETE customer
const deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;

    const existing = await pool.query('SELECT * FROM customers WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    

    await pool.query('DELETE FROM customers WHERE id = $1', [parseInt(id)]);
    res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    console.error('Error deleting customer:', error);
    res.status(500).json({ error: 'Failed to delete customer' });
  }
};
const downloadCustomersPDF = async (req, res) => {
  let doc;

  try {
    const result = await pool.query(`
      SELECT 
        c.id,
        c.name,
        c.phone,
        c.address,
        c.amount,
        c.created_at,
        c.updated_at
      FROM customers c
      ORDER BY c.name ASC
    `);

    doc = new PDFDocument({ 
      margin: 40,
      size: 'A4',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="customers-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === HEADER SECTION ===
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Customers Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`, 120, 90);

      doc
        .moveTo(40, 120)
        .lineTo(555, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalCustomers = result.rows.length;
    const totalAmount = result.rows.reduce(
      (sum, customer) => sum + (parseFloat(customer.amount) || 0),
      0
    );

    let yPos = 140;
    
    doc
      .rect(40, yPos, 515, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Customers: ${totalCustomers}`, 50, yPos + 30)
      .text(`Total Amount: RS ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 50, yPos + 45)
      .text(`Average Amount: RS ${totalCustomers > 0 ? (totalAmount / totalCustomers).toFixed(2) : '0.00'}`, 300, yPos + 30)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 300, yPos + 45);

    yPos += 80;

    // === TABLE HEADER ===
    const drawTableHeader = () => {
      if (yPos + 25 > 680) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 515, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');
      
      doc.text('Customer Name', 50, yPos + 8);
      doc.text('Phone', 170, yPos + 8);
      doc.text('Address', 250, yPos + 8);
      doc.text('Created Date', 390, yPos + 8);
      doc.text('Amount (RS)', 480, yPos + 8);
      
      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS ===
    result.rows.forEach((customer, index) => {
      const customerName = customer.name || 'N/A';
      const phone = customer.phone || 'N/A';
      const address = customer.address || 'N/A';
      const customerHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(customerName, { width: 110 });
      const addressHeight = doc
        .fontSize(9)
        .font('Helvetica')
        .heightOfString(address, { width: 130 });
      const rowHeight = Math.max(20, customerHeight + 10, addressHeight + 10);

      if (yPos + rowHeight > 680) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 515, rowHeight)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(9)
        .font('Helvetica');

      doc.text(customerName, 50, yPos + 6, { width: 110 });
      doc.text(phone, 170, yPos + 6, { width: 70 });
      doc.text(address, 250, yPos + 6, { width: 130 });
      
      doc.text(
        customer.created_at ? 
        new Date(customer.created_at).toLocaleDateString('en-US', { 
          month: 'short', 
          day: '2-digit', 
          year: '2-digit' 
        }) : 'N/A', 
        390, yPos + 6
      );

      doc.text(
        `RS ${(parseFloat(customer.amount) || 0).toLocaleString('en-US', { 
          minimumFractionDigits: 2, 
          maximumFractionDigits: 2 
        })}`, 
        480, yPos + 6, 
        { width: 70, align: 'left' }
      );

      yPos += rowHeight;
    });

    if (yPos + 110 > 680) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;
    
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
          'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
          40, 750, { align: 'center', width: 515 }
        );
    };

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating customers PDF:', { error: error.message, stack: error.stack });
    
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate customers PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

module.exports = {
  getAllCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  downloadCustomersPDF,
};
