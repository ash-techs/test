const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Validation function for inventory input
const validateInventoryInput = (data) => {
  const errors = [];

  if (!data.item || typeof data.item !== 'string') {
    errors.push('Item is required and must be a string');
  }
  if (data.quantity === undefined || isNaN(parseFloat(data.quantity)) || parseFloat(data.quantity) < 0) {
    errors.push('Quantity must be a valid non-negative number');
  }
  if (data.itemType && typeof data.itemType !== 'string') {
    errors.push('Item type must be a string');
  }
  if (!data.vendor || typeof data.vendor !== 'string') {
    errors.push('Vendor is required and must be a string');
  }
  if (data.unitPrice === undefined || isNaN(parseFloat(data.unitPrice)) || parseFloat(data.unitPrice) < 0) {
    errors.push('Unit price must be a valid non-negative number');
  }

  return errors;
};

// GET all inventory items
const getAllInventory = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = 'SELECT * FROM inventory';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY id ASC';

    const inventoryResult = await pool.query(query, values);

    const transformedInventory = inventoryResult.rows.map((item) => ({
      id: item.id,
      item: item.item,
      quantity: item.quantity,
      itemType: item.type || 'N/A',
      vendor: item.vendor,
      unitPrice: parseFloat(item.unitprice) || 0,
      description: item.description || '',
      created_at: item.created_at ? item.created_at.toISOString() : null,
      updated_at: item.updated_at ? item.updated_at.toISOString() : null,
    }));

    res.json(transformedInventory);
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'Failed to fetch inventory', details: error.message });
  }
};

// GET single inventory item
const getInventoryById = async (req, res) => {
  try {
    const { id } = req.params;
    const inventoryResult = await pool.query('SELECT * FROM inventory WHERE id = $1', [parseInt(id)]);
    if (inventoryResult.rows.length === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }

    const item = inventoryResult.rows[0];
    res.json({
      id: item.id,
      item: item.item,
      quantity: item.quantity,
      itemType: item.type || 'N/A',
      vendor: item.vendor,
      unitPrice: parseFloat(item.unitprice) || 0,
      description: item.description || '',
      created_at: item.created_at ? item.created_at.toISOString() : null,
      updated_at: item.updated_at ? item.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error fetching inventory item:', error);
    res.status(500).json({ error: 'Failed to fetch inventory item', details: error.message });
  }
};

// CREATE new inventory item
const createInventory = async (req, res) => {
  try {
    const { item, quantity, itemType, vendor, unitPrice, description } = req.body;

    const errors = validateInventoryInput(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }

    const existingItem = await pool.query('SELECT * FROM inventory WHERE item = $1 AND vendor = $2', [item, vendor]);
    if (existingItem.rows.length > 0) {
      return res.status(400).json({ error: 'Item with this vendor already exists' });
    }

    const now = new Date();
    const result = await pool.query(
      `INSERT INTO inventory (item, quantity, type, vendor, unitprice, description, "created_at", "updated_at")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [item, parseFloat(quantity), itemType || null, vendor, parseFloat(unitPrice), description || null, now, now]
    );

    const newItem = result.rows[0];
    res.status(201).json({
      id: newItem.id,
      item: newItem.item,
      quantity: newItem.quantity,
      itemType: newItem.type || 'N/A',
      vendor: newItem.vendor,
      unitPrice: parseFloat(newItem.unitprice) || 0,
      description: newItem.description || '',
      created_at: newItem.created_at ? newItem.created_at.toISOString() : null,
      updated_at: newItem.updated_at ? newItem.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error creating inventory item:', error);
    res.status(500).json({ error: 'Failed to create inventory item', details: error.message });
  }
};

// UPDATE inventory item
const updateInventory = async (req, res) => {
  try {
    const { id } = req.params;
    const { item, quantity, itemType, vendor, unitPrice, description } = req.body;

    const errors = validateInventoryInput(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }

    const existingItem = await pool.query('SELECT * FROM inventory WHERE id = $1', [parseInt(id)]);
    if (existingItem.rows.length === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }

    const now = new Date();
    const result = await pool.query(
      `UPDATE inventory SET item = $1, quantity = $2, type = $3, vendor = $4, unitprice = $5, description = $6, "updated_at" = $7 WHERE id = $8 RETURNING *`,
      [item, parseFloat(quantity), itemType || null, vendor, parseFloat(unitPrice), description || null, now, parseInt(id)]
    );

    const updatedItem = result.rows[0];
    res.json({
      id: updatedItem.id,
      item: updatedItem.item,
      quantity: updatedItem.quantity,
      itemType: updatedItem.type || 'N/A',
      vendor: updatedItem.vendor,
      unitPrice: parseFloat(updatedItem.unitprice) || 0,
      description: updatedItem.description || '',
      created_at: updatedItem.created_at ? updatedItem.created_at.toISOString() : null,
      updated_at: updatedItem.updated_at ? updatedItem.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error updating inventory item:', error);
    res.status(500).json({ error: 'Failed to update inventory item', details: error.message });
  }
};

// DELETE inventory item
const deleteInventory = async (req, res) => {
  try {
    const { id } = req.params;

    const existingItem = await pool.query('SELECT * FROM inventory WHERE id = $1', [parseInt(id)]);
    if (existingItem.rows.length === 0) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }

    await pool.query('DELETE FROM inventory WHERE id = $1', [parseInt(id)]);
    res.json({ message: 'Inventory item deleted successfully' });
  } catch (error) {
    console.error('Error deleting inventory item:', error);
    res.status(500).json({ error: 'Failed to delete inventory item', details: error.message });
  }
};

// Download inventory PDF report
const downloadInventoryPDF = async (req, res) => {
  let doc;

  try {
    const { dateRange } = req.query;
    let query = 'SELECT * FROM inventory';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY id ASC';

    const inventoryResult = await pool.query(query, values);

    doc = new PDFDocument({ margin: 50 });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="inventory-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    const logoPath = path.join(__dirname, '..', 'assets', 'logo.png');
    if (fs.existsSync(logoPath)) {
      doc.image(logoPath, 50, 30, { width: 100 });
    }

    doc.fontSize(22).text('Company Name', 160, 40);
    doc.fontSize(14).fillColor('gray').text('Inventory Report Summary', 160, 65);
    doc.moveDown();

    const totalItems = inventoryResult.rows.length;
    const totalValue = inventoryResult.rows.reduce((sum, item) => sum + (parseFloat(item.unitprice) * item.quantity || 0), 0);

    doc.moveDown(2);
    doc.fontSize(12).fillColor('black');
    doc.text(`Total Items: ${totalItems}`);
    doc.text(`Total Value: $${totalValue.toFixed(2)}`);
    doc.text(`Report Generated: ${new Date().toLocaleDateString()}`);
    doc.moveDown();

    let yPosition = doc.y + 40;
    const drawTableHeader = () => {
      doc.fontSize(10).fillColor('black');
      doc.text('ID', 50, yPosition);
      doc.text('Item', 80, yPosition);
      doc.text('Vendor', 160, yPosition);
      doc.text('Item Type', 240, yPosition);
      doc.text('Unit Price', 300, yPosition);
      doc.text('Quantity', 360, yPosition);
      doc.text('Total', 420, yPosition);
      yPosition += 15;
      doc.moveTo(50, yPosition).lineTo(520, yPosition).stroke();
      yPosition += 10;
    };

    drawTableHeader();

    inventoryResult.rows.forEach((item) => {
      if (yPosition > 700) {
        doc.addPage();
        yPosition = 50;
        drawTableHeader();
      }

      doc.text(item.id.toString(), 50, yPosition);
      doc.text((item.item || '').substring(0, 15), 80, yPosition);
      doc.text((item.vendor || '').substring(0, 15), 160, yPosition);
      doc.text(item.type || 'N/A', 240, yPosition);
      doc.text(`$${parseFloat(item.unitprice).toFixed(2)}`, 300, yPosition);
      doc.text(item.quantity.toString(), 360, yPosition);
      doc.text(`$${(parseFloat(item.unitprice) * item.quantity).toFixed(2)}`, 420, yPosition);
      yPosition += 18;
    });

    if (yPosition > 700) {
      doc.addPage();
      yPosition = 50;
    }

    yPosition += 40;
    doc.moveTo(50, yPosition).lineTo(520, yPosition).stroke();
    yPosition += 10;

    doc.fontSize(10).fillColor('gray');
    doc.text('Company Name', 50, yPosition);
    doc.text('Phone: +92 300 1234567', 50, yPosition + 15);
    doc.text('Email: info@company.com', 50, yPosition + 30);
    doc.text('Address: 123 Street, City, Pakistan', 50, yPosition + 45);

    doc.moveTo(400, yPosition + 45).lineTo(520, yPosition + 45).stroke();
    doc.text('Authorized Signature', 400, yPosition + 50);

    doc.end();
  } catch (error) {
    console.error('Error generating inventory PDF:', error);
    if (!res.headersSent) {
      res.status(500).json({ error: 'Failed to generate inventory PDF report', details: error.message });
    }
    if (doc) {
      doc.end();
    }
  }
};

module.exports = {
  getAllInventory,
  getInventoryById,
  createInventory,
  updateInventory,
  deleteInventory,
  downloadInventoryPDF,
};