const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const mapQuoteStatusToEnum = (status) => {
  const statusMap = {
    "draft": "DRAFT",
    "pending": "PENDING",
    "sent": "SENT",
    "accepted": "ACCEPTED",
    "declined": "DECLINED",
    "expired": "EXPIRED",
  };
  return statusMap[status.toLowerCase()] || "DRAFT";
};

const mapQuoteStatusFromEnum = (status) => {
  const statusMap = {
    "DRAFT": "draft",
    "PENDING": "pending",
    "SENT": "sent",
    "ACCEPTED": "accepted",
    "DECLINED": "declined",
    "EXPIRED": "expired",
  };
  return statusMap[status] || "draft";
};

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// GET all quotes
exports.getAllQuotes = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT q.*,
             (SELECT COUNT(*) FROM quote_items qi WHERE qi."quoteId" = q.id) as itemCount,
             (SELECT SUM(quantity * price) FROM quote_items qi WHERE qi."quoteId" = q.id) as totalAmount
      FROM quotes q
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE(q."updatedAt", q."createdAt") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY q."createdAt" DESC';

    const quotesResult = await pool.query(query, values);

    // Update expired quotes
    const currentDate = new Date();
    for (const quote of quotesResult.rows) {
      const isExpired = new Date(quote.expireDate) < currentDate && !['ACCEPTED', 'DECLINED'].includes(quote.status);
      if (isExpired && quote.status !== 'EXPIRED') {
        await pool.query(
          `UPDATE quotes SET status = $1, "updatedAt" = CURRENT_TIMESTAMP WHERE id = $2`,
          ['EXPIRED', quote.id]
        );
        quote.status = 'EXPIRED';
      }
    }

    const itemsResult = await pool.query('SELECT * FROM quote_items WHERE "quoteId" = ANY($1)', [
      quotesResult.rows.map(q => q.id),
    ]);

    const transformedQuotes = quotesResult.rows.map((quote) => ({
      id: String(quote.id),
      number: quote.number,
      companyname: quote.companyname,
      representative: quote.representative,
      email: quote.email,
      address: quote.address,
      phone: quote.phone,
      date: quote.date.toISOString().split('T')[0],
      expireDate: quote.expireDate.toISOString().split('T')[0],
      year: quote.year,
      currency: quote.currency,
      status: mapQuoteStatusFromEnum(quote.status),
      paid: quote.paid,
      note: quote.note || '',
      tax: quote.tax || 0,
      createdBy: quote.createdBy,
      itemCount: quote.itemCount,
      totalAmount: quote.totalAmount || 0,
      createdAt: quote.createdAt ? quote.createdAt.toISOString() : null,
      updatedAt: quote.updatedAt ? quote.updatedAt.toISOString() : null,
      items: itemsResult.rows
        .filter(item => item.quoteId === quote.id)
        .map(item => ({
          item: item.item,
          description: item.description || '',
          quantity: item.quantity,
          price: item.price,
        })),
    }));

    res.json(transformedQuotes);
  } catch (error) {
    console.error('Error fetching quotes:', error.message, error.stack);
    res.status(500).json({ error: 'Failed to fetch quotes', details: error.message });
  }
};

// GET single quote
exports.getQuoteById = async (req, res) => {
  try {
    const { id } = req.params;
    const quoteResult = await pool.query(
      `SELECT q.* FROM quotes q WHERE q.id = $1`,
      [id]
    );

    if (quoteResult.rows.length === 0) {
      return res.status(404).json({ error: 'Quote not found' });
    }

    const itemsResult = await pool.query('SELECT * FROM quote_items WHERE "quoteId" = $1', [id]);
    const quote = quoteResult.rows[0];

    const transformedQuote = {
      id: String(quote.id),
      number: quote.number,
      companyname: quote.companyname,
      representative: quote.representative,
      email: quote.email,
      address: quote.address,
      phone: quote.phone,
      date: quote.date.toISOString().split('T')[0],
      expireDate: quote.expireDate.toISOString().split('T')[0],
      year: quote.year,
      currency: quote.currency,
      status: mapQuoteStatusFromEnum(quote.status),
      paid: quote.paid,
      note: quote.note || '',
      tax: quote.tax || 0,
      createdBy: quote.createdBy,
      createdAt: quote.createdAt ? quote.createdAt.toISOString() : null,
      updatedAt: quote.updatedAt ? quote.updatedAt.toISOString() : null,
      items: itemsResult.rows.map(item => ({
        item: item.item,
        description: item.description || '',
        quantity: item.quantity,
        price: item.price,
      })),
    };

    res.json(transformedQuote);
  } catch (error) {
    console.error('Error fetching quote:', error);
    res.status(500).json({ error: 'Failed to fetch quote', details: error.message });
  }
};

// CREATE quote
exports.createQuote = async (req, res) => {
  try {
    const { number, companyname, representative, email, address, phone, date, expireDate, year, currency, status, paid, note, tax, createdBy, items } = req.body;

    if (!number || !companyname || !representative || !email || !address || !phone || !date || !expireDate || !items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Number, companyname, representative, email, address, phone, date, expireDate, and items are required' });
    }

    const existing = await pool.query('SELECT * FROM quotes WHERE number = $1', [number]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Quote number already exists' });
    }

    for (const item of items) {
      if (!item.item || !item.quantity || !item.price || isNaN(parseFloat(item.quantity)) || isNaN(parseFloat(item.price))) {
        return res.status(400).json({ error: 'Invalid item data' });
      }
    }

    await pool.query('BEGIN');
    const now = new Date();
    const quoteResult = await pool.query(
      `INSERT INTO quotes (id, number, companyname, representative, email, address, phone, date, "expireDate", year, currency, status, paid, note, tax, "createdBy", "createdAt", "updatedAt")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18) RETURNING *`,
      [
        crypto.randomUUID(),
        number,
        companyname,
        representative,
        email,
        address,
        phone,
        new Date(date),
        new Date(expireDate),
        year || new Date().getFullYear().toString(),
        currency || 'PKR',
        mapQuoteStatusToEnum(status || 'draft'),
        paid || 0,
        note || null,
        parseFloat(tax) || 0,
        createdBy || 'Admin',
        now,
        now,
      ]
    );

    const quoteId = quoteResult.rows[0].id;
    for (const item of items) {
      await pool.query(
        `INSERT INTO quote_items (id, "quoteId", item, description, quantity, price, "createdAt", "updatedAt")
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [crypto.randomUUID(), quoteId, item.item, item.description, parseFloat(item.quantity), parseFloat(item.price), now, now]
      );
    }

    await pool.query('COMMIT');

    const itemsResult = await pool.query('SELECT * FROM quote_items WHERE "quoteId" = $1', [quoteId]);
    const totalAmount = itemsResult.rows.reduce((sum, item) => sum + (item.quantity * item.price), 0);

    res.status(201).json({
      id: String(quoteResult.rows[0].id),
      number: quoteResult.rows[0].number,
      companyname: quoteResult.rows[0].companyname,
      representative: quoteResult.rows[0].representative,
      email: quoteResult.rows[0].email,
      address: quoteResult.rows[0].address,
      phone: quoteResult.rows[0].phone,
      date: quoteResult.rows[0].date.toISOString().split('T')[0],
      expireDate: quoteResult.rows[0].expireDate.toISOString().split('T')[0],
      year: quoteResult.rows[0].year,
      currency: quoteResult.rows[0].currency,
      status: mapQuoteStatusFromEnum(quoteResult.rows[0].status),
      paid: quoteResult.rows[0].paid,
      note: quoteResult.rows[0].note || '',
      tax: quoteResult.rows[0].tax || 0,
      createdBy: quoteResult.rows[0].createdBy,
      createdAt: quoteResult.rows[0].createdAt ? quoteResult.rows[0].createdAt.toISOString() : null,
      updatedAt: quoteResult.rows[0].updatedAt ? quoteResult.rows[0].updatedAt.toISOString() : null,
      itemCount: itemsResult.rows.length,
      totalAmount,
      items: itemsResult.rows.map(item => ({
        item: item.item,
        description: item.description || '',
        quantity: item.quantity,
        price: item.price,
      })),
    });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Error creating quote:', error);
    res.status(500).json({ error: 'Failed to create quote', details: error.message });
  }
};

// UPDATE quote
exports.updateQuote = async (req, res) => {
  try {
    const { id } = req.params;
    const { number, companyname, representative, email, address, phone, date, expireDate, year, currency, status, paid, note, tax, createdBy, items } = req.body;

    const existing = await pool.query('SELECT * FROM quotes WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Quote not found' });
    }

    if (number && number !== existing.rows[0].number) {
      const conflict = await pool.query('SELECT * FROM quotes WHERE number = $1 AND id != $2', [number, id]);
      if (conflict.rows.length > 0) {
        return res.status(400).json({ error: 'Quote number already exists' });
      }
    }

    for (const item of items || []) {
      if (!item.item || !item.quantity || !item.price || isNaN(parseFloat(item.quantity)) || isNaN(parseFloat(item.price))) {
        return res.status(400).json({ error: 'Invalid item data' });
      }
    }

    await pool.query('BEGIN');
    const now = new Date();
    const quoteResult = await pool.query(
      `UPDATE quotes SET number = $1, companyname = $2, representative = $3, email = $4, address = $5, phone = $6, date = $7, "expireDate" = $8, year = $9, currency = $10, status = $11, paid = $12, note = $13, tax = $14, "createdBy" = $15, "updatedAt" = $16 WHERE id = $17 RETURNING *`,
      [
        number || existing.rows[0].number,
        companyname || existing.rows[0].companyname,
        representative || existing.rows[0].representative,
        email || existing.rows[0].email,
        address || existing.rows[0].address,
        phone || existing.rows[0].phone,
        date ? new Date(date) : existing.rows[0].date,
        expireDate ? new Date(expireDate) : existing.rows[0].expireDate,
        year || existing.rows[0].year,
        currency || existing.rows[0].currency,
        status ? mapQuoteStatusToEnum(status) : existing.rows[0].status,
        paid !== undefined ? paid : existing.rows[0].paid,
        note !== undefined ? note : existing.rows[0].note,
        tax !== undefined ? parseFloat(tax) : existing.rows[0].tax,
        createdBy || existing.rows[0].createdBy,
        now,
        id,
      ]
    );

    if (items && items.length > 0) {
      await pool.query('DELETE FROM quote_items WHERE "quoteId" = $1', [id]);
      for (const item of items) {
        await pool.query(
          `INSERT INTO quote_items (id, "quoteId", item, description, quantity, price, "createdAt", "updatedAt")
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [crypto.randomUUID(), id, item.item, item.description, parseFloat(item.quantity), parseFloat(item.price), now, now]
        );
      }
    }

    await pool.query('COMMIT');

    const itemsResult = await pool.query('SELECT * FROM quote_items WHERE "quoteId" = $1', [id]);
    const totalAmount = itemsResult.rows.reduce((sum, item) => sum + (item.quantity * item.price), 0);

    res.json({
      id: String(quoteResult.rows[0].id),
      number: quoteResult.rows[0].number,
      companyname: quoteResult.rows[0].companyname,
      representative: quoteResult.rows[0].representative,
      email: quoteResult.rows[0].email,
      address: quoteResult.rows[0].address,
      phone: quoteResult.rows[0].phone,
      date: quoteResult.rows[0].date.toISOString().split('T')[0],
      expireDate: quoteResult.rows[0].expireDate.toISOString().split('T')[0],
      year: quoteResult.rows[0].year,
      currency: quoteResult.rows[0].currency,
      status: mapQuoteStatusFromEnum(quoteResult.rows[0].status),
      paid: quoteResult.rows[0].paid,
      note: quoteResult.rows[0].note || '',
      tax: quoteResult.rows[0].tax || 0,
      createdBy: quoteResult.rows[0].createdBy,
      createdAt: quoteResult.rows[0].createdAt ? quoteResult.rows[0].createdAt.toISOString() : null,
      updatedAt: quoteResult.rows[0].updatedAt ? quoteResult.rows[0].updatedAt.toISOString() : null,
      itemCount: itemsResult.rows.length,
      totalAmount,
      items: itemsResult.rows.map(item => ({
        item: item.item,
        description: item.description || '',
        quantity: item.quantity,
        price: item.price,
      })),
    });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Error updating quote:', error);
    res.status(500).json({ error: 'Failed to update quote', details: error.message });
  }
};

// DELETE quote
exports.deleteQuote = async (req, res) => {
  try {
    const { id } = req.params;

    const existing = await pool.query('SELECT * FROM quotes WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Quote not found' });
    }

    await pool.query('BEGIN');
    await pool.query('DELETE FROM quote_items WHERE "quoteId" = $1', [id]);
    await pool.query('DELETE FROM quotes WHERE id = $1', [id]);
    await pool.query('COMMIT');

    res.json({ message: 'Quote deleted successfully' });
  } catch (error) {
    await pool.query('ROLLBACK');
    console.error('Error deleting quote:', error);
    res.status(500).json({ error: 'Failed to delete quote', details: error.message });
  }
};

// DOWNLOAD all quotes PDF

exports.downloadQuotesPDF = async (req, res) => {
  let doc;

  try {
    // Fetch quotes with related data
    const quotesResult = await pool.query(`
      SELECT 
        id,
        number,
        companyname,
        representative,
        email,
        address,
        phone,
        status,
        "expireDate",
        "createdAt",
        currency,
        COALESCE(
          (SELECT SUM(quantity * price) 
           FROM quote_items qi 
           WHERE qi."quoteId" = q.id), 0
        ) as "totalAmount"
      FROM quotes q
      ORDER BY q."createdAt" DESC
    `);

    // Create PDF with better page setup
    doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      bufferPages: true
    });

    // Set response headers
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="quotes-report.pdf"');

    // Error handling for PDF stream
    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === IMPROVED HEADER SECTION ===
    const drawHeader = () => {
      // Company logo (if exists)
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.png');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 40, 40, { width: 60 });
      }

      // Company header with better styling
      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('AHS TECHNOLOGIES', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Quote Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })}`, 120, 90);

      // Decorative line
      doc
        .moveTo(40, 120)
        .lineTo(555, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // === SUMMARY STATISTICS ===
    const totalQuotes = quotesResult.rows.length;
    const totalAmount = quotesResult.rows.reduce(
      (sum, quote) => sum + (parseFloat(quote.totalAmount) || 0),
      0
    );

    // Status counts using database statuses
    const statusCounts = quotesResult.rows.reduce((acc, quote) => {
      const status = quote.status;
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {});

    // Summary cards layout
    let yPos = 140;

    // Main statistics box
    const currencySymbol = quotesResult.rows[0]?.currency === 'USD' ? '$' : 'RS';
    doc
      .rect(40, yPos, 515, 60)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Quotes: ${totalQuotes}`, 50, yPos + 30)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 300, yPos + 45);

    yPos += 80;

    // Status breakdown in a neat grid
    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Status Breakdown:', 40, yPos);

    yPos += 25;
    let statusX = 50;
    let statusY = yPos;

    Object.keys(statusCounts).forEach((status, index) => {
      const count = statusCounts[status] || 0;
      const percentage = totalQuotes > 0 ? ((count / totalQuotes) * 100).toFixed(1) : '0.0';

      const statusText = `${status}: ${count} (${percentage}%)`;
      const statusHeight = doc
        .fontSize(10)
        .font('Helvetica')
        .heightOfString(statusText, { width: 110 });

      if (statusY + statusHeight > 680) {
        doc.addPage();
        statusY = 60;
        statusX = 50;
      }

      doc
        .fontSize(10)
        .fillColor('#34495e')
        .font('Helvetica')
        .text(statusText, statusX, statusY);

      statusX += 120;
      if ((index + 1) % 4 === 0) {
        statusX = 50;
        statusY += statusHeight + 8;
      }
    });

    yPos = statusY + 40;

    const drawTableHeader = () => {
      if (yPos + 25 > 680) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 515, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');

      doc.text('Quote #', 90, yPos + 8);
      doc.text('Company', 170, yPos + 8);
      doc.text('Status', 290, yPos + 8);
      doc.text('Due Date', 360, yPos + 8);
      doc.text(`Amount (${currencySymbol})`, 470, yPos + 8);

      yPos += 25;
      return yPos;
    };

    yPos = drawTableHeader();

    // === TABLE ROWS WITH BETTER FORMATTING ===
    quotesResult.rows.forEach((quote, index) => {
      // Check for page break
      if (yPos + 20 > 680) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      // Alternate row colors
      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 515, 20)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(9)
        .font('Helvetica');

      // Table data with proper formatting
      doc.text((quote.number || 'N/A').substring(0, 12), 90, yPos + 6);

      // Better company name handling
      const companyName = quote.companyname || `Quote #${quote.id}`;
      doc.text(companyName.substring(0, 18), 170, yPos + 6);

      // Status with color coding
      const status = quote.status;
      let statusColor = '#2c3e50';
      if (status === 'PAID') statusColor = '#27ae60';
      else if (status === 'OVERDUE' || status === 'UNPAID') statusColor = '#e74c3c';
      else if (status === 'PENDING' || status === 'PARTIALLY_PAID') statusColor = '#f39c12';
      else if (status === 'DRAFT') statusColor = '#95a5a6';

      doc.fillColor(statusColor).text(status, 290, yPos + 6);

      // Formatted dates and amounts
      const currencySymbolRow = quote.currency === 'USD' ? '$' : 'RS';
      doc
        .fillColor('#2c3e50')
        .text(
          quote.expireDate ?
            new Date(quote.expireDate).toLocaleDateString('en-US', {
              month: 'short',
              day: '2-digit',
              year: '2-digit'
            }) : 'N/A',
          360, yPos + 6
        )
        .text(
          `${currencySymbolRow} ${(parseFloat(quote.totalAmount) || 0).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
          })}`,
          470, yPos + 6,
          { width: 80, align: 'right' }
        );

      yPos += 20;
    });

    if (yPos + 110 > 680) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;

    // Company footer information
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
          'AHS TECHNOLOGIES | Phone: +92 51 882 3062 | Email: sales@ahs-technologies.com | 4th Floor, Al-Samim Heights, Business Square, Gulberg Greens, Islamabad',
          40, 750, { align: 'center', width: 515 }
        );
    };

    // Add footer to all pages
    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    // Add footer to new pages
    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();

  } catch (error) {
    console.error('Error generating quotes PDF:', error);

    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate quotes PDF report',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }

    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

exports.downloadQuotesPDFById = async (req, res) => {
  let doc;

  try {
    const { id } = req.params;
    if (!id) {
      return res.status(400).json({
        success: false,
        error: 'Quote ID is required'
      });
    }

    // Fetch quote with all related data
    const quoteResult = await pool.query(`
      SELECT 
        q.*,
        q.note as "quoteNote",
        q.currency,
        COALESCE(
          (SELECT SUM(quantity * price) 
           FROM quote_items qi 
           WHERE qi."quoteId" = q.id), 0
        ) as "totalAmount"
      FROM quotes q
      WHERE q.id = $1
    `, [id]);

    if (quoteResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Quote not found'
      });
    }

    const quote = quoteResult.rows[0];

    // Fetch quote items
    const itemsResult = await pool.query(`
      SELECT 
        id,
        quantity,
        price,
        description,
        "createdAt"
      FROM quote_items 
      WHERE "quoteId" = $1
      ORDER BY "createdAt" ASC
    `, [quote.id]);

    // Create PDF with better setup
    doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      bufferPages: true
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="quote-${quote.number || quote.id}.pdf"`);

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    // === PROFESSIONAL HEADER ===
    const logoPath = path.join(__dirname, '..', 'assets', 'logo.png');
    if (fs.existsSync(logoPath)) {
      doc.image(logoPath, 40, 40, { width: 100, height: 70 });
    }

    // Company header with professional styling
    doc
      .fontSize(24)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('AHS TECHNOLOGIES', 150, 90)
      .fontSize(10)
      .fillColor('#7f8c8d')
      .font('Helvetica');

    // Quote details box (right aligned)
    const quoteBoxX = 410;
    doc
      .fontSize(18)
      .font('Helvetica-Bold')
      .text('QUOTE', quoteBoxX + 20, 50)
      .fontSize(10)
      .font('Helvetica')
      .text(`Quote #: ${quote.number || quote.id}`, quoteBoxX + 20, 70)
      .text(`Date: ${new Date(quote.date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      })}`, quoteBoxX + 20, 84)
      .text(`Due Date: ${quote.expireDate ?
        new Date(quote.expireDate).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        }) : 'N/A'}`, quoteBoxX + 20, 98);

    // Decorative line
    doc
      .moveTo(40, 130)
      .lineTo(555, 130)
      .strokeColor('#3498db')
      .lineWidth(2)
      .stroke();

    // === BILLING INFORMATION ===
    let yPos = 140;

    // From section (left side)
    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('From:', 40, yPos);

    let fromYPos = yPos + 14;
    const fromDetails = [
      'AHS TECHNOLOGIES',
      '4th Floor, Al-Samim Heights',
      'Business Square, Gulberg Greens',
      'Islamabad, Pakistan',
      'Phone: +92 51 882 3062'
    ];

    doc
      .fontSize(10)
      .fillColor('#34495e')
      .font('Helvetica');

    fromDetails.forEach((detail, index) => {
      if (index === 0) {
        doc.font('Helvetica-Bold').fillColor('#2c3e50');
      } else {
        doc.font('Helvetica').fillColor('#34495e');
      }
      const detailHeight = doc.heightOfString(detail, { width: 180 });
      if (fromYPos + detailHeight > 680) {
        doc.addPage();
        fromYPos = 60;
      }
      doc.text(detail, 40, fromYPos);
      fromYPos += detailHeight + 3;
    });

    // To section (closer to From)
    let customerYPos = yPos;
    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('To:', 230, customerYPos);

    const customerDetails = [
      quote.companyname,
      `Attn: ${quote.representative || 'N/A'}`,
      quote.address || 'N/A',
      `Phone: ${quote.phone || 'N/A'}`,
      `Email: ${quote.email || 'N/A'}`
    ];

    customerYPos += 14;
    doc
      .fontSize(10)
      .fillColor('#34495e')
      .font('Helvetica');

    customerDetails.forEach((detail, index) => {
      if (index === 0) {
        doc.font('Helvetica-Bold').fillColor('#2c3e50');
      } else {
        doc.font('Helvetica').fillColor('#34495e');
      }
      const detailHeight = doc.heightOfString(detail, { width: 180 });
      if (customerYPos + detailHeight > 680) {
        doc.addPage();
        customerYPos = 60;
      }
      doc.text(detail, 230, customerYPos);
      customerYPos += detailHeight + 3;
    });

    // GST/NTN/Website box (right side)
    let gstBoxYPos = yPos;
    doc
      .rect(410, gstBoxYPos, 145, 80)
      .lineWidth(1)
      .strokeColor('#34495e')
      .stroke()
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Tax Details:', 420, gstBoxYPos + 10);

    const taxDetails = [
      'NTN: A012250-1',
      'GST: 32-77-8762-244-58',
      'www.ahs-technologies.com'
    ];

    gstBoxYPos += 24;
    doc
      .fontSize(10)
      .fillColor('#34495e')
      .font('Helvetica');

    taxDetails.forEach((detail) => {
      const detailHeight = doc.heightOfString(detail, { width: 135 });
      if (gstBoxYPos + detailHeight > 680) {
        doc.addPage();
        gstBoxYPos = 60;
      }
      doc.text(detail, 420, gstBoxYPos);
      gstBoxYPos += detailHeight + 3;
    });

    // Set yPos to the bottom of the tallest section
    yPos = Math.max(fromYPos, customerYPos, gstBoxYPos) + 20;

    // Quote status badge
    const status = quote.status;
    let statusColor = '#95a5a6';
    let statusBg = '#ecf0f1';

    if (status === 'PAID') {
      statusColor = '#27ae60';
      statusBg = '#d5f4e6';
    } else if (status === 'OVERDUE' || status === 'UNPAID') {
      statusColor = '#e74c3c';
      statusBg = '#fdeaea';
    } else if (status === 'PENDING' || status === 'PARTIALLY_PAID') {
      statusColor = '#f39c12';
      statusBg = '#fef9e7';
    } else if (status === 'DRAFT') {
      statusColor = '#95a5a6';
      statusBg = '#ecf0f1';
    }

    if (yPos + 25 > 680) {
      doc.addPage();
      yPos = 60;
    }

    doc
      .rect(40, yPos, 100, 25)
      .fill(statusBg)
      .fillColor(statusColor)
      .fontSize(11)
      .font('Helvetica-Bold')
      .text(`Status: ${status.toUpperCase()}`, 45, yPos + 8);

    yPos += 45;

    // === ITEMS TABLE ===
    const drawTableHeader = () => {
      if (yPos + 60 > 680) {
        doc.addPage();
        yPos = 60;
      }
      // Quote note header
      if (quote.quoteNote) {
        const noteHeight = doc
          .fontSize(11)
          .font('Helvetica-Bold')
          .heightOfString(quote.quoteNote, { width: 515 });
        doc
          .rect(40, yPos, 515, noteHeight + 10)
          .fill('#34495e')
          .fillColor('white')
          .fontSize(11)
          .font('Helvetica-Bold')
          .text(quote.quoteNote, 40, yPos + 5, { align: 'center', width: 515 });
        yPos += noteHeight + 15;
      }

      // Main table header
      doc
        .rect(40, yPos, 515, 30)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(11)
        .font('Helvetica-Bold');

      doc.text('S#', 50, yPos + 10, { width: 30 });
      doc.text('Description', 90, yPos + 10, { width: 240 });
      doc.text('Qty', 340, yPos + 10, { width: 50 });
      doc.text('Price', 400, yPos + 10, { width: 60 });
      doc.text('Total', 470, yPos + 10, { width: 65, align: 'right' });

      yPos += 30;
      return yPos;
    };

    yPos = drawTableHeader();

    // Table rows with item details
    let subtotal = 0;
    const currencySymbol = quote.currency === 'USD' ? '$' : 'PKR';
    itemsResult.rows.forEach((item, index) => {
      const itemTotal = item.quantity * item.price;
      subtotal += itemTotal;

      // Calculate row height based on description
      const description = item.description || 'No description';
      const descriptionHeight = doc
        .fontSize(10)
        .font('Helvetica')
        .heightOfString(description, { width: 240 });
      const rowHeight = Math.max(25, descriptionHeight + 10);

      // Check for page break
      if (yPos + rowHeight > 680) {
        doc.addPage();
        yPos = 60;
        yPos = drawTableHeader();
      }

      // Alternate row colors
      const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
      doc
        .rect(40, yPos, 515, rowHeight)
        .fill(rowColor)
        .fillColor('#2c3e50')
        .fontSize(10)
        .font('Helvetica');

      // S#, Quantity, price, and total with adjusted padding
      doc
        .text((index + 1).toString(), 50, yPos + 8, { width: 30 })
        .text(description, 90, yPos + 8, { width: 240 })
        .text(item.quantity.toString(), 340, yPos + 8, { width: 50 })
        .text(`${currencySymbol} ${item.price.toFixed(2)}`, 400, yPos + 8, { width: 60 })
        .text(`${currencySymbol} ${itemTotal.toFixed(2)}`, 470, yPos + 8, { align: 'right', width: 65 });

      yPos += rowHeight;
    });

    // === Electronic print notice ===
    yPos += 10;
    if (yPos + 20 > 680) {
      doc.addPage();
      yPos = 60;
    }
    doc
      .fontSize(10)
      .fillColor('#7f8c8d')
      .font('Helvetica-Oblique')
      .text('This print is electronic no need of signature', 40, yPos, { align: 'center', width: 515 });
    yPos += 20;

    // === TOTALS SECTION ===
    yPos += 20;
    if (yPos + 80 > 680) {
      doc.addPage();
      yPos = 60;
    }

    // Summary box
    const summaryBoxY = yPos;

    doc
      .fillColor('#2c3e50')
      .fontSize(11)
      .font('Helvetica')
      .text('Subtotal:', 360, summaryBoxY + 15)
      .text(`${currencySymbol} ${subtotal.toFixed(2)}`, 480, summaryBoxY + 15, { align: 'left', width: 100 });

    // Add tax if present in quote
    const tax = quote.tax ? subtotal * (quote.tax / 100) : 0;
    let summaryBoxHeight = quote.tax ? 80 : 60;
    if (quote.tax) {
      doc
        .text(`Tax (${quote.tax}%):`, 360, summaryBoxY + 35)
        .text(`${currencySymbol} ${tax.toFixed(2)}`, 480, summaryBoxY + 35, { align: 'left', width: 100 });
    }

    doc
      .font('Helvetica-Bold')
      .fontSize(12)
      .text('Total:', 360, summaryBoxY + (quote.tax ? 55 : 35))
      .text(`${currencySymbol} ${(subtotal + tax).toFixed(2)}`, 480, summaryBoxY + (quote.tax ? 55 : 35), { align: 'left', width: 100 });

    yPos = summaryBoxY + summaryBoxHeight;

    // === PAYMENT TERMS ===
    yPos += 30;
    if (yPos + 30 > 680) {
      doc.addPage();
      yPos = 60;
    }

    doc
      .fontSize(10)
      .fillColor('#7f8c8d')
      .font('Helvetica')
      .text('Terms & Conditions:', 40, yPos);

    yPos += 12;

    const termsCurrency = quote.currency === 'USD' ? 'USD' : currencySymbol;
    const terms = [
      `1. All prices in ${termsCurrency} and will be valid for 15 days.`,
      '2. Prices are based on the delivery to the customer site.',
      '3. Payment 100% advance.',
      '4. Prices are inclusive of all Taxes.',
      '5. Errors and omissions are expected.'
    ];

    terms.forEach(term => {
      doc.text(term, 40, yPos, { width: 500 });
      yPos += 12;
    });

    // === PROFESSIONAL FOOTER ===
    const addFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
          'AHS TECHNOLOGIES | Phone: +92 51 882 3062 | Email: sales@ahs-technologies.com | 4th Floor, Al-Samim Heights, Business Square, Gulberg Greens, Islamabad',
          40, 750, { align: 'center', width: 515 }
        );
    };

    // Add footer to all pages
    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    // Add footer to new pages
    doc.on('pageAdded', () => {
      addFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();

  } catch (error) {
    console.error('Error generating single quote PDF:', error);

    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate single quote PDF',
        message: error.message,
        timestamp: new Date().toISOString()
      });
    }

    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};