const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
} = require('@simplewebauthn/server');
const cors = require('cors');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const jwtSecret = process.env.JWT_SECRET;
const rpName = 'ASHTECH ERP';
const rpID = 'localhost';
const expectedOrigin = process.env.RP_ORIGIN.split(",");

// CORS configuration
const corsOptions = {
  origin: process.env.ALLOWED_ORIGIN.split(","),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
};

const express = require('express');
const app = express();
app.use(cors(corsOptions));
app.use(express.json());

const challenges = new Map();

function normalizeTransports(transports) {
  if (!transports) return undefined;
  if (Array.isArray(transports)) return transports;
  if (typeof transports === 'string') {
    if (transports.includes(',')) {
      return transports.split(',').map(t => t.trim());
    }
    try {
      const parsed = JSON.parse(transports);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      console.warn(`Invalid transports format: ${transports}`);
      return undefined;
    }
  }
  return undefined;
}

const loginUser = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required.' });
  }

  try {
    const userQuery = 'SELECT id, email, password, status FROM users WHERE email = $1';
    const result = await pool.query(userQuery, [email]);
    const user = result.rows[0];

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    if (user.status !== 'Active') {
      return res.status(403).json({ 
        success: false, 
        message: 'Your account is currently inactive. Please contact support to reactivate your account.' 
      });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: '1h' });

    res.status(200).json({ success: true, message: 'Login successful!', token });
  } catch (error) {
    console.error('Error during login:', error);
    res.status(500).json({ success: false, message: 'An internal server error occurred.' });
  }
};

const registerFingerprint = async (req, res) => {
  try {
    const { userId } = req.body;
    
    const userQuery = 'SELECT id, email, name, status FROM users WHERE id = $1';
    const userResult = await pool.query(userQuery, [userId]);
    const user = userResult.rows[0];

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (user.status !== 'Active') {
      return res.status(403).json({ 
        success: false, 
        message: 'Your account is currently inactive. Please contact support to reactivate your account.' 
      });
    }

    const credentialsQuery = 'SELECT credential_id, aaguid, transports FROM authenticators WHERE user_id = $1';
    const credentialsResult = await pool.query(credentialsQuery, [userId]);
    const userCredentials = credentialsResult.rows;

    const options = await generateRegistrationOptions({
      rpName,
      rpID,
      userID: Buffer.from(user.id.toString()),
      userName: user.email,
      attestationType: 'none',
      excludeCredentials: userCredentials.map(credential => ({
        id: credential.credential_id,
        type: 'public-key',
        transports: normalizeTransports(credential.transports),
      })),
      timeout: 60000,
    });

    challenges.set(userId, options.challenge);

    res.status(200).json({ success: true, options });
  } catch (error) {
    console.error('Error during fingerprint registration initiation:', error);
    res.status(500).json({ success: false, message: `Failed to initiate registration: ${error.message}` });
  }
};

const verifyRegistration = async (req, res) => {
  try {
    const { userId, registrationResponse } = req.body;

    if (!userId || !registrationResponse) {
      return res.status(400).json({ success: false, message: 'userId and registrationResponse are required.' });
    }

    const challenge = challenges.get(userId);

    if (!challenge) {
      challenges.delete(userId);
      return res.status(400).json({ success: false, message: 'Registration session expired or invalid.' });
    }

    const verification = await verifyRegistrationResponse({
      response: registrationResponse,
      expectedChallenge: challenge,
      expectedOrigin,
      expectedRPID: rpID,
      requireUserVerification: false,
    });


    if (verification.verified) {
      const { registrationInfo } = verification;
      const { credential } = registrationInfo || {};
      if (!credential?.id || !credential?.publicKey) {
        throw new Error('Missing credentialID or credentialPublicKey in registrationInfo');
      }

      const credentialIDBase64 = Buffer.from(credential.id).toString('base64');
      const publicKeyBase64 = Buffer.from(credential.publicKey).toString('base64');

      const credentialInsertQuery = `
        INSERT INTO authenticators (user_id, credential_id, credential_public_key, sign_count, aaguid, transports)
        VALUES ($1, $2, $3, $4, $5, $6) RETURNING *
      `;
      await pool.query(credentialInsertQuery, [
        userId,
        credentialIDBase64,
        publicKeyBase64,
        credential.counter,
        registrationInfo.aaguid ? registrationInfo.aaguid.toString() : null,
        JSON.stringify(credential.transports || []),
      ]);

      challenges.delete(userId);

      res.status(200).json({ success: true, message: 'Fingerprint registered successfully!', verified: true });
    } else {
      challenges.delete(userId);
      res.status(400).json({ success: false, message: 'Failed to verify registration response.', verified: false });
    }
  } catch (error) {
    console.error('Error verifying registration:', error);
    challenges.delete(req.body.userId);
    res.status(500).json({ success: false, message: `An internal server error occurred: ${error.message}` });
  }
};

const loginFingerprint = async (req, res) => {
  try {
    const { email } = req.body;
    
    const userQuery = 'SELECT id, email, name, status FROM users WHERE email = $1';
    const userResult = await pool.query(userQuery, [email]);
    const user = userResult.rows[0];

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (user.status !== 'Active') {
      return res.status(403).json({ 
        success: false, 
        message: 'Your account is currently inactive. Please contact support to reactivate your account.' 
      });
    }

    const credentialsQuery = 'SELECT credential_id, transports FROM authenticators WHERE user_id = $1';
    const credentialsResult = await pool.query(credentialsQuery, [user.id]);
    const userCredentials = credentialsResult.rows;

    if (userCredentials.length === 0) {
      return res.status(400).json({ success: false, message: 'No fingerprint registered for this user.' });
    }

    const options = await generateAuthenticationOptions({
      rpID,
      allowCredentials: userCredentials.map(credential => ({
        id: credential.credential_id,
        type: 'public-key',
        transports: normalizeTransports(credential.transports) || ['hybrid', 'internal'],
      })),
      userVerification: 'preferred',
    });

    challenges.set(user.id, options.challenge);
    res.status(200).json({ success: true, options, userId: user.id });
    
  } catch (error) {
    console.error('Error during fingerprint login initiation:', error);
    res.status(500).json({ success: false, message: `Failed to initiate login: ${error.message}` });
  }
};

const verifyAuthentication = async (req, res) => {
  try {
    const { userId, authenticationResponse } = req.body;

    const challenge = challenges.get(userId);

    if (!challenge) {
      challenges.delete(userId);
      return res.status(400).json({ success: false, message: 'Authentication session expired or invalid.' });
    }

    const credentialQuery = 'SELECT * FROM authenticators WHERE user_id = $1 AND credential_id = $2';
    const credentialResult = await pool.query(credentialQuery, [userId, authenticationResponse.id]);
    const userCredential = credentialResult.rows[0];

    if (!userCredential) {
      challenges.delete(userId);
      return res.status(400).json({ success: false, message: 'Fingerprint credential not found.' });
    }

    const verification = await verifyAuthenticationResponse({
      response: authenticationResponse,
      expectedChallenge: challenge,
      expectedOrigin,
      expectedRPID: rpID,
      authenticator: {
        credentialID: Buffer.from(userCredential.credential_id, 'base64'),
        credentialPublicKey: Buffer.from(userCredential.credential_public_key, 'base64'),
        counter: userCredential.sign_count,
      },
      requireUserVerification: false,
    });

    if (verification.verified) {
      const { newCounter } = verification.authenticationInfo;
      const updateCounterQuery = 'UPDATE authenticators SET sign_count = $1, updated_at = now() WHERE id = $2';
      await pool.query(updateCounterQuery, [newCounter, userCredential.id]);

      challenges.delete(userId);

      const userQuery = 'SELECT id, email, status FROM users WHERE id = $1';
      const userResult = await pool.query(userQuery, [userId]);
      const user = userResult.rows[0];

      if (user.status !== 'Active') {
        return res.status(403).json({ 
          success: false, 
          message: 'Your account is currently inactive. Please contact support to reactivate your account.' 
        });
      }

      const token = jwt.sign({ sub: user.id, email: user.email }, jwtSecret, { expiresIn: '1h' });

      res.status(200).json({ success: true, message: 'Fingerprint login successful!', token });
    } else {
      challenges.delete(userId);
      res.status(400).json({ success: false, message: 'Fingerprint authentication failed.' });
    }
  } catch (error) {
    console.error('Error verifying authentication:', error);
    challenges.delete(req.body.userId);
    res.status(500).json({ success: false, message: `An internal server error occurred: ${error.message}` });
  }
};

module.exports = {
  loginUser,
  registerFingerprint,
  verifyRegistration,
  loginFingerprint,
  verifyAuthentication,
};