const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Enum definitions
const TRANSACTION_TYPES = {
  'Income': 'INCOME',
  'Expense': 'EXPENSE',
  'Transfer': 'TRANSFER'
};

const TRANSACTION_STATUSES = {
  'Pending': 'PENDING',
  'Completed': 'COMPLETED',
  'Cancelled': 'CANCELLED'
};

const CATEGORIES = {
  'Office Supplies': 'OFFICE_SUPPLIES',
  'Marketing': 'MARKETING',
  'Travel': 'TRAVEL',
  'Utilities': 'UTILITIES',
  'Salaries': 'SALARIES',
  'Equipment': 'EQUIPMENT',
  'Software': 'SOFTWARE',
  'Professional Services': 'PROFESSIONAL_SERVICES',
  'Sales': 'SALES',
  'Rent': 'RENT',
  'Payroll': 'PAYROLL',
  'Other': 'OTHER'
};

// Reverse mappings for display
const TRANSACTION_TYPES_REVERSE = Object.fromEntries(
  Object.entries(TRANSACTION_TYPES).map(([key, value]) => [value, key])
);

const TRANSACTION_STATUSES_REVERSE = Object.fromEntries(
  Object.entries(TRANSACTION_STATUSES).map(([key, value]) => [value, key])
);

const CATEGORIES_REVERSE = Object.fromEntries(
  Object.entries(CATEGORIES).map(([key, value]) => [value, key])
);

// Enum conversion functions
const mapTypeToEnum = (type) => TRANSACTION_TYPES[type] || 'INCOME';
const mapTypeFromEnum = (type) => TRANSACTION_TYPES_REVERSE[type] || 'Income';
const mapTransactionStatusToEnum = (status) => TRANSACTION_STATUSES[status] || 'PENDING';
const mapTransactionStatusFromEnum = (status) => TRANSACTION_STATUSES_REVERSE[status] || 'Pending';
const mapCategoryToEnum = (category) => CATEGORIES[category] || 'OTHER';
const mapCategoryFromEnum = (category) => CATEGORIES_REVERSE[category] || 'Other';

// Validation functions
const isValidTransactionType = (type) => Object.keys(TRANSACTION_TYPES).includes(type);
const isValidTransactionStatus = (status) => Object.keys(TRANSACTION_STATUSES).includes(status);
const isValidCategory = (category) => Object.keys(CATEGORIES).includes(category);

const validateTransactionInput = (data) => {
  const errors = [];

  if (!data.type || !isValidTransactionType(data.type)) {
    errors.push(`Invalid transaction type. Valid options: ${Object.keys(TRANSACTION_TYPES).join(', ')}`);
  }

  if (!data.amount || isNaN(parseFloat(data.amount)) || parseFloat(data.amount) <= 0) {
    errors.push('Amount must be a valid number greater than 0');
  }

  if (!data.bank || typeof data.bank !== 'string' || data.bank.trim() === '') {
    errors.push('Bank name is required');
  }

  if (!data.category || !isValidCategory(data.category)) {
    errors.push(`Invalid category. Valid options: ${Object.keys(CATEGORIES).join(', ')}`);
  }

  if (!data.date || isNaN(Date.parse(data.date))) {
    errors.push('Valid date is required');
  }

  if (data.status && !isValidTransactionStatus(data.status)) {
    errors.push(`Invalid status. Valid options: ${Object.keys(TRANSACTION_STATUSES).join(', ')}`);
  }

  if (data.type !== 'Transfer') {
    if (data.customerid) {
      // Validate customerid if provided
      if (isNaN(parseInt(data.customerid))) {
        errors.push('Customer ID must be a valid number');
      }
    }
    if (data.customername && !data.customerid) {
      // Allow customername only if customerid is not provided
      if (typeof data.customername !== 'string' || data.customername.trim() === '') {
        errors.push('Customer name must be a non-empty string if no customer ID is provided');
      }
    }
  } else {
    if (!data.fromcustomerid || isNaN(parseInt(data.fromcustomerid))) {
      errors.push('From customer ID is required for Transfer transactions');
    }
    if (!data.tocustomerid || isNaN(parseInt(data.tocustomerid))) {
      errors.push('To customer ID is required for Transfer transactions');
    }
    if (data.fromcustomerid && data.tocustomerid && data.fromcustomerid === data.tocustomerid) {
      errors.push('From and To customers must be different');
    }
  }

  return errors;
};

// Function to update customer amount in customers table
const updateCustomerAmount = async (customerid, amount, type, isReverse = false) => {
  if (!customerid) return;

  const sign = isReverse ? -1 : 1;
  let adjustment = 0;

  if (type === 'INCOME') {
    adjustment = -amount * sign; // Income reduces customer balance (payment received)
  } else if (type === 'EXPENSE') {
    adjustment = amount * sign; // Expense increases customer balance (charge added)
  } else {
    return; // Transfer handled separately
  }

  try {
    await pool.query(
      `UPDATE customers SET amount = amount + $1 WHERE id = $2`,
      [adjustment, parseInt(customerid)]
    );
  } catch (error) {
    console.error('Error updating customer amount:', error);
    throw new Error('Failed to update customer balance');
  }
};

// Function to update customer amounts for Transfer transactions
const updateTransferCustomerAmounts = async (fromcustomerid, tocustomerid, amount, isReverse = false) => {
  if (!fromcustomerid || !tocustomerid) return;

  const sign = isReverse ? -1 : 1;

  try {
    await pool.query(
      `UPDATE customers SET amount = amount - $1 WHERE id = $2`,
      [amount * sign, parseInt(fromcustomerid)]
    );
    await pool.query(
      `UPDATE customers SET amount = amount + $1 WHERE id = $2`,
      [amount * sign, parseInt(tocustomerid)]
    );
  } catch (error) {
    console.error('Error updating transfer customer amounts:', error);
    throw new Error('Failed to update customer balances for transfer');
  }
};

// Transform transaction data for API response
const transformTransaction = (transaction) => ({
  id: transaction.id,
  type: mapTypeFromEnum(transaction.type),
  amount: parseFloat(transaction.amount) || 0,
  bank: transaction.bank,
  checkNumber: transaction.checknumber || '',
  customername: transaction.customername || null,
  customerid: transaction.customerid ? transaction.customerid.toString() : null,
  fromcustomerid: transaction.fromcustomerid ? transaction.fromcustomerid.toString() : null,
  tocustomerid: transaction.tocustomerid ? transaction.tocustomerid.toString() : null,
  status: mapTransactionStatusFromEnum(transaction.status),
  category: mapCategoryFromEnum(transaction.category),
  date: transaction.date.toISOString().split('T')[0],
  description: transaction.description || '',
  createdBy: transaction.createdby,
  createdAt: transaction.createdat.toISOString(),
  updatedAt: transaction.updatedat.toISOString(),
});

// GET all transactions
const getAllTransactions = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT t.*, c.name as customername, cfrom.name as fromcustomername, cto.name as tocustomername
      FROM transactions t
      LEFT JOIN customers c ON t.customerid = c.id
      LEFT JOIN customers cfrom ON t.fromcustomerid = cfrom.id
      LEFT JOIN customers cto ON t.tocustomerid = cto.id
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE(t.updatedat, t.createdat) >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY t.createdat DESC';

    const result = await pool.query(query, values);
    const transformed = result.rows.map(row => transformTransaction(row));
    res.json(transformed);
  } catch (error) {
    console.error('Error fetching transactions:', error);
    res.status(500).json({ error: 'Failed to fetch transactions' });
  }
};

// GET single transaction
const getTransactionById = async (req, res) => {
  try {
    const { id } = req.params;

    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(id)) {
      return res.status(400).json({ error: 'Invalid transaction ID format' });
    }

    const result = await pool.query(`
      SELECT t.*, c.name as customername, cfrom.name as fromcustomername, cto.name as tocustomername
      FROM transactions t
      LEFT JOIN customers c ON t.customerid = c.id
      LEFT JOIN customers cfrom ON t.fromcustomerid = cfrom.id
      LEFT JOIN customers cto ON t.tocustomerid = cto.id
      WHERE t.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const row = result.rows[0];
    res.json(transformTransaction(row));
  } catch (error) {
    console.error('Error fetching transaction:', error);
    res.status(500).json({ error: 'Failed to fetch transaction' });
  }
};

// CREATE new transaction
const createTransaction = async (req, res) => {
  try {
    const validationErrors = validateTransactionInput(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationErrors
      });
    }

    const {
      type, amount, bank, checkNumber, status, category,
      date, description, createdBy, customerid, customername,
      fromcustomerid, tocustomerid
    } = req.body;

    let finalcustomername = customername || null;
    if (type !== 'Transfer' && customerid) {
      const customerResult = await pool.query('SELECT name FROM customers WHERE id = $1', [parseInt(customerid)]);
      if (customerResult.rows.length === 0) {
        return res.status(400).json({ error: 'Customer not found' });
      }
      finalcustomername = customerResult.rows[0].name;
    } else if (type === 'Transfer') {
      if (fromcustomerid) {
        const fromCustomerResult = await pool.query('SELECT id FROM customers WHERE id = $1', [parseInt(fromcustomerid)]);
        if (fromCustomerResult.rows.length === 0) {
          return res.status(400).json({ error: 'From customer not found' });
        }
      }
      if (tocustomerid) {
        const toCustomerResult = await pool.query('SELECT id FROM customers WHERE id = $1', [parseInt(tocustomerid)]);
        if (toCustomerResult.rows.length === 0) {
          return res.status(400).json({ error: 'To customer not found' });
        }
      }
      finalcustomername = null;
    }

    const transactionId = crypto.randomUUID();
    const result = await pool.query(
      `INSERT INTO transactions (
        id, type, amount, bank, checkNumber, status, category, date,
        description, createdby, customername, customerid, fromcustomerid, tocustomerid,
        createdat, updatedat
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
      RETURNING *`,
      [
        transactionId,
        mapTypeToEnum(type),
        parseFloat(amount),
        bank.trim(),
        checkNumber || null,
        mapTransactionStatusToEnum(status || 'Pending'),
        mapCategoryToEnum(category),
        new Date(date),
        description || null,
        createdBy || 'Admin',
        finalcustomername,
        customerid ? parseInt(customerid) : null,
        fromcustomerid ? parseInt(fromcustomerid) : null,
        tocustomerid ? parseInt(tocustomerid) : null,
        new Date(),
        new Date(),
      ]
    );

    const newTransaction = result.rows[0];

    if (newTransaction.status === 'COMPLETED') {
      if (newTransaction.type === 'INCOME' && newTransaction.customerid) {
        await updateCustomerAmount(newTransaction.customerid, parseFloat(newTransaction.amount), newTransaction.type);
      } else if (newTransaction.type === 'EXPENSE' && newTransaction.customerid) {
        await updateCustomerAmount(newTransaction.customerid, parseFloat(newTransaction.amount), newTransaction.type);
      } else if (newTransaction.type === 'TRANSFER' && newTransaction.fromcustomerid && newTransaction.tocustomerid) {
        await updateTransferCustomerAmounts(newTransaction.fromcustomerid, newTransaction.tocustomerid, parseFloat(newTransaction.amount));
      }
    }

    res.status(201).json(transformTransaction(newTransaction));
  } catch (error) {
    console.error('Error creating transaction:', error);
    res.status(500).json({ error: 'Failed to create transaction' });
  }
};

// UPDATE transaction
const updateTransaction = async (req, res) => {
  try {
    const { id } = req.params;

    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(id)) {
      return res.status(400).json({ error: 'Invalid transaction ID format' });
    }

    const validationErrors = validateTransactionInput(req.body);
    if (validationErrors.length > 0) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationErrors
      });
    }

    const {
      type, amount, bank, checkNumber, status, category,
      date, description, createdBy, customerid, customername,
      fromcustomerid, tocustomerid
    } = req.body;

    // Fetch existing transaction
    const existingResult = await pool.query(
      `SELECT * FROM transactions WHERE id = $1`,
      [id]
    );

    if (existingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const existingTransaction = existingResult.rows[0];

    let finalcustomername = customername || null;
    if (type !== 'Transfer' && customerid) {
      const customerResult = await pool.query('SELECT name FROM customers WHERE id = $1', [parseInt(customerid)]);
      if (customerResult.rows.length === 0) {
        return res.status(400).json({ error: 'Customer not found' });
      }
      finalcustomername = customerResult.rows[0].name;
    } else if (type === 'Transfer') {
      if (fromcustomerid) {
        const fromCustomerResult = await pool.query('SELECT id FROM customers WHERE id = $1', [parseInt(fromcustomerid)]);
        if (fromCustomerResult.rows.length === 0) {
          return res.status(400).json({ error: 'From customer not found' });
        }
      }
      if (tocustomerid) {
        const toCustomerResult = await pool.query('SELECT id FROM customers WHERE id = $1', [parseInt(tocustomerid)]);
        if (toCustomerResult.rows.length === 0) {
          return res.status(400).json({ error: 'To customer not found' });
        }
      }
      finalcustomername = null;
    }

    // Reverse previous customer balance updates if transaction was completed
    if (existingTransaction.status === 'COMPLETED') {
      if (existingTransaction.type === 'INCOME' && existingTransaction.customerid) {
        await updateCustomerAmount(existingTransaction.customerid, parseFloat(existingTransaction.amount), existingTransaction.type, true);
      } else if (existingTransaction.type === 'EXPENSE' && existingTransaction.customerid) {
        await updateCustomerAmount(existingTransaction.customerid, parseFloat(existingTransaction.amount), existingTransaction.type, true);
      } else if (existingTransaction.type === 'TRANSFER' && existingTransaction.fromcustomerid && existingTransaction.tocustomerid) {
        await updateTransferCustomerAmounts(existingTransaction.fromcustomerid, existingTransaction.tocustomerid, parseFloat(existingTransaction.amount), true);
      }
    }

    const result = await pool.query(
      `UPDATE transactions SET
        type = $1,
        amount = $2,
        bank = $3,
        checkNumber = $4,
        status = $5,
        category = $6,
        date = $7,
        description = $8,
        createdby = $9,
        customername = $10,
        customerid = $11,
        fromcustomerid = $12,
        tocustomerid = $13,
        updatedat = $14
      WHERE id = $15
      RETURNING *`,
      [
        mapTypeToEnum(type),
        parseFloat(amount),
        bank.trim(),
        checkNumber || null,
        mapTransactionStatusToEnum(status || 'Pending'),
        mapCategoryToEnum(category),
        new Date(date),
        description || null,
        createdBy || existingTransaction.createdby,
        finalcustomername,
        customerid ? parseInt(customerid) : null,
        fromcustomerid ? parseInt(fromcustomerid) : null,
        tocustomerid ? parseInt(tocustomerid) : null,
        new Date(),
        id
      ]
    );

    const updatedTransaction = result.rows[0];

    if (updatedTransaction.status === 'COMPLETED') {
      if (updatedTransaction.type === 'INCOME' && updatedTransaction.customerid) {
        await updateCustomerAmount(updatedTransaction.customerid, parseFloat(updatedTransaction.amount), updatedTransaction.type);
      } else if (updatedTransaction.type === 'EXPENSE' && updatedTransaction.customerid) {
        await updateCustomerAmount(updatedTransaction.customerid, parseFloat(updatedTransaction.amount), updatedTransaction.type);
      } else if (updatedTransaction.type === 'TRANSFER' && updatedTransaction.fromcustomerid && updatedTransaction.tocustomerid) {
        await updateTransferCustomerAmounts(updatedTransaction.fromcustomerid, updatedTransaction.tocustomerid, parseFloat(updatedTransaction.amount));
      }
    }

    res.json(transformTransaction(updatedTransaction));
  } catch (error) {
    console.error('Error updating transaction:', error);
    res.status(500).json({ error: 'Failed to update transaction' });
  }
};

// DELETE transaction
const deleteTransaction = async (req, res) => {
  try {
    const { id } = req.params;

    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(id)) {
      return res.status(400).json({ error: 'Invalid transaction ID format' });
    }

    const existingResult = await pool.query(
      `SELECT * FROM transactions WHERE id = $1`,
      [id]
    );

    if (existingResult.rows.length === 0) {
      return res.status(404).json({ error: 'Transaction not found' });
    }

    const existingTransaction = existingResult.rows[0];

    if (existingTransaction.status === 'COMPLETED') {
      if (existingTransaction.type === 'INCOME' && existingTransaction.customerid) {
        await updateCustomerAmount(existingTransaction.customerid, parseFloat(existingTransaction.amount), existingTransaction.type, true);
      } else if (existingTransaction.type === 'EXPENSE' && existingTransaction.customerid) {
        await updateCustomerAmount(existingTransaction.customerid, parseFloat(existingTransaction.amount), existingTransaction.type, true);
      } else if (existingTransaction.type === 'TRANSFER' && existingTransaction.fromcustomerid && existingTransaction.tocustomerid) {
        await updateTransferCustomerAmounts(existingTransaction.fromcustomerid, existingTransaction.tocustomerid, parseFloat(existingTransaction.amount), true);
      }
    }

    await pool.query('DELETE FROM transactions WHERE id = $1', [id]);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting transaction:', error);
    res.status(500).json({ error: 'Failed to delete transaction' });
  }
};

// GET balance
const getBalance = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        COALESCE(SUM(CASE WHEN type = 'INCOME' AND status = 'COMPLETED' THEN amount ELSE 0 END), 0) -
        COALESCE(SUM(CASE WHEN type = 'EXPENSE' AND status = 'COMPLETED' THEN amount ELSE 0 END), 0) as balance
      FROM transactions
    `);
    res.json({ balance: parseFloat(result.rows[0].balance) || 0 });
  } catch (error) {
    console.error('Error fetching balance:', error);
    res.status(500).json({ error: 'Failed to fetch balance' });
  }
};

// GET transactions by status
const getTransactionsByStatus = async (req, res) => {
  try {
    const { status } = req.params;
    const validStatus = mapTransactionStatusToEnum(status);

    if (!isValidTransactionStatus(status)) {
      return res.status(400).json({ 
        error: `Invalid status. Valid options: ${Object.keys(TRANSACTION_STATUSES).join(', ')}`
      });
    }

    const result = await pool.query(`
      SELECT t.*, c.name as customername, cfrom.name as fromcustomername, cto.name as tocustomername
      FROM transactions t
      LEFT JOIN customers c ON t.customerid = c.id
      LEFT JOIN customers cfrom ON t.fromcustomerid = cfrom.id
      LEFT JOIN customers cto ON t.tocustomerid = cto.id
      WHERE t.status = $1
      ORDER BY t.createdat DESC
    `, [validStatus]);

    const transformed = result.rows.map(row => transformTransaction(row));
    res.json(transformed);
  } catch (error) {
    console.error('Error fetching transactions by status:', error);
    res.status(500).json({ error: 'Failed to fetch transactions by status' });
  }
};

// GET enum options
const getEnumOptions = async (req, res) => {
  try {
    res.json({
      transactionTypes: Object.keys(TRANSACTION_TYPES),
      statuses: Object.keys(TRANSACTION_STATUSES),
      categories: Object.keys(CATEGORIES)
    });
  } catch (error) {
    console.error('Error fetching enum options:', error);
    res.status(500).json({ error: 'Failed to fetch enum options' });
  }
};

// GET all customers
const getAllCustomers = async (req, res) => {
  try {
    const result = await pool.query('SELECT id, name, amount FROM customers ORDER BY name');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching customers:', error);
    res.status(500).json({ error: 'Failed to fetch customers' });
  }
};

// DOWNLOAD finance PDF
const toSafeString = (val, fallback = '') => (val === null || val === undefined) ? fallback : String(val);
const toSafeNumber = (val, fallback = 0) => {
  if (val === null || val === undefined || val === '') return fallback;
  const n = Number(val);
  return Number.isFinite(n) ? n : fallback;
};
const toSafeInt = (val, fallback = null) => {
  if (val === null || val === undefined || val === '') return fallback;
  const n = parseInt(String(val), 10);
  return Number.isNaN(n) ? fallback : n;
};
const toSafeLower = (val, fallback = '') => toSafeString(val, fallback).toLowerCase();

const formatCurrency = (amount, currencySymbol) => {
  const n = toSafeNumber(amount, 0);
  return `${currencySymbol} ${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

// MAIN handler
// If you're using TypeScript rename to: export const downloadFinancePDF = async (req: Request, res: Response) => { ... }
const downloadFinancePDF = async (req, res) => {
  let doc;
  try {
    const { dateRange, fromDate, toDate, status, category } = req.query || {};

    // Build base query
    let query = `
      SELECT t.*, c.name as customername, cfrom.name as fromcustomername, cto.name as tocustomername
      FROM transactions t
      LEFT JOIN customers c ON t.customerid = c.id
      LEFT JOIN customers cfrom ON t.fromcustomerid = cfrom.id
      LEFT JOIN customers cto ON t.tocustomerid = cto.id
    `;

    const values = [];
    const whereParts = [];

    // dateRange handling (safe map to days on server)
    if (dateRange) {
      let days = 7; // default
      switch (String(dateRange)) {
        case '7d': days = 7; break;
        case '14d': days = 14; break;
        case '30d': days = 30; break;
        default: days = 7;
      }
      // days is an integer we control, safe to interpolate into the INTERVAL literal
      whereParts.push(`COALESCE(t.updatedat, t.createdat) >= CURRENT_DATE - INTERVAL '${days} days'`);
    }

    // fromDate & toDate (parameterized)
    if (fromDate && toDate) {
      values.push(fromDate);
      values.push(toDate);
      const idxFrom = values.length - 1;
      const idxTo = values.length;
      whereParts.push(`t.date BETWEEN $${idxFrom} AND $${idxTo}`);
    } else if (fromDate) {
      values.push(fromDate);
      whereParts.push(`t.date >= $${values.length}`);
    } else if (toDate) {
      values.push(toDate);
      whereParts.push(`t.date <= $${values.length}`);
    }

    // status (use your mapper to transform readable status into stored enum)
    if (status) {
      const mapped = mapTransactionStatusToEnum ? mapTransactionStatusToEnum(String(status)) : String(status);
      values.push(mapped);
      whereParts.push(`t.status = $${values.length}`);
    }

    // category
    if (category) {
      const mappedCat = mapCategoryToEnum ? mapCategoryToEnum(String(category)) : String(category);
      values.push(mappedCat);
      whereParts.push(`t.category = $${values.length}`);
    }

    if (whereParts.length) {
      query += ' WHERE ' + whereParts.join(' AND ');
    }

    query += ' ORDER BY t.createdat DESC';

    // Execute query
    const result = await pool.query(query, values);

    // Begin PDF creation
    doc = new PDFDocument({ size: 'A4', margin: 40, bufferPages: true });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="finance-report.pdf"');

    doc.pipe(res);

    // Header drawer
    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        try {
          doc.image(logoPath, 40, 40, { width: 60 });
        } catch (e) {
          // ignore image errors
        }
      }

      doc
        .fontSize(24)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 120, 45)
        .fontSize(12)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Finance Summary Report', 120, 75)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}`, 120, 90);

      doc
        .moveTo(40, 120)
        .lineTo(555, 120)
        .strokeColor('#3498db')
        .lineWidth(2)
        .stroke();
    };

    drawHeader();

    // Transform rows safely using user's transformTransaction if exists
    const rawRows = result.rows || [];
    const transactions = rawRows.map(row => {
      if (typeof transformTransaction === 'function') return transformTransaction(row);
      // fallback transform if transformTransaction is not provided
      return {
        ...row,
        customername: toSafeString(row.customername, null),
        fromcustomername: toSafeString(row.fromcustomername, null),
        tocustomername: toSafeString(row.tocustomername, null),
        amount: row.amount,
        type: toSafeString(row.type, '').trim(),
        status: toSafeString(row.status, '').trim(),
        description: toSafeString(row.description, ''),
        bank: toSafeString(row.bank, ''),
        currency: toSafeString(row.currency, 'PKR'),
      };
    });

    // Summary statistics (safe operations)
    const totalTransactions = transactions.length;
    const totalIncome = transactions
      .filter(t => toSafeLower(t.type) === 'income' && toSafeLower(t.status) === 'completed')
      .reduce((sum, t) => sum + toSafeNumber(t.amount, 0), 0);
    const totalExpenses = transactions
      .filter(t => toSafeLower(t.type) === 'expense' && toSafeLower(t.status) === 'completed')
      .reduce((sum, t) => sum + toSafeNumber(t.amount, 0), 0);
    const netProfit = totalIncome - totalExpenses;

    // status counts
    const statusCounts = transactions.reduce((acc, transaction) => {
      const st = toSafeLower(transaction.status, 'unknown');
      acc[st] = (acc[st] || 0) + 1;
      return acc;
    }, {});

    let yPos = 140;
    const currencySymbol = toSafeString(transactions[0]?.currency, 'PKR') === 'USD' ? '$' : 'RS';

    // Summary box
    doc
      .rect(40, yPos, 515, 100)
      .fillAndStroke('#ecf0f1', '#bdc3c7')
      .fillColor('#2c3e50')
      .fontSize(14)
      .font('Helvetica-Bold')
      .text('Summary Statistics', 50, yPos + 10)
      .fontSize(11)
      .font('Helvetica')
      .text(`Total Transactions: ${totalTransactions}`, 50, yPos + 30)
      .text(`Total Income: ${formatCurrency(totalIncome, currencySymbol)}`, 50, yPos + 45)
      .text(`Total Expenses: ${formatCurrency(totalExpenses, currencySymbol)}`, 50, yPos + 60)
      .text(`Net Profit/Loss: ${formatCurrency(netProfit, currencySymbol)}`, 50, yPos + 75)
      .text(`Report Period: ${fromDate || 'All'} to ${toDate || 'All'}`, 300, yPos + 30)
      .text(`Filter Status: ${status || 'All'}`, 300, yPos + 45)
      .text(`Filter Category: ${category || 'All'}`, 300, yPos + 60)
      .text(`Report Date: ${new Date().toLocaleDateString()}`, 300, yPos + 75);

    yPos += 120;

    // Status breakdown
    doc
      .fontSize(12)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Status Breakdown:', 40, yPos);

    yPos += 25;
    let statusX = 50;
    let statusY = yPos;

    Object.keys(statusCounts).forEach((st, index) => {
      const count = statusCounts[st] || 0;
      const percentage = totalTransactions > 0 ? ((count / totalTransactions) * 100).toFixed(1) : '0.0';

      const statusText = `${st}: ${count} (${percentage}%)`;
      const statusHeight = doc
        .fontSize(10)
        .font('Helvetica')
        .heightOfString(statusText, { width: 110 });

      if (statusY + statusHeight > 680) {
        doc.addPage();
        statusY = 60;
        statusX = 50;
      }

      doc
        .fontSize(10)
        .fillColor('#34495e')
        .font('Helvetica')
        .text(statusText, statusX, statusY);

      statusX += 120;
      if ((index + 1) % 4 === 0) {
        statusX = 50;
        statusY += statusHeight + 8;
      }
    });

    yPos = statusY + 40;

    // Draw table header (with page check)
    const drawTableHeader = () => {
      if (yPos + 25 > 680) {
        doc.addPage();
        yPos = 60;
      }
      doc
        .rect(40, yPos, 515, 25)
        .fill('#34495e')
        .fillColor('white')
        .fontSize(10)
        .font('Helvetica-Bold');

      doc.text('Type', 50, yPos + 8);
      doc.text('Description', 150, yPos + 8);
      doc.text('Bank', 290, yPos + 8);
      doc.text('Customer', 350, yPos + 8);
      doc.text(`Amount (${currencySymbol})`, 430, yPos + 8);
      doc.text('Status', 520, yPos + 8);

      yPos += 30;
      return yPos;
    };

    yPos = drawTableHeader();

    // Table rows
   transactions.forEach((transaction, index) => {
  const description = transaction.description || '';

  // Ensure from/to names are correct based on matching IDs
  let customerDisplay = 'N/A';
  if (transaction.type === 'Transfer') {
    const fromName = transaction.fromcustomerid && transaction.fromcustomerid === transaction.cfrom_id
      ? transaction.fromcustomername
      : 'N/A';
    const toName = transaction.tocustomerid && transaction.tocustomerid === transaction.cto_id
      ? transaction.tocustomername
      : 'N/A';

    customerDisplay = `From: ${fromName} To: ${toName}`;
  } else {
    customerDisplay = transaction.customername || 'N/A';
  }

  const descriptionHeight = doc
    .fontSize(9)
    .font('Helvetica')
    .heightOfString(description, { width: 80 });
  const customerHeight = doc
    .fontSize(9)
    .font('Helvetica')
    .heightOfString(customerDisplay, { width: 80 });
  const rowHeight = Math.max(20, descriptionHeight + 10, customerHeight + 10);

  if (yPos + rowHeight > 680) {
    doc.addPage();
    yPos = 60;
    yPos = drawTableHeader();
  }

  const rowColor = index % 2 === 0 ? '#ffffff' : '#f0f0f0';
  doc
    .rect(40, yPos, 515, rowHeight)
    .fill(rowColor)
    .fillColor('#2c3e50')
    .fontSize(9)
    .font('Helvetica');

  doc.text(transaction.type.substring(0, 10), 50, yPos + 10);
  doc.text(description.substring(0, 25), 150, yPos + 10, { width: 80 });
  doc.text((transaction.bank || 'N/A').substring(0, 10), 290, yPos + 10);
  doc.text(customerDisplay.substring(0, 25), 350, yPos + 10, { width: 80 });
  doc.text(
    `${currencySymbol} ${(parseFloat(transaction.amount) || 0).toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`,
    430, yPos + 10,
    { width: 80, align: 'right' }
  );

  const status = transaction.status.toLowerCase();
  let statusColor = '#2c3e50';
  if (status === 'completed') statusColor = '#27ae60';
  else if (status === 'cancelled') statusColor = '#e74c3c';
  else if (status === 'pending') statusColor = '#f39c12';

  doc.fillColor(statusColor).text(status, 520, yPos + 10);

  yPos += rowHeight;
});
    // Ensure room for footer
    if (yPos + 134 > 680) {
      doc.addPage();
      yPos = 60;
    }

    yPos += 30;

    const addFooter = (pageIndex) => {
      try {
        doc.switchToPage(pageIndex);
      } catch (e) {
        // switchToPage may throw if bufferPages false; fallback: set the y for current page
      }
      doc
        .fontSize(9)
        .fillColor('#7f8c8d')
        .font('Helvetica')
       .text(
           'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
         40,
          750,
          { align: 'center', width: 515 }
        );
    };

    // Add footers to existing pages
    const range = doc.bufferedPageRange ? doc.bufferedPageRange() : { start: 0, count: 1 };
    const pageCount = range.count || 1;
    for (let i = 0; i < pageCount; i++) {
      addFooter(i);
    }

    // Add footer on future pages as they are added
    doc.on('pageAdded', () => {
      const idx = (doc.bufferedPageRange && doc.bufferedPageRange().count - 1) || 0;
      addFooter(idx);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating finance PDF:', error);

    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate finance PDF report',
        message: error.message || String(error),
        timestamp: new Date().toISOString()
      });
    }

    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};


module.exports = {
  getAllTransactions,
  getTransactionById,
  createTransaction,
  updateTransaction,
  deleteTransaction,
  getBalance,
  getTransactionsByStatus,
  getEnumOptions,
  getAllCustomers,
  downloadFinancePDF,
};