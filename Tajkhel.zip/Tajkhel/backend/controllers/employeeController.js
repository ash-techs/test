const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

const validDepartments = ['IT', 'HR', 'Finance', 'Marketing', 'Sales'];
const validStatuses = ['Active', 'Inactive'];

// Get all employees
const getAllEmployees = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = 'SELECT id, name, employee_id, department, position, salary, hire_date, email, website, status, "created_at", "updated_at" FROM employees';
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY "created_at" DESC';

    const result = await pool.query(query, values);
    const employees = result.rows.map((emp) => ({
      id: emp.id,
      name: emp.name,
      employeeId: emp.employee_id,
      department: emp.department,
      position: emp.position,
      salary: parseFloat(emp.salary) || 0,
      hireDate: emp.hire_date|| null,
      email: emp.email,
      website: emp.website || '',
      status: emp.status || 'Active',
      created_at: emp.created_at ? emp.created_at.toISOString() : null,
      updated_at: emp.updated_at ? emp.updated_at.toISOString() : null,
    }));
    res.json(employees);
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Failed to fetch employees', details: error.message });
  }
};

// Search employees
const searchEmployees = async (req, res) => {
  try {
    const { search, dateRange } = req.query;
    let query = 'SELECT id, name, employee_id, department, position, salary, hire_date, email, website, status, "created_at", "updated_at" FROM employees';
    let params = [];

    if (search || dateRange) {
      query += ' WHERE';
      let conditions = [];

      if (search) {
        conditions.push('name ILIKE $1 OR employee_id ILIKE $1 OR department ILIKE $1');
        params.push(`%${search}%`);
      }

      if (dateRange) {
        let days;
        switch (dateRange) {
          case '7d':
            days = 7;
            break;
          case '14d':
            days = 14;
            break;
          case '30d':
            days = 30;
            break;
          default:
            days = 7;
        }
        const index = params.length + 1;
        conditions.push(`COALESCE("updated_at", "created_at") >= CURRENT_DATE - INTERVAL $${index}`);
        params.push(`${days} days`);
      }

      query += ' ' + conditions.join(' AND ');
    }
    query += ' ORDER BY "created_at" DESC';

    const result = await pool.query(query, params);
    const employees = result.rows.map((emp) => ({
      id: emp.id,
      name: emp.name,
      employeeId: emp.employee_id,
      department: emp.department,
      position: emp.position,
      salary: parseFloat(emp.salary) || 0,
      hireDate: emp.hire_date ? emp.hire_date.toISOString() : null,
      email: emp.email,
      website: emp.website || '',
      status: emp.status || 'Active',
      created_at: emp.created_at ? emp.created_at.toISOString() : null,
      updated_at: emp.updated_at ? emp.updated_at.toISOString() : null,
    }));
    res.json(employees);
  } catch (error) {
    console.error('Error searching employees:', error);
    res.status(500).json({ error: 'Failed to search employees', details: error.message });
  }
};

// Get employee by ID
const getEmployeeById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT id, name, employee_id, department, position, salary, hire_date, email, website, status, "created_at", "updated_at" FROM employees WHERE id = $1',
      [parseInt(id)]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const emp = result.rows[0];
    res.json({
      id: emp.id,
      name: emp.name,
      employeeId: emp.employee_id,
      department: emp.department,
      position: emp.position,
      salary: parseFloat(emp.salary) || 0,
      hireDate: emp.hire_date ? emp.hire_date.toISOString() : null,
      email: emp.email,
      website: emp.website || '',
      status: emp.status || 'Active',
      created_at: emp.created_at ? emp.created_at.toISOString() : null,
      updated_at: emp.updated_at ? emp.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error fetching employee:', error);
    res.status(500).json({ error: 'Failed to fetch employee', details: error.message });
  }
};

// Create employee
const createEmployee = async (req, res) => {
  try {
    const { name, employeeId, department, position, salary, hireDate, email, website, status } = req.body;

    if (!name || !employeeId || !department || !email) {
      return res.status(400).json({ error: 'Name, employee ID, department, and email are required' });
    }

    if (!validDepartments.includes(department)) {
      return res.status(400).json({ error: `Invalid department. Valid options: ${validDepartments.join(', ')}` });
    }

    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid options: ${validStatuses.join(', ')}` });
    }

    if (isNaN(parseFloat(salary)) || parseFloat(salary) < 0) {
      return res.status(400).json({ error: 'Salary must be a valid non-negative number' });
    }

    if (hireDate && isNaN(Date.parse(hireDate))) {
      return res.status(400).json({ error: 'Invalid hire date' });
    }

    if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    if (website && !/^https?:\/\/.+\..+/.test(website)) {
      return res.status(400).json({ error: 'Invalid website URL' });
    }

    const existing = await pool.query('SELECT * FROM employees WHERE employee_id = $1 OR email = $1', [employeeId]);
    if (existing.rows.length > 0) {
      return res.status(400).json({ error: 'Employee ID or email already exists' });
    }

    const now = new Date();
    const result = await pool.query(
      `INSERT INTO employees (name, employee_id, department, position, salary, hire_date, email, website, status, "created_at", "updated_at")
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [
        name,
        employeeId,
        department,
        position || null,
        parseFloat(salary) || 0,
        hireDate ? new Date(hireDate) : null,
        email,
        website || null,
        status || 'Active',
        now,
        now,
      ]
    );

    const emp = result.rows[0];
    res.status(201).json({
      id: emp.id,
      name: emp.name,
      employeeId: emp.employee_id,
      department: emp.department,
      position: emp.position,
      salary: parseFloat(emp.salary) || 0,
      hireDate: emp.hire_date,
      email: emp.email,
      website: emp.website || '',
      status: emp.status || 'Active',
      created_at: emp.created_at ? emp.created_at.toISOString() : null,
      updated_at: emp.updated_at ? emp.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error creating employee:', error);
    res.status(500).json({ error: 'Failed to create employee', details: error.message });
  }
};

// Update employee
const updateEmployee = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, employeeId, department, position, salary, hireDate, email, website, status } = req.body;

    const existing = await pool.query('SELECT * FROM employees WHERE id = $1', [parseInt(id)]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    if (employeeId && employeeId !== existing.rows[0].employee_id) {
      const idCheck = await pool.query('SELECT * FROM employees WHERE employee_id = $1 AND id != $2', [employeeId, parseInt(id)]);
      if (idCheck.rows.length > 0) {
        return res.status(400).json({ error: 'Employee ID already exists' });
      }
    }

    if (email && email !== existing.rows[0].email) {
      const emailCheck = await pool.query('SELECT * FROM employees WHERE email = $1 AND id != $2', [email, parseInt(id)]);
      if (emailCheck.rows.length > 0) {
        return res.status(400).json({ error: 'Email already exists' });
      }
    }

    if (department && !validDepartments.includes(department)) {
      return res.status(400).json({ error: `Invalid department. Valid options: ${validDepartments.join(', ')}` });
    }

    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Valid options: ${validStatuses.join(', ')}` });
    }

    if (salary && (isNaN(parseFloat(salary)) || parseFloat(salary) < 0)) {
      return res.status(400).json({ error: 'Salary must be a valid non-negative number' });
    }

    if (hireDate && isNaN(Date.parse(hireDate))) {
      return res.status(400).json({ error: 'Invalid hire date' });
    }

    if (email && !/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }

    if (website && !/^https?:\/\/.+\..+/.test(website)) {
      return res.status(400).json({ error: 'Invalid website URL' });
    }

    const data = {
      ...(name && { name }),
      ...(employeeId && { employee_id: employeeId }),
      ...(department && { department }),
      ...(position && { position }),
      ...(salary && { salary: parseFloat(salary) }),
      ...(hireDate && { hire_date: hireDate }),
      ...(email && { email }),
      ...(website !== undefined && { website: website || null }),
      ...(status && { status }),
      updated_at: new Date(),
    };

    const fields = Object.keys(data).map((key, index) => `"${key}" = $${index + 1}`);
    const values = Object.values(data);

    if (fields.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    const result = await pool.query(
      `UPDATE employees SET ${fields.join(', ')} WHERE id = $${fields.length + 1} RETURNING *`,
      [...values, parseInt(id)]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    const emp = result.rows[0];
    res.json({
      id: emp.id,
      name: emp.name,
      employeeId: emp.employee_id,
      department: emp.department,
      position: emp.position,
      salary: parseFloat(emp.salary) || 0,
      hireDate: emp.hire_date || null,
      email: emp.email,
      website: emp.website || '',
      status: emp.status || 'Active',
      created_at: emp.created_at ? emp.created_at.toISOString() : null,
      updated_at: emp.updated_at ? emp.updated_at.toISOString() : null,
    });
  } catch (error) {
    console.error('Error updating employee:', error);
    res.status(500).json({ error: 'Failed to update employee', details: error.message });
  }
};

// Delete employee
const deleteEmployee = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query('DELETE FROM employees WHERE id = $1 RETURNING *', [parseInt(id)]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Error deleting employee:', error);
    res.status(500).json({ error: 'Failed to delete employee', details: error.message });
  }
};

module.exports = {
  getAllEmployees,
  searchEmployees,
  getEmployeeById,
  createEmployee,
  updateEmployee,
  deleteEmployee,
};