const { Pool } = require('pg');
const PDFDocument = require('pdfkit');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Status mappings aligned with frontend
const STATUS_MAP = {
  draft: 'DRAFT',
  pending: 'PENDING',
  unpaid: 'UNPAID',
  overdue: 'OVERDUE',
  partially_paid: 'PARTIALLY_PAID',
  paid: 'PAID',
};

const STATUS_MAP_REVERSE = Object.fromEntries(
  Object.entries(STATUS_MAP).map(([key, value]) => [value, key])
);

const VALID_STATUSES = Object.keys(STATUS_MAP);

const mapStatusToEnum = (status) => {
  if (!status || !VALID_STATUSES.includes(status.toLowerCase())) {
    throw new Error(`Invalid status. Valid options: ${VALID_STATUSES.join(', ')}`);
  }
  return STATUS_MAP[status.toLowerCase()];
};

const mapStatusFromEnum = (status) => {
  return STATUS_MAP_REVERSE[status] || 'draft';
};

const getDiscountPercentage = (discount) => {
  switch (discount) {
    case 'FIVE_PERCENT': return 0.05;
    case 'TEN_PERCENT': return 0.10;
    case 'FIFTEEN_PERCENT': return 0.15;
    default: return 0;
  }
};

const validateInvoiceInput = (data) => {
  const errors = [];

  if (!data.number || data.number.trim() === '') {
    errors.push('Invoice number is required');
  }

  if (!data.customer || data.customer.trim() === '') {
    errors.push('Customer is required');
  }

  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Invalid email format');
  }

  if (!data.address || data.address.trim() === '') {
    errors.push('Address is required');
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone is required');
  }

  if (!data.date || isNaN(Date.parse(data.date))) {
    errors.push('Valid date is required');
  }

  if (!data.expireDate || isNaN(Date.parse(data.expireDate))) {
    errors.push('Valid expire date is required');
  }

  if (data.date && data.expireDate && 
      Date.parse(data.date) && Date.parse(data.expireDate) &&
      new Date(data.expireDate) <= new Date(data.date)) {
    errors.push('Expire date must be after invoice date');
  }

  if (data.year && (isNaN(parseInt(data.year)) || parseInt(data.year) < 2000 || parseInt(data.year) > 2100)) {
    errors.push('Year must be a valid year between 2000 and 2100');
  }

  if (data.status && !VALID_STATUSES.includes(data.status.toLowerCase())) {
    errors.push(`Invalid status. Valid options: ${VALID_STATUSES.join(', ')}`);
  }

  if (data.paid && (isNaN(parseFloat(data.paid)) || parseFloat(data.paid) < 0)) {
    errors.push('Paid amount must be a valid positive number');
  }

  if (data.tax && (isNaN(parseFloat(data.tax)) || parseFloat(data.tax) < 0)) {
    errors.push('Tax must be a valid positive number');
  }

  if (!data.items || !Array.isArray(data.items) || data.items.length === 0) {
    errors.push('At least one invoice item is required');
  } else {
    data.items.forEach((item, index) => {
      if (!item.productId) {
        errors.push(`Product ID is required for item ${index + 1}`);
      }
      if (!item.weight || isNaN(parseFloat(item.weight)) || parseFloat(item.weight) <= 0) {
        errors.push(`Valid weight (greater than 0) is required for item ${index + 1}`);
      }
      if (!item.balanceUnits || isNaN(parseInt(item.balanceUnits)) || parseInt(item.balanceUnits) <= 0) {
        errors.push(`Valid balance units (greater than 0) is required for item ${index + 1}`);
      }
      if (!item.unitPrice || isNaN(parseFloat(item.unitPrice)) || parseFloat(item.unitPrice) <= 0) {
        errors.push(`Valid unit price (greater than 0) is required for item ${index + 1}`);
      }
    });
  }

  return errors;
};

const getAllInvoices = async (req, res) => {
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT *
      FROM invoices
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d':
          days = 7;
          break;
        case '14d':
          days = 14;
          break;
        case '30d':
          days = 30;
          break;
        default:
          days = 7;
      }
      query += ` WHERE COALESCE("updatedAt", "createdAt") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY "createdAt" DESC';

    const invoicesResult = await pool.query(query, values);
    const invoiceIds = invoicesResult.rows.map(i => i.id);
    const itemsResult = await pool.query(`
      SELECT ii.*, p.lot, p.fileno 
      FROM invoice_items ii
      JOIN products p ON ii.product_id = p.id
      WHERE ii."invoiceId" = ANY($1)
    `, [invoiceIds]);

    const transformedInvoices = invoicesResult.rows.map((invoice) => {
      const items = itemsResult.rows
        .filter(item => item.invoiceId === invoice.id)
        .map(item => ({
          id: item.id.toString(),
          productId: parseInt(item.product_id),
          productName: item.product_name || `Product #${item.product_id}`,
          productLot: item.lot,
          productFileno: item.fileno,
          weight: parseFloat(item.weight),
          balanceUnits: parseInt(item.balance_units),
          balanceWeight: parseFloat(item.balance_weight),
          unitPrice: parseFloat(item.unit_price),
          discount: item.discount,
          amount: parseFloat(item.amount),
        }));

      const subtotal = items.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
      const discountAmount = items.reduce((sum, item) => sum + ((item.weight * item.balanceUnits / 45) * item.unitPrice * getDiscountPercentage(item.discount)), 0);
      const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
      const total = subtotal - discountAmount + taxAmount;

      return {
        id: invoice.id.toString(),
        number: invoice.number,
        customer: invoice.customer,
        email: invoice.email || '',
        address: invoice.address,
        phone: invoice.phone,
        date: invoice.date.toISOString().split('T')[0],
        expireDate: invoice.expiredate.toISOString().split('T')[0],
        year: invoice.year.toString(),
        currency: invoice.currency || 'PKR',
        status: mapStatusFromEnum(invoice.status),
        paid: parseFloat(invoice.paid) || 0,
        note: invoice.note || '',
        tax: parseFloat(invoice.tax) || 0,
        createdBy: invoice.createdBy || 'Admin',
        createdAt: invoice.createdAt ? invoice.createdAt.toISOString() : null,
        updatedAt: invoice.updatedAt ? invoice.updatedAt.toISOString() : null,
        items,
        total,
      };
    });

    res.json(transformedInvoices);
  } catch (error) {
    console.error('Error fetching invoices:', error);
    res.status(500).json({ error: 'Failed to fetch invoices', details: error.message });
  }
};

const getInvoiceById = async (req, res) => {
  try {
    const { id } = req.params;
    const invoiceResult = await pool.query('SELECT * FROM invoices WHERE id = $1', [parseInt(id)]);
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const itemsResult = await pool.query(`
      SELECT ii.*, p.lot, p.fileno 
      FROM invoice_items ii
      JOIN products p ON ii.product_id = p.id
      WHERE ii."invoiceId" = $1
    `, [parseInt(id)]);

    const invoice = invoiceResult.rows[0];
    const items = itemsResult.rows.map(item => ({
      id: item.id.toString(),
      productId: parseInt(item.product_id),
      productName: item.product_name || `Product #${item.product_id}`,
      productLot: item.lot,
      productFileno: item.fileno,
      weight: parseFloat(item.weight),
      balanceUnits: parseInt(item.balance_units),
      balanceWeight: parseFloat(item.balance_weight),
      unitPrice: parseFloat(item.unit_price),
      discount: item.discount,
      amount: parseFloat(item.amount),
    }));

    const subtotal = items.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
    const discountAmount = items.reduce((sum, item) => sum + ((item.weight * item.balanceUnits / 45) * item.unitPrice * getDiscountPercentage(item.discount)), 0);
    const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
    const total = subtotal - discountAmount + taxAmount;

    res.json({
      id: invoice.id.toString(),
      number: invoice.number,
      customer: invoice.customer,
      email: invoice.email || '',
      address: invoice.address,
      phone: invoice.phone,
      date: invoice.date.toISOString().split('T')[0],
      expireDate: invoice.expiredate.toISOString().split('T')[0],
      year: invoice.year.toString(),
      currency: invoice.currency || 'PKR',
      status: mapStatusFromEnum(invoice.status),
      paid: parseFloat(invoice.paid) || 0,
      note: invoice.note || '',
      tax: parseFloat(invoice.tax) || 0,
      createdBy: invoice.createdBy || 'Admin',
      createdAt: invoice.createdAt ? invoice.createdAt.toISOString() : null,
      updatedAt: invoice.updatedAt ? invoice.updatedAt.toISOString() : null,
      items,
      total,
    });
  } catch (error) {
    console.error('Error fetching invoice:', error);
    res.status(500).json({ error: 'Failed to fetch invoice', details: error.message });
  }
};

const createInvoice = async (req, res) => {
  const client = await pool.connect();
  try {
    const {
      number, customer, email, address, phone, date, expireDate, year, currency,
      status = 'draft', paid, note, tax, createdBy, items,
    } = req.body;

    // Early validation to ensure items is defined and an array
    if (!items || !Array.isArray(items)) {
      return res.status(400).json({ error: 'Validation failed', details: ['Items must be a non-empty array'] });
    }

    const errors = validateInvoiceInput(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }

    await client.query('BEGIN');
    try {
      const existingInvoice = await client.query('SELECT * FROM invoices WHERE number = $1', [number]);
      if (existingInvoice.rows.length > 0) {
        throw new Error('Invoice number already exists');
      }

      const invoiceResult = await client.query(
        `INSERT INTO invoices (
          number, customer, email, address, phone, date, "expiredate", 
          year, currency, status, paid, note, tax, "createdBy", "createdAt", "updatedAt"
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16) RETURNING *`,
        [
          number, customer, email || null, address, phone, new Date(date), new Date(expireDate),
          parseInt(year) || new Date().getFullYear(), currency || 'PKR', mapStatusToEnum(status),
          parseFloat(paid) || 0, note || null, parseFloat(tax) || 0, createdBy || 'Admin',
          new Date(), new Date(),
        ]
      );

      const invoiceId = invoiceResult.rows[0].id;

      for (const item of items) {
        const productResult = await client.query(
          'SELECT id, lot, fileno, balance_unit, balance_weight, weight FROM products WHERE id = $1',
          [item.productId]
        );
        if (productResult.rows.length === 0) {
          throw new Error(`Product not found for ID ${item.productId}`);
        }
        const product = productResult.rows[0];
        if (item.balanceUnits > product.balance_unit) {
          throw new Error(`Balance units (${item.balanceUnits}) exceed available units (${product.balance_unit}) for product ${item.productId}`);
        }

        // Use product's weight if not provided in item
        const weight = parseFloat(item.weight) || parseFloat(product.weight);
        const balanceWeight = weight * item.balanceUnits;
        const baseAmount = (weight * item.balanceUnits / 45) * item.unitPrice;
        const discountPercentage = getDiscountPercentage(item.discount || 'NO_DISCOUNT');
        const amount = baseAmount * (1 - discountPercentage);

        await client.query(
          `INSERT INTO invoice_items (
            "invoiceId", product_id, product_name, product_lot, product_fileno, 
            weight, balance_units, balance_weight, unit_price, discount, amount
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
          [
            invoiceId, item.productId, item.productName || `Product #${item.productId}`, 
            product.lot, product.fileno, weight, item.balanceUnits, balanceWeight, 
            item.unitPrice, item.discount || 'NO_DISCOUNT', amount,
          ]
        );

        if (mapStatusToEnum(status) === 'PAID') {
          const newBalanceUnit = product.balance_unit - item.balanceUnits;
          const newBalanceWeight = product.balance_weight - balanceWeight;
          await client.query(
            'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
            [newBalanceUnit, newBalanceWeight, item.productId]
          );
        }
      }

      await client.query('COMMIT');

      const itemsResult = await client.query(`
        SELECT ii.*, p.lot, p.fileno 
        FROM invoice_items ii
        JOIN products p ON ii.product_id = p.id
        WHERE ii."invoiceId" = $1
      `, [invoiceId]);
      const invoice = invoiceResult.rows[0];

      const mappedItems = itemsResult.rows.map(item => ({
        id: item.id.toString(),
        productId: parseInt(item.product_id),
        productName: item.product_name || `Product #${item.product_id}`,
        productLot: item.lot,
        productFileno: item.fileno,
        weight: parseFloat(item.weight),
        balanceUnits: parseInt(item.balance_units),
        balanceWeight: parseFloat(item.balance_weight),
        unitPrice: parseFloat(item.unit_price),
        discount: item.discount,
        amount: parseFloat(item.amount),
      }));

      const subtotal = mappedItems.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
      const discountAmount = mappedItems.reduce((sum, item) => sum + ((item.weight * item.balanceUnits / 45) * item.unitPrice * getDiscountPercentage(item.discount)), 0);
      const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
      const total = subtotal - discountAmount + taxAmount;

      res.status(201).json({
        id: invoice.id.toString(),
        number: invoice.number,
        customer: invoice.customer,
        email: invoice.email || '',
        address: invoice.address,
        phone: invoice.phone,
        date: invoice.date.toISOString().split('T')[0],
        expireDate: invoice.expiredate.toISOString().split('T')[0],
        year: invoice.year.toString(),
        currency: invoice.currency || 'PKR',
        status: mapStatusFromEnum(invoice.status),
        paid: parseFloat(invoice.paid) || 0,
        note: invoice.note || '',
        tax: parseFloat(invoice.tax) || 0,
        createdBy: invoice.createdBy || 'Admin',
        createdAt: invoice.createdAt ? invoice.createdAt.toISOString() : null,
        updatedAt: invoice.updatedAt ? invoice.updatedAt.toISOString() : null,
        items: mappedItems,
        total,
      });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error creating invoice:', error);
    res.status(500).json({ error: 'Failed to create invoice', details: error.message });
  } finally {
    client.release();
  }
};
const updateInvoice = async (req, res) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const {
      number, customer, email, address, phone, date, expireDate, year, currency,
      status, paid, note, tax, createdBy, items,
    } = req.body;

    // Early validation to ensure items is defined and an array
    if (!items || !Array.isArray(items)) {
      return res.status(400).json({ error: 'Validation failed', details: ['Items must be a non-empty array'] });
    }

    const errors = validateInvoiceInput(req.body);
    if (errors.length > 0) {
      return res.status(400).json({ error: 'Validation failed', details: errors });
    }

    await client.query('BEGIN');
    try {
      // Check if invoice exists
      const existingInvoice = await client.query('SELECT * FROM invoices WHERE id = $1', [parseInt(id)]);
      if (existingInvoice.rows.length === 0) {
        throw new Error('Invoice not found');
      }

      // Check for duplicate invoice number (excluding the current invoice)
      const duplicateInvoice = await client.query(
        'SELECT * FROM invoices WHERE number = $1 AND id != $2',
        [number, parseInt(id)]
      );
      if (duplicateInvoice.rows.length > 0) {
        throw new Error('Invoice number already exists');
      }

      // If the existing invoice was PAID, restore product quantities
      if (existingInvoice.rows[0].status === 'PAID') {
        const oldItems = await client.query('SELECT * FROM invoice_items WHERE "invoiceId" = $1', [parseInt(id)]);
        for (const item of oldItems.rows) {
          const productResult = await client.query(
            'SELECT balance_unit, balance_weight FROM products WHERE id = $1',
            [item.product_id]
          );
          if (productResult.rows.length > 0) {
            const product = productResult.rows[0];
            const newBalanceUnit = product.balance_unit + parseInt(item.balance_units);
            const newBalanceWeight = product.balance_weight + parseFloat(item.balance_weight);
            await client.query(
              'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
              [newBalanceUnit, newBalanceWeight, item.product_id]
            );
          }
        }
      }

      // Update the invoice
      const invoiceResult = await client.query(
        `UPDATE invoices SET
          number = $1, customer = $2, email = $3, address = $4, phone = $5, date = $6, "expiredate" = $7,
          year = $8, currency = $9, status = $10, paid = $11, note = $12, tax = $13, "createdBy" = $14, "updatedAt" = $15
         WHERE id = $16 RETURNING *`,
        [
          number, customer, email || null, address, phone, new Date(date), new Date(expireDate),
          parseInt(year), currency || 'PKR', mapStatusToEnum(status), parseFloat(paid) || 0, note || null,
          parseFloat(tax) || 0, createdBy || 'Admin', new Date(), parseInt(id),
        ]
      );

      // Delete existing invoice items
      await client.query('DELETE FROM invoice_items WHERE "invoiceId" = $1', [parseInt(id)]);

      // Insert updated invoice items
      for (const item of items) {
        const productResult = await client.query(
          'SELECT id, lot, fileno, balance_unit, balance_weight, weight FROM products WHERE id = $1',
          [item.productId]
        );
        if (productResult.rows.length === 0) {
          throw new Error(`Product not found for ID ${item.productId}`);
        }
        const product = productResult.rows[0];
        if (item.balanceUnits > product.balance_unit) {
          throw new Error(`Balance units (${item.balanceUnits}) exceed available units (${product.balance_unit}) for product ${item.productId}`);
        }

        // Use product's weight if not provided in item
        const weight = parseFloat(item.weight) || parseFloat(product.weight);
        const balanceWeight = weight * item.balanceUnits;
        const baseAmount = (weight * item.balanceUnits / 45) * item.unitPrice;
        const discountPercentage = getDiscountPercentage(item.discount || 'NO_DISCOUNT');
        const amount = baseAmount * (1 - discountPercentage);

        await client.query(
          `INSERT INTO invoice_items (
            "invoiceId", product_id, product_name, product_lot, product_fileno, 
            weight, balance_units, balance_weight, unit_price, discount, amount
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
          [
            parseInt(id), item.productId, item.productName || `Product #${item.productId}`, 
            product.lot, product.fileno, weight, item.balanceUnits, balanceWeight, 
            item.unitPrice, item.discount || 'NO_DISCOUNT', amount,
          ]
        );

        // If the new status is PAID, deduct product quantities
        if (mapStatusToEnum(status) === 'PAID') {
          const newBalanceUnit = product.balance_unit - item.balanceUnits;
          const newBalanceWeight = product.balance_weight - balanceWeight;
          await client.query(
            'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
            [newBalanceUnit, newBalanceWeight, item.productId]
          );
        }
      }

      await client.query('COMMIT');

      // Fetch updated invoice items
      const itemsResult = await client.query(`
        SELECT ii.*, p.lot, p.fileno 
        FROM invoice_items ii
        JOIN products p ON ii.product_id = p.id
        WHERE ii."invoiceId" = $1
      `, [parseInt(id)]);
      const invoice = invoiceResult.rows[0];

      // Map items for response
      const mappedItems = itemsResult.rows.map(item => ({
        id: item.id.toString(),
        productId: parseInt(item.product_id),
        productName: item.product_name || `Product #${item.product_id}`,
        productLot: item.lot,
        productFileno: item.fileno,
        weight: parseFloat(item.weight),
        balanceUnits: parseInt(item.balance_units),
        balanceWeight: parseFloat(item.balance_weight),
        unitPrice: parseFloat(item.unit_price),
        discount: item.discount,
        amount: parseFloat(item.amount),
      }));

      // Calculate totals
      const subtotal = mappedItems.reduce((sum, item) => sum + (item.weight * item.balanceUnits / 45) * item.unitPrice, 0);
      const discountAmount = mappedItems.reduce((sum, item) => sum + ((item.weight * item.balanceUnits / 45) * item.unitPrice * getDiscountPercentage(item.discount)), 0);
      const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
      const total = subtotal - discountAmount + taxAmount;

      // Return updated invoice
      res.json({
        id: invoice.id.toString(),
        number: invoice.number,
        customer: invoice.customer,
        email: invoice.email || '',
        address: invoice.address,
        phone: invoice.phone,
        date: invoice.date.toISOString().split('T')[0],
        expireDate: invoice.expiredate.toISOString().split('T')[0],
        year: invoice.year.toString(),
        currency: invoice.currency || 'PKR',
        status: mapStatusFromEnum(invoice.status),
        paid: parseFloat(invoice.paid) || 0,
        note: invoice.note || '',
        tax: parseFloat(invoice.tax) || 0,
        createdBy: invoice.createdBy || 'Admin',
        createdAt: invoice.createdAt ? invoice.createdAt.toISOString() : null,
        updatedAt: invoice.updatedAt ? invoice.updatedAt.toISOString() : null,
        items: mappedItems,
        total,
      });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }
  } catch (error) {
    console.error('Error updating invoice:', error);
    res.status(500).json({ error: 'Failed to update invoice', details: error.message });
  } finally {
    client.release();
  }
};
const deleteInvoice = async (req, res) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    await client.query('BEGIN');

    const invoiceResult = await client.query('SELECT * FROM invoices WHERE id = $1', [parseInt(id)]);
    if (invoiceResult.rows.length === 0) {
      throw new Error('Invoice not found');
    }

    if (invoiceResult.rows[0].status === 'PAID') {
      const itemsResult = await client.query('SELECT * FROM invoice_items WHERE "invoiceId" = $1', [parseInt(id)]);
      for (const item of itemsResult.rows) {
        const productResult = await client.query(
          'SELECT balance_unit, balance_weight FROM products WHERE id = $1',
          [item.product_id]
        );
        if (productResult.rows.length > 0) {
          const product = productResult.rows[0];
          const newBalanceUnit = product.balance_unit + parseInt(item.balance_units);
          const newBalanceWeight = product.balance_weight + parseFloat(item.balance_weight);
          await client.query(
            'UPDATE products SET balance_unit = $1, balance_weight = $2, updated_at = CURRENT_TIMESTAMP WHERE id = $3',
            [newBalanceUnit, newBalanceWeight, item.product_id]
          );
        }
      }
    }

    await client.query('DELETE FROM invoice_items WHERE "invoiceId" = $1', [parseInt(id)]);
    await client.query('DELETE FROM invoices WHERE id = $1', [parseInt(id)]);
    await client.query('COMMIT');

    res.status(200).json({ message: 'Invoice deleted successfully' });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error deleting invoice:', error);
    res.status(500).json({ error: 'Failed to delete invoice', details: error.message });
  } finally {
    client.release();
  }
};

const downloadInvoicesPDF = async (req, res) => {
  let doc;
  try {
    const { dateRange } = req.query;
    let query = `
      SELECT i.*, 
             (SELECT SUM(ii.amount) FROM invoice_items ii WHERE ii."invoiceId" = i.id) as total
      FROM invoices i
    `;
    const values = [];

    if (dateRange) {
      let days;
      switch (dateRange) {
        case '7d': days = 7; break;
        case '14d': days = 14; break;
        case '30d': days = 30; break;
        default: days = 7;
      }
      query += ` WHERE COALESCE(i."updatedAt", i."createdAt") >= CURRENT_DATE - INTERVAL $1`;
      values.push(`${days} days`);
    }
    query += ' ORDER BY i.currency, i."createdAt" DESC';

    const invoicesResult = await pool.query(query, values);
    const invoiceIds = invoicesResult.rows.map(i => i.id);
    const itemsResult = await pool.query(`
      SELECT ii.*, p.lot, p.fileno 
      FROM invoice_items ii
      JOIN products p ON ii.product_id = p.id
      WHERE ii."invoiceId" = ANY($1)
    `, [invoiceIds]);

    doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      layout: 'landscape',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="invoices-report.pdf"');

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    const drawHeader = () => {

      doc
        .fontSize(20)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 40, 30)
        .fontSize(10)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Invoice Summary Report', 40, 50)
        .text(`Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', month: 'long', day: 'numeric' })}`, 40, 65);

      doc
        .moveTo(40, 85)
        .lineTo(800, 85)
        .strokeColor('#3498db')
        .lineWidth(1)
        .stroke();
    };

    const addFixedFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(8)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
          'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',  
          40, 520, { align: 'left', width: 760 }
        );
    };

    drawHeader();

    // Group invoices by currency
    const invoicesByCurrency = invoicesResult.rows.reduce((acc, invoice) => {
      const currency = invoice.currency || 'PKR';
      if (!acc[currency]) acc[currency] = [];
      acc[currency].push(invoice);
      return acc;
    }, {});

    let yPos = 100;

    // Summary statistics for each currency
    Object.keys(invoicesByCurrency).forEach((currency, currencyIndex) => {
      const invoices = invoicesByCurrency[currency];
      const totalInvoices = invoices.length;
      const totalAmount = invoices.reduce((sum, invoice) => sum + (parseFloat(invoice.total) || 0), 0);
      const statusCounts = invoices.reduce((acc, invoice) => {
        const status = mapStatusFromEnum(invoice.status);
        acc[status] = (acc[status] || 0) + 1;
        return acc;
      }, {});

      if (yPos + 80 > 500) {
        doc.addPage();
        drawHeader();
        yPos = 100;
      }

      doc
        .rect(40, yPos, 760, 60)
        .fillAndStroke('#f5f6f5', '#d1d5db')
        .fillColor('#1f2937')
        .fontSize(12)
        .font('Helvetica-Bold')
        .text(`${currency} Summary Statistics`, 45, yPos + 10)
        .fontSize(10)
        .font('Helvetica')
        .text(`Total Invoices: ${totalInvoices}`, 45, yPos + 25)
        .text(`Total Amount: ${currency} ${totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, 45, yPos + 40)
        .text(`Average Amount: ${currency} ${totalInvoices > 0 ? (totalAmount / totalInvoices).toFixed(2) : '0.00'}`, 400, yPos + 25);

      yPos += 70;

      doc
        .fontSize(11)
        .fillColor('#1f2937')
        .font('Helvetica-Bold')
        .text(`${currency} Status Breakdown:`, 40, yPos);

      yPos += 20;
      let statusX = 45;
      let statusY = yPos;

      Object.keys(statusCounts).forEach((status, index) => {
        const count = statusCounts[status] || 0;
        const percentage = totalInvoices > 0 ? ((count / totalInvoices) * 100).toFixed(1) : '0.0';
        const statusText = `${status}: ${count} (${percentage}%)`;
        const statusHeight = doc
          .fontSize(9)
          .font('Helvetica')
          .heightOfString(statusText, { width: 100 });

        if (statusY + statusHeight > 500) {
          doc.addPage();
          drawHeader();
          statusY = 100;
          statusX = 45;
        }

        doc
          .fontSize(9)
          .fillColor('#374151')
          .font('Helvetica')
          .text(statusText, statusX, statusY);

        statusX += 110;
        if ((index + 1) % 6 === 0) {
          statusX = 45;
          statusY += statusHeight + 5;
        }
      });

      yPos = statusY + 30;

      const drawTableHeader = () => {
        if (yPos + 20 > 500) {
          doc.addPage();
          drawHeader();
          yPos = 100;
        }
        doc
          .rect(40, yPos, 760, 20)
          .fill('#1f2937')
          .fillColor('white')
          .fontSize(9)
          .font('Helvetica-Bold');

        doc.text('Invoice #', 45, yPos + 6, { width: 60 });
        doc.text('Customer', 105, yPos + 6, { width: 100 });
        doc.text('Date', 205, yPos + 6, { width: 60 });
        doc.text('Due Date', 265, yPos + 6, { width: 60 });
        doc.text('Status', 325, yPos + 6, { width: 60 });
        doc.text('Tax', 385, yPos + 6, { width: 50 });
        doc.text('Paid', 435, yPos + 6, { width: 50 });
        doc.text('Total', 485, yPos + 6, { width: 60 });
        doc.text('Outstanding', 545, yPos + 6, { width: 60 });

        yPos += 20;
        return yPos;
      };

      yPos = drawTableHeader();

      invoices.forEach((invoice, index) => {
        const invoiceItems = itemsResult.rows.filter(item => item.invoiceId === invoice.id);
        const subtotal = invoiceItems.reduce((sum, item) => sum + (item.weight * item.balance_units / 45) * item.unit_price, 0);
        const discountAmount = invoiceItems.reduce((sum, item) => sum + ((item.weight * item.balance_units / 45) * item.unit_price * getDiscountPercentage(item.discount)), 0);
        const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
        const total = subtotal - discountAmount + taxAmount;
        const outstanding = total - (parseFloat(invoice.paid) || 0);

        const customerName = invoice.customer || 'N/A';
        const customerHeight = doc
          .fontSize(8)
          .font('Helvetica')
          .heightOfString(customerName, { width: 100 });
        const rowHeight = Math.max(18, customerHeight + 8);

        if (yPos + rowHeight > 500) {
          doc.addPage();
          drawHeader();
          yPos = 100;
          yPos = drawTableHeader();
        }

        const rowColor = index % 2 === 0 ? '#ffffff' : '#f9fafb';
        doc
          .rect(40, yPos, 760, rowHeight)
          .fill(rowColor)
          .fillColor('#1f2937')
          .fontSize(8)
          .font('Helvetica');

        doc.text(invoice.number.substring(0, 15), 45, yPos + 5, { width: 60 });
        doc.text(customerName.substring(0, 25), 105, yPos + 5, { width: 100 });
        doc.text(
          invoice.date ?
            new Date(invoice.date).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: '2-digit' }) :
            'N/A',
          205, yPos + 5, { width: 60 }
        );
        doc.text(
          invoice.expiredate ?
            new Date(invoice.expiredate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: '2-digit' }) :
            'N/A',
          265, yPos + 5, { width: 60 }
        );

        const status = mapStatusFromEnum(invoice.status);
        let statusColor = '#1f2937';
        if (status === 'paid') statusColor = '#15803d';
        else if (status === 'overdue' || status === 'unpaid') statusColor = '#b91c1c';
        else if (status === 'pending' || status === 'partially_paid') statusColor = '#d97706';

        doc.fillColor(statusColor).text(status, 325, yPos + 5, { width: 60 });

        doc.fillColor('#1f2937').text(`${(parseFloat(invoice.tax) || 0).toFixed(2)}%`, 385, yPos + 5, { width: 50 });
        doc.text(
          `${currency} ${(parseFloat(invoice.paid) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          435, yPos + 5, { width: 50 }
        );
        doc.text(
          `${currency} ${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          485, yPos + 5, { width: 60 }
        );
        doc.text(
          `${currency} ${outstanding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          545, yPos + 5, { width: 60 }
        );

        yPos += rowHeight;
      });

      yPos += 20;
    });

    // Add signature line and totals
    if (yPos + 20 > 500) {
      doc.addPage();
      drawHeader();
      yPos = 100;
    }
    doc
      .fontSize(9)
      .fillColor('#6b7280')
      .font('Helvetica-Oblique')
      .text('This print is electronic, no signature required', 40, yPos, { align: 'left', width: 760 });

    yPos += 15;


    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFixedFooter(i);
    }

    doc.on('pageAdded', () => {
      drawHeader();
      addFixedFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating invoices PDF:', error, error.stack);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate invoices PDF report',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};

const downloadInvoicesPDFById = async (req, res) => {
  let doc;
  try {
    const { id } = req.params;
    const invoiceResult = await pool.query('SELECT * FROM invoices WHERE id = $1', [parseInt(id)]);
    if (invoiceResult.rows.length === 0) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const itemsResult = await pool.query(`
      SELECT ii.*, p.lot, p.fileno 
      FROM invoice_items ii
      JOIN products p ON ii.product_id = p.id
      WHERE ii."invoiceId" = $1
    `, [parseInt(id)]);

    const invoice = invoiceResult.rows[0];

    doc = new PDFDocument({
      margin: 40,
      size: 'A4',
      layout: 'landscape',
      bufferPages: true,
    });

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="invoice-${invoice.number}.pdf"`);

    doc.on('error', (err) => {
      console.error('PDF stream error:', err);
      if (!res.headersSent) {
        res.status(500).send('Failed to stream PDF');
      }
    });

    doc.pipe(res);

    const drawHeader = () => {
      const logoPath = path.join(__dirname, '..', 'assets', 'logo.jpeg');
      if (fs.existsSync(logoPath)) {
        doc.image(logoPath, 750, 28, { width: 50 });
      }

      doc
        .fontSize(20)
        .fillColor('#2c3e50')
        .font('Helvetica-Bold')
        .text('TAJKHEL TRADING COMPANY', 40, 30)
        .fontSize(10)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text('Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar', 40, 50)
        .text('Phone: +0912214610', 40, 65);

      doc
        .moveTo(40, 85)
        .lineTo(800, 85)
        .strokeColor('#3498db')
        .lineWidth(1)
        .stroke();
    };

    const addFixedFooter = (pageIndex) => {
      doc.switchToPage(pageIndex);
      doc
        .fontSize(8)
        .fillColor('#7f8c8d')
        .font('Helvetica')
        .text(
          'TAJKHEL TRADING COMPANY | Phone: +0912214610 | Office 19/A, Japan Market Qissa Khawani Bazar, Peshawar',
          40, 500, { align: 'left', width: 760 }
        );
    };

    drawHeader();

    let yPos = 100;

    doc
      .fontSize(16)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('INVOICE', 40, yPos)
      .fontSize(9)
      .font('Helvetica')
      .text(`Invoice #: ${invoice.number || invoice.id}`, 40, yPos + 15)
      .text(`Date: ${new Date(invoice.date).toLocaleDateString('en-US', { 
        year: 'numeric', month: 'long', day: 'numeric' })}`, 40, yPos + 30)
      .text(`Due Date: ${invoice.expiredate ? 
        new Date(invoice.expiredate).toLocaleDateString('en-US', { 
          year: 'numeric', month: 'short', day: 'numeric' }) : 'N/A'}`, 40, yPos + 45);

    yPos += 60;

    doc
      .fontSize(11)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Bill To:', 40, yPos);

    const customerDetails = [];
    if (invoice.customer) {
      customerDetails.push(invoice.customer);
      if (invoice.address) customerDetails.push(invoice.address);
      if (invoice.phone) customerDetails.push(`Phone: ${invoice.phone}`);
      if (invoice.email) customerDetails.push(`Email: ${invoice.email}`);
    } else {
      console.error('No customer data found for invoice:', invoice.id);
    }

    let customerYPos = yPos + 12;
    doc.fontSize(9).fillColor('#374151').font('Helvetica');
    customerDetails.forEach((detail, index) => {
      if (index === 0) {
        doc.font('Helvetica-Bold').fillColor('#2c3e50');
      } else {
        doc.font('Helvetica').fillColor('#374151');
      }
      const detailHeight = doc.heightOfString(detail, { width: 200 });
      if (customerYPos + detailHeight > 500) {
        doc.addPage();
        drawHeader();
        customerYPos = 100;
      }
      doc.text(detail, 40, customerYPos);
      customerYPos += detailHeight + 4;
    });

    let paymentYPos = yPos;
    doc
      .fontSize(11)
      .fillColor('#2c3e50')
      .font('Helvetica-Bold')
      .text('Account Details:', 260, paymentYPos);

    const paymentDetails = [
      'BANK: Meezan Bank',
      'TITLE: Tajkhel trading company',
      'ACC#: 0675534001'
    ];

    paymentYPos += 12;
    doc.fontSize(9).fillColor('#374151').font('Helvetica');
    paymentDetails.forEach((detail, index) => {
      if (index === 0) {
        doc.font('Helvetica-Bold').fillColor('#2c3e50');
      } else {
        doc.font('Helvetica').fillColor('#374151');
      }
      const detailHeight = doc.heightOfString(detail, { width: 200 });
      if (paymentYPos + detailHeight > 500) {
        doc.addPage();
        drawHeader();
        paymentYPos = 100;
      }
      doc.text(detail, 260, paymentYPos);
      paymentYPos += detailHeight + 4;
    });

    yPos = Math.max(customerYPos, paymentYPos) + 20;

    const status = mapStatusFromEnum(invoice.status);
    let statusColor = '#6b7280';
    let statusBg = '#f5f6f5';
    if (status === 'paid') {
      statusColor = '#15803d';
      statusBg = '#dcfce7';
    } else if (status === 'overdue' || status === 'unpaid') {
      statusColor = '#b91c1c';
      statusBg = '#fee2e2';
    } else if (status === 'pending' || status === 'partially_paid') {
      statusColor = '#d97706';
      statusBg = '#fef3c7';
    }

    if (yPos + 20 > 500) {
      doc.addPage();
      drawHeader();
      yPos = 100;
    }

    doc
      .rect(40, yPos, 100, 20)
      .fill(statusBg)
      .fillColor(statusColor)
      .fontSize(10)
      .font('Helvetica-Bold')
      .text(`Status: ${status.toUpperCase()}`, 45, yPos + 6);

    yPos += 30;

    const drawTableHeader = () => {
      if (yPos + 25 > 500) {
        doc.addPage();
        drawHeader();
        yPos = 100;
      }
      if (invoice.note) {
        const noteHeight = doc
          .fontSize(10)
          .font('Helvetica-Bold')
          .heightOfString(invoice.note, { width: 760 });
        doc
          .rect(40, yPos, 760, noteHeight + 8)
          .fill('#1f2937')
          .fillColor('white')
          .fontSize(10)
          .font('Helvetica-Bold')
          .text(invoice.note, 40, yPos + 4, { align: 'center', width: 760 });
        yPos += noteHeight + 12;
      }

      doc
        .rect(40, yPos, 760, 20)
        .fill('#1f2937')
        .fillColor('white')
        .fontSize(9)
        .font('Helvetica-Bold');

      doc.text('S#', 45, yPos + 6, { width: 30 });
      doc.text('Product', 75, yPos + 6, { width: 120 });
      doc.text('Lot', 195, yPos + 6, { width: 60 });
      doc.text('File No', 255, yPos + 6, { width: 60 });
      doc.text('Weight', 315, yPos + 6, { width: 50 });
      doc.text('Units', 365, yPos + 6, { width: 50 });
      doc.text('Bal Weight', 415, yPos + 6, { width: 50 });
      doc.text('Unit Price', 465, yPos + 6, { width: 60 });
      doc.text('Discount', 525, yPos + 6, { width: 60 });
      doc.text('Amount', 585, yPos + 6, { width: 60 });

      yPos += 20;
      return yPos;
    };

    yPos = drawTableHeader();

    const currencySymbol = invoice.currency || 'PKR';
    let subtotal = 0;
    let discountTotal = 0;

    itemsResult.rows.forEach((item, index) => {
      const baseAmount = (item.weight * item.balance_units / 45) * item.unit_price;
      const discountPercentage = getDiscountPercentage(item.discount);
      const amount = baseAmount * (1 - discountPercentage);
      subtotal += baseAmount;
      discountTotal += baseAmount * discountPercentage;

      const productName = item.product_name || `Product #${item.product_id}`;
      const productHeight = doc
        .fontSize(8)
        .font('Helvetica')
        .heightOfString(productName, { width: 120 });
      const rowHeight = Math.max(18, productHeight + 8);

      if (yPos + rowHeight > 500) {
        doc.addPage();
        drawHeader();
        yPos = 100;
        yPos = drawTableHeader();
      }

      const rowColor = index % 2 === 0 ? '#ffffff' : '#f9fafb';
      doc
        .rect(40, yPos, 760, rowHeight)
        .fill(rowColor)
        .fillColor('#1f2937')
        .fontSize(8)
        .font('Helvetica');

      doc.text((index + 1).toString(), 45, yPos + 5, { width: 30 });
      doc.text(productName.substring(0, 25), 75, yPos + 5, { width: 120 });
      doc.text(item.lot || 'N/A', 195, yPos + 5, { width: 60 });
      doc.text(item.fileno || 'N/A', 255, yPos + 5, { width: 60 });
      doc.text(Number(item.weight).toFixed(2), 315, yPos + 5, { width: 50 });
      doc.text(Number(item.balance_units), 365, yPos + 5, { width: 50 });
      doc.text(Number(item.balance_weight).toFixed(2), 415, yPos + 5, { width: 50 });
      doc.text(`${currencySymbol} ${Number(item.unit_price).toFixed(2)}`, 465, yPos + 5, { width: 60 });
      doc.text(item.discount.replace('_', ' '), 525, yPos + 5, { width: 60 });
      doc.text(`${currencySymbol} ${Number(amount).toFixed(2)}`, 585, yPos + 5, { width: 60 });

      yPos += rowHeight;
    });

    yPos += 10;
    if (yPos + 80 > 500) {
      doc.addPage();
      drawHeader();
      yPos = 100;
    }

    doc
      .fontSize(9)
      .fillColor('#6b7280')
      .font('Helvetica-Oblique')
      .text('This print is electronic, no signature required', 40, yPos, { align: 'left', width: 760 });

    yPos += 15;

    const summaryBoxY = yPos;
    const taxAmount = invoice.tax ? subtotal * (invoice.tax / 100) : 0;
    const total = subtotal - discountTotal + taxAmount;

    doc
      .fillColor('#1f2937')
      .fontSize(10)
      .font('Helvetica')
      .text('Subtotal:', 400, summaryBoxY)
      .text(`${currencySymbol} ${Number(subtotal).toFixed(2)}`, 520, summaryBoxY, { width: 100 })
      .text('Discount:', 400, summaryBoxY + 15)
      .text(`${currencySymbol} ${Number(discountTotal).toFixed(2)}`, 520, summaryBoxY + 15, { width: 100 });

    if (invoice.tax) {
      doc
        .text(`Tax (${invoice.tax}%):`, 400, summaryBoxY + 30)
        .text(`${currencySymbol} ${Number(taxAmount).toFixed(2)}`, 520, summaryBoxY + 30, { width: 100 });
    }

    doc
      .font('Helvetica-Bold')
      .fontSize(11)
      .text('Total:', 400, summaryBoxY + (invoice.tax ? 45 : 30))
      .text(`${currencySymbol} ${Number(total).toFixed(2)}`, 520, summaryBoxY + (invoice.tax ? 45 : 30), { width: 100 })
      .text('Paid:', 400, summaryBoxY + (invoice.tax ? 60 : 45))
      .text(`${currencySymbol} ${Number(invoice.paid).toFixed(2)}`, 520, summaryBoxY + (invoice.tax ? 60 : 45), { width: 100 });

    yPos = summaryBoxY + (invoice.tax ? 75 : 60);

    yPos += 20;
    if (yPos + 20 > 500) {
      doc.addPage();
      drawHeader();
      yPos = 100;
    }

    doc
      .fontSize(9)
      .fillColor('#6b7280')
      .font('Helvetica')
      .text('Payment Terms: Net 30 days', 40, yPos)
      .text('Thank you for your business!', 40, yPos + 12);

    const pageCount = doc.bufferedPageRange().count;
    for (let i = 0; i < pageCount; i++) {
      addFixedFooter(i);
    }

    doc.on('pageAdded', () => {
      drawHeader();
      addFixedFooter(doc.bufferedPageRange().count - 1);
    });

    doc.end();
  } catch (error) {
    console.error('Error generating single invoice PDF:', error, error.stack);
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate single invoice PDF',
        message: error.message,
        timestamp: new Date().toISOString(),
      });
    }
    if (doc) {
      try {
        doc.end();
      } catch (endError) {
        console.error('Error closing PDF document:', endError);
      }
    }
  }
};
module.exports = {
  getAllInvoices,
  getInvoiceById,
  createInvoice,
  updateInvoice,
  deleteInvoice,
  downloadInvoicesPDF,
  downloadInvoicesPDFById,
};